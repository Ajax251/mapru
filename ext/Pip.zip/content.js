let activeVideo = null;
const btn = document.createElement('div');
btn.className = 'pip-overlay-btn';
btn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M19 7h-8v6h8V7zm2-4H3c-1.1 0-2 .9-2 2v14c0 1.1.9 1.98 2 1.98h18c1.1 0 2-.88 2-1.98V5c0-1.1-.9-2-2-2zm0 16.01H3V4.98h18v14.03z"/></svg>`;
document.body.appendChild(btn);

const findVideo = (el) => {
    if (el.tagName === 'VIDEO') return el;
    return el.querySelector('video') || el.closest('.html5-video-player')?.querySelector('video');
};

document.addEventListener('mouseover', (e) => {
    const video = findVideo(e.target);
    if (video) {
        activeVideo = video;
        const rect = video.getBoundingClientRect();
        
        btn.style.top = `${rect.top + window.scrollY + 10}px`;
        btn.style.left = `${rect.left + window.scrollX + (rect.width / 2)}px`;
        btn.style.transform = 'translateX(-50%)';
        
        btn.style.display = 'flex';
        setTimeout(() => btn.style.opacity = '1', 10);
    } else if (e.target !== btn && !btn.contains(e.target)) {
        btn.style.opacity = '0';
        setTimeout(() => { if (btn.style.opacity === '0') btn.style.display = 'none'; }, 200);
    }
});

btn.addEventListener('click', async (e) => {
    e.stopPropagation();
    if (!activeVideo) return;
    try {
        if (document.pictureInPictureElement) {
            await document.exitPictureInPicture();
        } else {
            await activeVideo.requestPictureInPicture();
        }
    } catch (err) {}
});