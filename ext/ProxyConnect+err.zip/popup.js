document.addEventListener('DOMContentLoaded', function() {
    const toggle = document.getElementById('proxyToggle');
    const proxySelect = document.getElementById('proxySelect');
    const newProxyInput = document.getElementById('newProxyInput');
    const addProxyBtn = document.getElementById('addProxyBtn');
    const deleteProxyBtn = document.getElementById('deleteProxyBtn');
    const schemeSelect = document.getElementById('scheme');
    const targetSitesInput = document.getElementById('targetSites');
    const statusDiv = document.getElementById('status');
    const trafficInfoDiv = document.getElementById('trafficInfo');
    const resetButton = document.getElementById('resetButton');
    
    const importBtn = document.getElementById('importBtn');
    const exportBtn = document.getElementById('exportBtn');
    const fileInput = document.getElementById('fileInput');

    const authCopyBlock = document.getElementById('authCopyBlock');
    const copyLoginBtn = document.getElementById('copyLoginBtn');
    const copyPassBtn = document.getElementById('copyPassBtn');

    let proxyList =[];

    // Иконки для кнопок копирования
    const loginIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`;
    const passIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>`;
    const checkIcon = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`;

    function showStatus(message, type = 'error') {
        statusDiv.textContent = message;
        statusDiv.className = type === 'success' ? 'status-success' : 'status-error';
        setTimeout(() => { statusDiv.textContent = ''; statusDiv.className = ''; }, 3000);
    }

    function formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024, sizes =['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    function updateTrafficInfo() {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (!tabs[0] || !tabs[0].url) { trafficInfoDiv.textContent = 'N/A'; return; }
            try {
                const hostname = new URL(tabs[0].url).hostname;
                chrome.storage.local.get('trafficData', (data) => {
                    trafficInfoDiv.textContent = formatBytes((data.trafficData || {})[hostname] || 0);
                });
            } catch (e) { trafficInfoDiv.textContent = 'N/A'; }
        });
    }

    function updateAuthButtons() {
        const idx = parseInt(proxySelect.value, 10);
        const selected = proxyList[idx];
        
        if (selected && selected.username) {
            authCopyBlock.style.display = 'flex';
            
            copyLoginBtn.onclick = () => {
                navigator.clipboard.writeText(selected.username);
                copyLoginBtn.innerHTML = `${checkIcon} <span>Скопировано</span>`;
                copyLoginBtn.classList.add('copied');
                setTimeout(() => { 
                    copyLoginBtn.innerHTML = `${loginIcon} <span>Логин</span>`; 
                    copyLoginBtn.classList.remove('copied'); 
                }, 1500);
            };
            
            copyPassBtn.onclick = () => {
                navigator.clipboard.writeText(selected.password || '');
                copyPassBtn.innerHTML = `${checkIcon} <span>Скопировано</span>`;
                copyPassBtn.classList.add('copied');
                setTimeout(() => { 
                    copyPassBtn.innerHTML = `${passIcon} <span>Пароль</span>`; 
                    copyPassBtn.classList.remove('copied'); 
                }, 1500);
            };
        } else {
            authCopyBlock.style.display = 'none';
        }
    }

    function parseProxyString(str) {
        str = str.trim();
        if (!str) return null;
        
        let scheme = 'http';
        let host, port, username = '', password = '';

        const schemeMatch = str.match(/^(http|https|socks4|socks5):\/\/(.*)/i);
        if (schemeMatch) {
            scheme = schemeMatch[1].toLowerCase();
            str = schemeMatch[2];
        }

        if (str.includes('@')) {
            const parts = str.split('@');
            const auth = parts[0].split(':');
            username = auth[0];
            password = auth.slice(1).join(':'); 
            str = parts[1];
        }

        const parts = str.split(':');
        if (parts.length >= 2 && !username) {
            host = parts[0];
            port = parts[1];
            if (parts.length >= 4) {
                username = parts[2];
                password = parts.slice(3).join(':');
            }
        } else if (parts.length >= 2 && username) {
            host = parts[0];
            port = parts[1];
        } else {
            return null;
        }

        port = parseInt(port, 10);
        if (!host || isNaN(port) || port < 1 || port > 65535) return null;

        return { address: `${host}:${port}`, port, username, password, scheme };
    }

    function renderProxySelect(selectedIndex) {
        proxySelect.innerHTML = '';
        if (proxyList.length === 0) {
            const opt = document.createElement('option');
            opt.value = ""; opt.textContent = "Нет сохраненных прокси"; opt.disabled = true;
            proxySelect.appendChild(opt); proxySelect.value = "";
        } else {
            proxyList.forEach((proxy, index) => {
                const opt = document.createElement('option');
                opt.value = index;
                const authMark = proxy.username ? ' 🔒' : '';
                opt.textContent = `${proxy.address} (${proxy.scheme.toUpperCase()})${authMark}`;
                proxySelect.appendChild(opt);
            });
            proxySelect.value = (selectedIndex >= 0 && selectedIndex < proxyList.length) ? selectedIndex : 0;
        }
        updateAuthButtons();
    }

    function collectSettings() {
        const idx = parseInt(proxySelect.value, 10);
        const selected = proxyList[idx];
        if (!selected) return { server: '', port: '', scheme: schemeSelect.value, targetSites: targetSitesInput.value.trim(), username: '', password: '' };
        
        const [server, port] = selected.address.split(':');
        return {
            server, port,
            scheme: selected.scheme,
            targetSites: targetSitesInput.value.trim(),
            username: selected.username || '',
            password: selected.password || ''
        };
    }

    function saveSettingsOnChange() {
        const settings = collectSettings();
        chrome.storage.sync.set({ proxySettings: settings, proxyList: proxyList });
        
        if (toggle.checked) {
            if (settings.server && settings.port) {
                chrome.runtime.sendMessage({ action: 'apply', settings: settings });
            } else {
                toggle.checked = false;
                chrome.runtime.sendMessage({ action: 'disable' });
                chrome.storage.sync.set({ isConnected: false });
            }
        }
    }

    chrome.storage.sync.get(['proxyList', 'proxySettings', 'isConnected'], function(data) {
        proxyList = data.proxyList ||[];
        let selectedIndex = 0;
        if (data.proxySettings && data.proxySettings.server) {
            const activeAddr = `${data.proxySettings.server}:${data.proxySettings.port}`;
            selectedIndex = Math.max(0, proxyList.findIndex(p => p.address === activeAddr));
        }
        renderProxySelect(selectedIndex);
        if (proxyList[selectedIndex]) schemeSelect.value = proxyList[selectedIndex].scheme;
        if (data.proxySettings) targetSitesInput.value = data.proxySettings.targetSites || '';

        toggle.checked = !!data.isConnected;
        updateTrafficInfo();
    });

    toggle.addEventListener('change', function() {
        const settings = collectSettings();
        if (toggle.checked) {
            if (!settings.server || !settings.port) {
                toggle.checked = false; showStatus('Выберите прокси', 'error'); return;
            }
            chrome.runtime.sendMessage({ action: 'apply', settings: settings });
            chrome.storage.sync.set({ isConnected: true, proxySettings: settings });
            showStatus('Прокси подключен', 'success');
        } else {
            chrome.runtime.sendMessage({ action: 'disable' });
            chrome.storage.sync.set({ isConnected: false });
            showStatus('Прокси отключен', 'error');
        }
    });

    addProxyBtn.addEventListener('click', () => {
        const input = newProxyInput.value.trim();
        if (!input) return;
        
        const parsed = parseProxyString(input);
        if (!parsed) { showStatus('Ошибка формата', 'error'); return; }

        const existsIdx = proxyList.findIndex(p => p.address === parsed.address && p.username === parsed.username);
        if (existsIdx !== -1) {
            renderProxySelect(existsIdx);
            schemeSelect.value = proxyList[existsIdx].scheme;
            showStatus('Уже в списке', 'success'); return;
        }

        const schemeToUse = input.includes('://') ? parsed.scheme : schemeSelect.value;
        proxyList.push({ address: parsed.address, scheme: schemeToUse, username: parsed.username, password: parsed.password });
        newProxyInput.value = '';
        renderProxySelect(proxyList.length - 1);
        saveSettingsOnChange();
        showStatus('Добавлено', 'success');
    });

    newProxyInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') addProxyBtn.click(); });

    deleteProxyBtn.addEventListener('click', () => {
        const idx = parseInt(proxySelect.value, 10);
        if (!isNaN(idx) && proxyList[idx]) {
            proxyList.splice(idx, 1);
            const newIdx = proxyList.length > 0 ? 0 : -1;
            renderProxySelect(newIdx);
            if (newIdx !== -1) schemeSelect.value = proxyList[newIdx].scheme;
            saveSettingsOnChange();
        }
    });

    proxySelect.addEventListener('change', () => {
        const idx = parseInt(proxySelect.value, 10);
        if (!isNaN(idx) && proxyList[idx]) {
            schemeSelect.value = proxyList[idx].scheme;
            updateAuthButtons();
            saveSettingsOnChange();
        }
    });

    schemeSelect.addEventListener('change', () => {
        const idx = parseInt(proxySelect.value, 10);
        if (!isNaN(idx) && proxyList[idx]) {
            proxyList[idx].scheme = schemeSelect.value;
            renderProxySelect(idx); 
            saveSettingsOnChange();
        }
    });

    targetSitesInput.addEventListener('input', saveSettingsOnChange);

    resetButton.addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'resetStats' });
        trafficInfoDiv.textContent = '0 B';
    });

    importBtn.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            const lines = event.target.result.split('\n');
            let addedCount = 0;

            lines.forEach(line => {
                const parsed = parseProxyString(line);
                if (parsed) {
                    const exists = proxyList.find(p => p.address === parsed.address && p.username === parsed.username);
                    if (!exists) {
                        proxyList.push({ address: parsed.address, scheme: parsed.scheme, username: parsed.username, password: parsed.password });
                        addedCount++;
                    }
                }
            });

            if (addedCount > 0) {
                renderProxySelect(proxyList.length - 1);
                saveSettingsOnChange();
                showStatus(`Импортировано: ${addedCount}`, 'success');
            } else { showStatus('Новых прокси не найдено', 'error'); }
            
            fileInput.value = '';
        };
        reader.readAsText(file);
    });

    exportBtn.addEventListener('click', () => {
        if (proxyList.length === 0) { showStatus('Список пуст', 'error'); return; }

        const lines = proxyList.map(p => {
            let line = `${p.scheme}://${p.address}`;
            if (p.username) line += `:${p.username}:${p.password}`;
            return line;
        });

        const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = 'proxy_list.txt';
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        URL.revokeObjectURL(url);
    });
});