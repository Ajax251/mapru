// Функция для проверки и блокировки URL
async function checkAndBlockTab(tab) {
  // Проверяем, что вкладка открыта программно и имеет URL
  if (tab.openerTabId === undefined && tab.pendingUrl) {
    const urlToBlock = tab.pendingUrl;

    const data = await chrome.storage.sync.get('blockedUrls');
    const blockedUrls = data.blockedUrls || [];

    for (const blockedUrl of blockedUrls) {
      if (urlToBlock.startsWith(blockedUrl)) {
        console.log(`[Tab Blocker] Блокировка вкладки: ${urlToBlock}`);
        
        // Закрываем вкладку
        chrome.tabs.remove(tab.id);

        // Увеличиваем счетчик для этого URL
        const sessionData = await chrome.storage.session.get('blockCounts');
        const counts = sessionData.blockCounts || {};
        counts[blockedUrl] = (counts[blockedUrl] || 0) + 1;
        await chrome.storage.session.set({ blockCounts: counts });
        console.log(`[Tab Blocker] Счетчик для ${blockedUrl} теперь: ${counts[blockedUrl]}`);
        
        return; 
      }
    }
  }
}

// Слушаем событие создания новой вкладки
chrome.tabs.onCreated.addListener(checkAndBlockTab);

// При первой установке создаем пустой список для URL
chrome.runtime.onInstalled.addListener(() => {
  // Проверяем, существует ли уже список заблокированных URL
  chrome.storage.sync.get(['blockedUrls'], (result) => {
    // Если списка нет (самая первая установка), создаем пустой список.
    // Это предотвращает ошибки при первом запуске.
    if (!result.blockedUrls) {
      chrome.storage.sync.set({ blockedUrls: [] });
      console.log('[Tab Blocker] Список блокировки инициализирован. Он пуст.');
    }
  });
});