document.addEventListener('DOMContentLoaded', () => {
  const urlList = document.getElementById('urlList');
  const newUrlInput = document.getElementById('newUrl');
  const addBtn = document.getElementById('addBtn');

  const deleteIconSvg = `
    <svg viewBox="0 0 24 24">
      <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path>
    </svg>`;

  async function loadUrls() {
    const { blockedUrls = [] } = await chrome.storage.sync.get('blockedUrls');
    const { blockCounts = {} } = await chrome.storage.session.get('blockCounts');
    
    urlList.innerHTML = '';

    blockedUrls.forEach(url => {
      const count = blockCounts[url] || 0;

      const li = document.createElement('li');
      
      const urlText = document.createElement('span');
      urlText.className = 'url-text';
      urlText.textContent = url;
      urlText.title = url; // Показывает полный URL при наведении

      const counterBadge = document.createElement('span');
      counterBadge.className = 'counter-badge';
      counterBadge.textContent = count;

      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'delete-btn';
      deleteBtn.innerHTML = deleteIconSvg;
      deleteBtn.dataset.url = url;
      deleteBtn.title = 'Удалить';

      li.appendChild(urlText);
      li.appendChild(counterBadge);
      li.appendChild(deleteBtn);
      urlList.appendChild(li);
    });
  }

  async function addUrl() {
    const newUrl = newUrlInput.value.trim();
    if (newUrl) {
      const { blockedUrls = [] } = await chrome.storage.sync.get('blockedUrls');
      if (!blockedUrls.includes(newUrl)) {
        blockedUrls.push(newUrl);
        await chrome.storage.sync.set({ blockedUrls });
        newUrlInput.value = '';
        loadUrls();
      }
    }
  }

  urlList.addEventListener('click', async (e) => {
    const deleteBtn = e.target.closest('.delete-btn');
    if (deleteBtn) {
      const urlToDelete = deleteBtn.dataset.url;
      let { blockedUrls = [] } = await chrome.storage.sync.get('blockedUrls');
      blockedUrls = blockedUrls.filter(url => url !== urlToDelete);
      await chrome.storage.sync.set({ blockedUrls });
      
      // Также удалим счетчик из сессии для чистоты
      let { blockCounts = {} } = await chrome.storage.session.get('blockCounts');
      delete blockCounts[urlToDelete];
      await chrome.storage.session.set({ blockCounts });

      loadUrls();
    }
  });

  addBtn.addEventListener('click', addUrl);
  newUrlInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      addUrl();
    }
  });
  
  loadUrls();
});