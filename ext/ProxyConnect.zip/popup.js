document.addEventListener('DOMContentLoaded', function() {
    const toggle = document.getElementById('proxyToggle');
    const serverInput = document.getElementById('server');
    const portInput = document.getElementById('port');
    const schemeSelect = document.getElementById('scheme');
    const targetSitesInput = document.getElementById('targetSites');
    const statusDiv = document.getElementById('status');
    const trafficInfoDiv = document.getElementById('trafficInfo');
    const resetButton = document.getElementById('resetButton');

    function showStatus(message, type = 'error') {
        statusDiv.textContent = message;
        statusDiv.className = type === 'success' ? 'status-success' : 'status-error';
        setTimeout(() => {
            statusDiv.textContent = '';
            statusDiv.className = '';
        }, 4000);
    }

    function validateInputs(server, port) {
        if (!server || !port) {
            showStatus('Пожалуйста, заполните поля сервера и порта', 'error');
            return false;
        }
        if (!/^\d+$/.test(port) || port < 1 || port > 65535) {
            showStatus('Порт должен быть числом от 1 до 65535', 'error');
            return false;
        }
        return true;
    }
    
    function formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    function updateTrafficInfo() {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (!tabs[0] || !tabs[0].url) {
                trafficInfoDiv.textContent = 'N/A';
                return;
            }
            try {
                const url = new URL(tabs[0].url);
                const hostname = url.hostname;

                chrome.storage.local.get('trafficData', (data) => {
                    const trafficData = data.trafficData || {};
                    const siteTraffic = trafficData[hostname] || 0;
                    trafficInfoDiv.textContent = formatBytes(siteTraffic);
                });
            } catch (e) {
                trafficInfoDiv.textContent = 'N/A';
            }
        });
    }

    chrome.storage.sync.get(['proxySettings', 'isConnected'], function(data) {
        if (data.proxySettings) {
            serverInput.value = data.proxySettings.server || '';
            portInput.value = data.proxySettings.port || '';
            schemeSelect.value = data.proxySettings.scheme || 'http';
            targetSitesInput.value = data.proxySettings.targetSites || '';
        }
        toggle.checked = !!data.isConnected;
        if (toggle.checked) {
            showStatus('Прокси активен', 'success');
        }
    });

    function collectSettings() {
        return {
            scheme: schemeSelect.value,
            server: serverInput.value.trim(),
            port: portInput.value.trim(),
            targetSites: targetSitesInput.value.trim()
        };
    }

    toggle.addEventListener('change', function() {
        const settings = collectSettings();
        if (toggle.checked) {
            if (!validateInputs(settings.server, settings.port)) {
                toggle.checked = false;
                return;
            }
            chrome.runtime.sendMessage({ action: 'apply', settings: settings });
            chrome.storage.sync.set({ isConnected: true, proxySettings: settings });
            showStatus('Прокси подключен успешно', 'success');
        } else {
            chrome.runtime.sendMessage({ action: 'disable' });
            chrome.storage.sync.set({ isConnected: false });
            showStatus('Прокси отключен', 'error');
        }
    });

    function saveSettingsOnChange() {
        const settings = collectSettings();
        chrome.storage.sync.set({ proxySettings: settings });
        if (toggle.checked && validateInputs(settings.server, settings.port)) {
            chrome.runtime.sendMessage({ action: 'apply', settings: settings });
        }
    }

    resetButton.addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'resetStats' });
        trafficInfoDiv.textContent = '0 B';
    });

    serverInput.addEventListener('input', saveSettingsOnChange);
    portInput.addEventListener('input', saveSettingsOnChange);
    schemeSelect.addEventListener('change', saveSettingsOnChange);
    targetSitesInput.addEventListener('input', saveSettingsOnChange);

    serverInput.addEventListener('keypress', (e) => (e.key === 'Enter') && portInput.focus());
    portInput.addEventListener('keypress', (e) => (e.key === 'Enter') && targetSitesInput.focus());
    
    updateTrafficInfo();
});