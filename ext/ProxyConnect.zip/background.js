let cachedState = {
    isConnected: false,
    proxySettings: {},
    connectionStatus: 'disconnected',
    lastIpInfo: null
};

let trafficData = {};
let saveTrafficTimeout = null;
let baseIconBitmap = null;
const authRetryMap = new Map();

initialize();

async function initialize() {
    const data = await chrome.storage.local.get([
        'proxySettings',
        'isConnected',
        'trafficData',
        'lastIpInfo',
        'connectionStatus'
    ]);

    trafficData = data.trafficData || {};
    cachedState.isConnected = !!data.isConnected;
    cachedState.lastIpInfo = data.lastIpInfo || null;
    cachedState.connectionStatus = data.isConnected ? (data.connectionStatus || 'checking') : 'disconnected';

    if (data.proxySettings) {
        updateCachedState(data.proxySettings);
    }

    if (cachedState.isConnected) {
        enforceStrictWebRTC(true);
        if (cachedState.proxySettings && cachedState.proxySettings.server && cachedState.proxySettings.port) {
            await applyProxyAsync(cachedState.proxySettings, false);
        } else {
            await engageEmergencyKillSwitch();
        }
    } else {
        enforceStrictWebRTC(false);
        await updateVisualIndicators();
    }
}

function updateCachedState(proxySettings) {
    cachedState.proxySettings = {
        scheme: (proxySettings?.scheme || 'http').toLowerCase(),
        server: (proxySettings?.server || '').trim(),
        port: String(proxySettings?.port || '').trim(),
        username: (proxySettings?.username || '').trim(),
        password: (proxySettings?.password || '').trim()
    };
}

function enforceStrictWebRTC(enable) {
    if (!chrome.privacy || !chrome.privacy.network) return;
    chrome.privacy.network.webRTCIPHandlingPolicy.set({
        value: enable ? 'disable_non_proxied_udp' : 'default'
    }, () => { void chrome.runtime.lastError; });
}

async function engageEmergencyKillSwitch() {
    enforceStrictWebRTC(true);
    const killConfig = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "http",
                host: "127.0.0.1",
                port: 9
            },
            bypassList: []
        }
    };

    await new Promise((resolve) => {
        chrome.proxy.settings.set({ value: killConfig, scope: "regular" }, () => {
            void chrome.runtime.lastError;
            resolve();
        });
    });

    cachedState.connectionStatus = 'error';
    await chrome.storage.local.set({ connectionStatus: 'error' });
    await updateVisualIndicators();
}

async function applyProxyAsync(settings, runCheck = true) {
    if (!settings || !settings.server || !settings.port) {
        await engageEmergencyKillSwitch();
        return;
    }

    const portNum = parseInt(settings.port, 10);
    if (isNaN(portNum) || portNum < 1 || portNum > 65535) {
        await engageEmergencyKillSwitch();
        return;
    }

    updateCachedState(settings);
    cachedState.isConnected = true;
    if (runCheck) cachedState.connectionStatus = 'checking';
    authRetryMap.clear();

    enforceStrictWebRTC(true);

    const config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: cachedState.proxySettings.scheme,
                host: cachedState.proxySettings.server,
                port: portNum
            },
            bypassList: []
        }
    };

    await new Promise((resolve) => {
        chrome.proxy.settings.set({ value: config, scope: "regular" }, () => {
            void chrome.runtime.lastError;
            resolve();
        });
    });

    await updateVisualIndicators();
    if (runCheck) {
        await checkProxyConnection();
    }
}

function disableProxy() {
    cachedState.isConnected = false;
    cachedState.connectionStatus = 'disconnected';
    cachedState.lastIpInfo = null;
    authRetryMap.clear();

    enforceStrictWebRTC(false);

    chrome.storage.local.set({
        isConnected: false,
        connectionStatus: 'disconnected',
        lastIpInfo: null
    });

    chrome.proxy.settings.clear({ scope: "regular" }, () => {
        void chrome.runtime.lastError;
        updateVisualIndicators();
    });
}

if (chrome.proxy && chrome.proxy.onProxyError) {
    chrome.proxy.onProxyError.addListener(() => {
        if (cachedState.isConnected) {
            cachedState.connectionStatus = 'error';
            chrome.storage.local.set({ connectionStatus: 'error' });
            updateVisualIndicators();
        }
    });
}

async function checkProxyConnection() {
    if (!cachedState.isConnected) return null;

    cachedState.connectionStatus = 'checking';
    await updateVisualIndicators();

    const startTime = Date.now();
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 7000);

        const response = await fetch('https://ipwho.is/', {
            signal: controller.signal,
            cache: 'no-store'
        });
        clearTimeout(timeoutId);

        if (!response.ok) throw new Error('HTTP Error');
        const data = await response.json();
        const ping = Date.now() - startTime;

        const ipInfo = {
            ip: data.ip || cachedState.proxySettings.server,
            country: data.country_code || '',
            ping: ping
        };

        cachedState.connectionStatus = 'connected';
        cachedState.lastIpInfo = ipInfo;

        await chrome.storage.local.set({
            connectionStatus: 'connected',
            lastIpInfo: ipInfo
        });

        await updateVisualIndicators();
        return { success: true, ...ipInfo };
    } catch (err) {
        try {
            const controller2 = new AbortController();
            const timeoutId2 = setTimeout(() => controller2.abort(), 5000);
            const res2 = await fetch('https://api.ipify.org?format=json', {
                signal: controller2.signal,
                cache: 'no-store'
            });
            clearTimeout(timeoutId2);
            if (!res2.ok) throw new Error('HTTP Error');
            const data2 = await res2.json();
            const ping = Date.now() - startTime;

            const ipInfo = {
                ip: data2.ip || cachedState.proxySettings.server,
                country: '',
                ping: ping
            };

            cachedState.connectionStatus = 'connected';
            cachedState.lastIpInfo = ipInfo;
            await chrome.storage.local.set({ connectionStatus: 'connected', lastIpInfo: ipInfo });
            await updateVisualIndicators();
            return { success: true, ...ipInfo };
        } catch (e2) {
            cachedState.connectionStatus = 'error';
            await chrome.storage.local.set({ connectionStatus: 'error' });
            await updateVisualIndicators();
            return { success: false, error: 'Прокси недоступен — трафик заблокирован' };
        }
    }
}

function getLastIpDigits(ipStr) {
    if (!ipStr) return '';
    let clean = ipStr.trim();
    if (clean.includes(':') && !clean.includes('::')) {
        clean = clean.split(':')[0];
    }
    if (clean.includes('.')) {
        const parts = clean.split('.');
        const last = parts[parts.length - 1];
        if (/^\d+$/.test(last)) {
            return last;
        }
    }
    const match = clean.match(/\d+$/);
    if (match) return match[0].slice(-3);
    return '';
}

async function getBaseIconBitmap() {
    if (baseIconBitmap) return baseIconBitmap;
    try {
        const url = chrome.runtime.getURL('icon.png');
        const response = await fetch(url);
        if (!response.ok) return null;
        const blob = await response.blob();
        baseIconBitmap = await createImageBitmap(blob);
        return baseIconBitmap;
    } catch (e) {
        return null;
    }
}

function renderSizeImageData(bitmap, size, statusColor) {
    const canvas = new OffscreenCanvas(size, size);
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    ctx.clearRect(0, 0, size, size);

    if (bitmap) {
        ctx.drawImage(bitmap, 0, 0, size, size);
    } else {
        ctx.fillStyle = '#0ea5e9';
        ctx.beginPath();
        ctx.arc(size / 2, size / 2, size * 0.45, 0, Math.PI * 2);
        ctx.fill();
    }

    if (statusColor) {
        const isSmall = size <= 19;
        const radius = isSmall ? 2.8 : 5.5;
        const border = isSmall ? 4.0 : 7.2;
        const cx = size - border;
        const cy = border;

        ctx.beginPath();
        ctx.arc(cx, cy, border, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();

        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.fillStyle = statusColor;
        ctx.fill();
    }

    return ctx.getImageData(0, 0, size, size);
}

async function safeSetIconWithDot(statusColor) {
    try {
        const bitmap = await getBaseIconBitmap();
        const sizes = [16, 19, 32, 38];
        const imageDataDict = {};
        for (const s of sizes) {
            imageDataDict[s] = renderSizeImageData(bitmap, s, statusColor);
        }

        chrome.action.setIcon({ imageData: imageDataDict }, () => {
            void chrome.runtime.lastError;
        });
    } catch (e) {
        void chrome.runtime.lastError;
    }
}

async function updateVisualIndicators() {
    if (!cachedState.isConnected) {
        await safeSetIconWithDot('#ef4444');
        chrome.action.setBadgeText({ text: '' });
        chrome.action.setTitle({ title: 'Прокси отключён (Прямое соединение)' });
        return;
    }

    let indicatorColor = '#10b981';
    if (cachedState.connectionStatus === 'error') {
        indicatorColor = '#ef4444';
    } else if (cachedState.connectionStatus === 'checking') {
        indicatorColor = '#f59e0b';
    }

    await safeSetIconWithDot(indicatorColor);

    const ipToDisplay = cachedState.lastIpInfo?.ip || cachedState.proxySettings?.server || '';
    const lastDigits = getLastIpDigits(ipToDisplay);

    if (cachedState.connectionStatus === 'error') {
        chrome.action.setBadgeText({ text: 'ERR' });
        chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
    } else if (cachedState.connectionStatus === 'checking') {
        chrome.action.setBadgeText({ text: lastDigits || '...' });
        chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
    } else if (lastDigits) {
        chrome.action.setBadgeText({ text: lastDigits });
        chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
    } else {
        chrome.action.setBadgeText({ text: 'ON' });
        chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
    }

    if (chrome.action.setBadgeTextColor) {
        chrome.action.setBadgeTextColor({ color: '#ffffff' });
    }

    const statusText = cachedState.connectionStatus === 'connected'
        ? '🟢 Прокси активен'
        : cachedState.connectionStatus === 'error'
        ? '🔴 Прокси недоступен — трафик заблокирован'
        : '🟡 Проверка соединения...';

    const ipLine = cachedState.lastIpInfo?.ip
        ? `IP: ${cachedState.lastIpInfo.ip} ${cachedState.lastIpInfo.country ? `(${cachedState.lastIpInfo.country})` : ''} • ${cachedState.lastIpInfo.ping} мс`
        : `Сервер: ${cachedState.proxySettings.server}:${cachedState.proxySettings.port}`;

    chrome.action.setTitle({
        title: `${statusText}\n${ipLine}`
    });
}

chrome.webRequest.onAuthRequired.addListener(
    (details, callback) => {
        if (!details.isProxy) {
            callback({});
            return;
        }

        const retries = authRetryMap.get(details.requestId) || 0;
        if (retries >= 3) {
            authRetryMap.delete(details.requestId);
            callback({ cancel: true });
            return;
        }
        authRetryMap.set(details.requestId, retries + 1);

        if (cachedState.isConnected && cachedState.proxySettings?.username) {
            callback({
                authCredentials: {
                    username: cachedState.proxySettings.username,
                    password: cachedState.proxySettings.password || ''
                }
            });
            return;
        }

        chrome.storage.local.get(['proxySettings', 'isConnected'], (data) => {
            const s = data.proxySettings;
            if (data.isConnected && s && s.username) {
                updateCachedState(s);
                cachedState.isConnected = true;
                callback({
                    authCredentials: {
                        username: s.username.trim(),
                        password: (s.password || '').trim()
                    }
                });
            } else {
                callback({ cancel: true });
            }
        });
    },
    { urls: ["<all_urls>"] },
    ["asyncBlocking"]
);

chrome.webRequest.onCompleted.addListener(
    (details) => {
        authRetryMap.delete(details.requestId);
        if (!cachedState.isConnected || details.tabId < 0 || details.fromCache) return;

        if (cachedState.connectionStatus === 'error' && details.url.startsWith('http')) {
            cachedState.connectionStatus = 'connected';
            chrome.storage.local.set({ connectionStatus: 'connected' });
            updateVisualIndicators();
        }

        const bytesHeader = details.responseHeaders?.find(h => h.name.toLowerCase() === 'content-length');
        const bytes = bytesHeader ? parseInt(bytesHeader.value, 10) : 0;
        if (bytes > 0) {
            chrome.tabs.get(details.tabId, (tab) => {
                if (chrome.runtime.lastError || !tab || !tab.url) return;
                try {
                    const mainHostname = new URL(tab.url).hostname;
                    trafficData[mainHostname] = (trafficData[mainHostname] || 0) + bytes;
                    scheduleSaveTraffic();
                } catch (e) {}
            });
        }
    },
    { urls: ["<all_urls>"] },
    ["responseHeaders"]
);

chrome.webRequest.onErrorOccurred.addListener(
    (details) => {
        authRetryMap.delete(details.requestId);
        if (cachedState.isConnected && details.error && details.error.includes('PROXY')) {
            cachedState.connectionStatus = 'error';
            chrome.storage.local.set({ connectionStatus: 'error' });
            updateVisualIndicators();
        }
    },
    { urls: ["<all_urls>"] }
);

function scheduleSaveTraffic() {
    if (saveTrafficTimeout) clearTimeout(saveTrafficTimeout);
    saveTrafficTimeout = setTimeout(() => {
        chrome.storage.local.set({ trafficData });
    }, 2000);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'apply') {
        applyProxyAsync(request.settings, request.runCheck !== false).then(() => {
            sendResponse({ status: 'applied' });
        });
        return true;
    } else if (request.action === 'disable') {
        disableProxy();
        sendResponse({ status: 'disabled' });
    } else if (request.action === 'checkIp') {
        checkProxyConnection().then(res => sendResponse(res));
        return true;
    } else if (request.action === 'resetStats') {
        trafficData = {};
        chrome.storage.local.set({ trafficData: {} });
        sendResponse({ ok: true });
    }
});

chrome.runtime.onInstalled.addListener(() => updateVisualIndicators());
chrome.runtime.onStartup.addListener(() => updateVisualIndicators());
chrome.tabs.onActivated.addListener(() => updateVisualIndicators());