// --- КОНФИГУРАЦИЯ ---
const COMPANION_DOMAINS_MAP = {
    'youtube.com': ['googlevideo.com', 'ytimg.com', 'ggpht.com']
};

// --- КЭШ В ПАМЯТИ ДЛЯ МАКСИМАЛЬНОЙ ПРОИЗВОДИТЕЛЬНОСТИ ---
let cachedState = {
    isConnected: false,
    proxySettings: {},
    expandedTargetSites: []
};
let trafficData = {};
let saveTrafficTimeout = null;

// --- ИНИЦИАЛИЗАЦИЯ ---
// Загружаем начальные данные один раз при старте
async function initialize() {
    const syncData = await chrome.storage.sync.get(['proxySettings', 'isConnected']);
    const localData = await chrome.storage.local.get('trafficData');
    
    trafficData = localData.trafficData || {};
    cachedState.isConnected = !!syncData.isConnected;
    if (syncData.proxySettings) {
        updateCachedState(syncData.proxySettings);
    }
    
    if (cachedState.isConnected) {
        applyProxy(cachedState.proxySettings);
    }
}
initialize();


// --- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ---
function getExpandedTargetSites(userSiteList) {
    if (!userSiteList) return [];
    const initialSites = userSiteList.split(/[\s,;\n]+/).filter(Boolean);
    const siteSet = new Set(initialSites);

    initialSites.forEach(site => {
        for (const mainDomain in COMPANION_DOMAINS_MAP) {
            if (site.includes(mainDomain)) {
                COMPANION_DOMAINS_MAP[mainDomain].forEach(companion => siteSet.add(companion));
            }
        }
    });
    return Array.from(siteSet);
}

function updateCachedState(proxySettings) {
    cachedState.proxySettings = proxySettings;
    cachedState.expandedTargetSites = getExpandedTargetSites(proxySettings.targetSites);
}


// --- ОСНОВНЫЕ ФУНКЦИИ ---
function applyProxy(settings) {
    if (!settings || !settings.server || !settings.port || !settings.scheme) return;
    updateCachedState(settings);
    cachedState.isConnected = true;

    const targetSites = cachedState.expandedTargetSites;
    let config;

    if (targetSites.length > 0) {
        const proxyType = settings.scheme.startsWith('socks') ? settings.scheme.toUpperCase() : 'PROXY';
        const proxyServerString = `${proxyType} ${settings.server}:${settings.port}`;
        const conditions = targetSites.map(host => `shExpMatch(host, "*.${host}") || shExpMatch(host, "${host}")`).join(" || ");
        const pacScript = `function FindProxyForURL(url, host) { if (${conditions}) { return "${proxyServerString}"; } return "DIRECT"; }`;
        config = { mode: "pac_script", pacScript: { data: pacScript } };
    } else {
        config = {
            mode: "fixed_servers",
            rules: {
                singleProxy: { scheme: settings.scheme, host: settings.server, port: parseInt(settings.port, 10) },
                bypassList: ["<local>"]
            }
        };
    }

    chrome.proxy.settings.set({ value: config, scope: "regular" }, () => {
        console.log("Прокси-настройки применены.");
        updateActiveTabIcon();
    });
}

function disableProxy() {
    cachedState.isConnected = false;
    chrome.proxy.settings.clear({ scope: "regular" }, () => {
        console.log("Прокси отключен.");
        updateActiveTabIcon();
    });
}

async function updateActiveTabIcon() {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab) updateIconForTab(tab);
    } catch (e) {
        // Может произойти ошибка, если окно было закрыто
    }
}

function updateIconForTab(tab) {
    if (!tab || !tab.url || !cachedState.isConnected) {
        chrome.action.setIcon({ path: "icon.png", tabId: tab.id });
        return;
    }

    const targetSites = cachedState.expandedTargetSites;
    let useProxy = false;

    if (targetSites.length === 0) {
        useProxy = true;
    } else {
        try {
            const hostname = new URL(tab.url).hostname;
            useProxy = targetSites.some(site => hostname.endsWith(`.${site}`) || hostname === site);
        } catch (e) { useProxy = false; }
    }
    chrome.action.setIcon({ path: useProxy ? "link.png" : "icon.png", tabId: tab.id });
}

// Отложенная запись статистики для снижения нагрузки
function scheduleSaveTraffic() {
    if (saveTrafficTimeout) clearTimeout(saveTrafficTimeout);
    saveTrafficTimeout = setTimeout(() => {
        chrome.storage.local.set({ trafficData });
    }, 2500); // Сохраняем раз в 2.5 секунды, если есть активность
}


// --- СЛУШАТЕЛИ СОБЫТИЙ ---
chrome.runtime.onMessage.addListener((request) => {
    if (request.action === 'apply') {
        applyProxy(request.settings);
    } else if (request.action === 'disable') {
        disableProxy();
    } else if (request.action === 'resetStats') {
        trafficData = {};
        chrome.storage.local.set({ trafficData: {} });
    }
});

chrome.tabs.onActivated.addListener(activeInfo => {
    updateActiveTabIcon();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    // Реагируем на изменение URL для мгновенной смены иконки
    if (tab.active && changeInfo.url) {
        updateIconForTab(tab);
    }
});

chrome.webRequest.onCompleted.addListener(
    (details) => {
        if (!cachedState.isConnected || details.tabId < 0 || details.fromCache) return;
        
        const targetSites = cachedState.expandedTargetSites;
        let useProxy = false;
        
        try {
            const hostname = new URL(details.url).hostname;
            useProxy = (targetSites.length === 0) || targetSites.some(site => hostname.endsWith(`.${site}`) || hostname === site);
        } catch (e) { return; }

        if (useProxy) {
            const bytesHeader = details.responseHeaders?.find(h => h.name.toLowerCase() === 'content-length');
            const bytes = bytesHeader ? parseInt(bytesHeader.value, 10) : 0;
            
            if (bytes > 0) {
                chrome.tabs.get(details.tabId, (tab) => {
                    if (chrome.runtime.lastError || !tab || !tab.url) return;
                    try {
                        const mainHostname = new URL(tab.url).hostname;
                        trafficData[mainHostname] = (trafficData[mainHostname] || 0) + bytes;
                        scheduleSaveTraffic();
                    } catch (e) { /* Игнорируем невалидные URL */ }
                });
            }
        }
    },
    { urls: ["<all_urls>"] },
    ["responseHeaders"]
);