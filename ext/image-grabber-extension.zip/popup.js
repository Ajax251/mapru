// popup.js

let allImages = [];
let filteredImages = [];
let selectedUrls = new Set();
let pageTitle = '';
let currentFilter = 'all';
let minSize = 0;
let convertFormat = 'original'; // 'original' | 'jpg' | 'png'
let jpgQuality = 0.80;

const grid = document.getElementById('image-grid');
const counter = document.getElementById('counter');
const btnZip = document.getElementById('btn-zip');
const btnAll = document.getElementById('btn-all');
const btnDlSelected = document.getElementById('btn-dl-selected');
const selCount = document.getElementById('sel-count');
const toast = document.getElementById('toast');
const fmtHint = document.getElementById('fmt-hint');
const qualityWrap = document.getElementById('quality-wrap');

function showToast(msg, isError = false) {
  toast.textContent = msg;
  toast.className = 'show' + (isError ? ' error' : '');
  setTimeout(() => toast.className = '', 2500);
}

// ── Format toggle ──────────────────────────────────────────────────────────
document.querySelectorAll('.fmt-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.fmt-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    convertFormat = btn.dataset.fmt;
    qualityWrap.style.display = convertFormat === 'jpg' ? 'flex' : 'none';
    fmtHint.textContent = convertFormat === 'original'
      ? 'без конвертации'
      : convertFormat === 'jpg'
      ? 'конвертация в JPEG'
      : 'конвертация в PNG';
  });
});

document.getElementById('jpg-quality').addEventListener('change', e => {
  jpgQuality = parseFloat(e.target.value);
});

// ── Filename helpers ───────────────────────────────────────────────────────

const MIME_TO_EXT = {
  'image/jpeg': 'jpg', 'image/jpg': 'jpg',
  'image/png': 'png', 'image/gif': 'gif',
  'image/webp': 'webp', 'image/svg+xml': 'svg',
  'image/avif': 'avif', 'image/bmp': 'bmp',
  'image/tiff': 'tiff',
};

const IMG_EXTS = new Set(['jpg','jpeg','png','gif','webp','svg','avif','bmp','tiff','ico']);

/** Get extension from URL path, fallback to mime, fallback to jpg */
function extFromUrl(url) {
  try {
    const pathname = new URL(url).pathname;
    const last = pathname.split('/').pop().split('?')[0].split('#')[0];
    const dot = last.lastIndexOf('.');
    if (dot !== -1) {
      const e = last.slice(dot + 1).toLowerCase();
      if (IMG_EXTS.has(e)) return e;
    }
  } catch {}
  return null;
}

function targetExt(originalExt) {
  if (convertFormat === 'jpg') return 'jpg';
  if (convertFormat === 'png') return 'png';
  return originalExt || 'jpg';
}

function buildFilename(url, index, ext) {
  try {
    const u = new URL(url);
    const parts = u.pathname.split('/');
    let base = parts[parts.length - 1] || '';
    base = base.split('?')[0].split('#')[0];
    // strip existing extension
    const dot = base.lastIndexOf('.');
    if (dot !== -1) base = base.slice(0, dot);
    base = base.replace(/[^a-z0-9_\-]/gi, '_').slice(0, 60);
    if (!base) base = `image_${String(index).padStart(3, '0')}`;
    return `${base}.${ext}`;
  } catch {
    return `image_${String(index).padStart(3, '0')}.${ext}`;
  }
}

// ── Init ───────────────────────────────────────────────────────────────────
async function init() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
    } catch {}
    const response = await chrome.tabs.sendMessage(tab.id, { action: 'getImages' });
    allImages = response.images || [];
    pageTitle = response.pageTitle || 'images';
    applyFilters();
  } catch (e) {
    grid.innerHTML = `<div class="state" style="grid-column:1/-1">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
        <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
      </svg>
      <p>Нет доступа к странице</p>
      <small>Перезагрузите страницу и попробуйте снова</small>
    </div>`;
    counter.textContent = 'ошибка';
  }
}

function applyFilters() {
  minSize = parseInt(document.getElementById('min-size').value) || 0;
  filteredImages = allImages.filter(img => {
    const w = img.width || 0, h = img.height || 0;
    if (minSize > 0 && (w < minSize && h < minSize)) return false;
    if (currentFilter === 'large') return w >= 400 || h >= 400;
    if (currentFilter === 'medium') return (w >= 100 && w < 400) || (h >= 100 && h < 400);
    return true;
  });
  renderGrid();
}

function renderGrid() {
  counter.textContent = `${filteredImages.length} фото`;

  if (filteredImages.length === 0) {
    grid.innerHTML = `<div class="state" style="grid-column:1/-1">
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
        <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>
        <polyline points="21 15 16 10 5 21"/>
      </svg>
      <p>Картинки не найдены</p>
      <small>Попробуйте изменить фильтры</small>
    </div>`;
    btnZip.disabled = true; btnAll.disabled = true;
    return;
  }

  btnZip.disabled = false; btnAll.disabled = false;

  grid.innerHTML = filteredImages.map((img, i) => {
    const isSelected = selectedUrls.has(img.url);
    const sizeLabel = img.width && img.height ? `${img.width}×${img.height}` : '';
    return `
      <div class="img-card ${isSelected ? 'selected' : ''}" data-url="${escHtml(img.url)}" data-index="${i}">
        <img src="${escHtml(img.url)}" loading="lazy" onerror="this.parentElement.style.display='none'" alt="${escHtml(img.alt)}">
        <div class="overlay">
          <button class="dl-btn" data-url="${escHtml(img.url)}" data-index="${i}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            Скачать
          </button>
          ${sizeLabel ? `<span class="img-size">${sizeLabel}</span>` : ''}
        </div>
        <div class="check-mark">
          <svg viewBox="0 0 12 12" fill="none" stroke="white" stroke-width="2">
            <polyline points="2 6 5 9 10 3"/>
          </svg>
        </div>
      </div>`;
  }).join('');

  updateSelCount();

  grid.querySelectorAll('.img-card').forEach(card => {
    card.addEventListener('click', e => {
      if (e.target.closest('.dl-btn')) return;
      const url = card.dataset.url;
      if (selectedUrls.has(url)) { selectedUrls.delete(url); card.classList.remove('selected'); }
      else { selectedUrls.add(url); card.classList.add('selected'); }
      updateSelCount();
    });
  });

  grid.querySelectorAll('.dl-btn').forEach(btn => {
    btn.addEventListener('click', async e => {
      e.stopPropagation();
      const url = btn.dataset.url;
      const index = parseInt(btn.dataset.index) + 1;
      await downloadOne(url, index);
      showToast('Загрузка…');
    });
  });
}

function updateSelCount() {
  const n = selectedUrls.size;
  selCount.textContent = n;
  btnDlSelected.disabled = n === 0;
}

function escHtml(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ── Download helpers ───────────────────────────────────────────────────────

async function downloadOne(url, index) {
  if (convertFormat === 'original') {
    // Just pass URL + let background figure out extension
    const origExt = extFromUrl(url);
    const ext = targetExt(origExt);
    const filename = buildFilename(url, index, ext);
    chrome.runtime.sendMessage({ action: 'downloadSingle', url, filename });
  } else {
    // Convert in popup context (canvas access)
    try {
      const blob = await convertImage(url, convertFormat, jpgQuality);
      const ext = convertFormat === 'jpg' ? 'jpg' : 'png';
      const filename = buildFilename(url, index, ext);
      const dataUrl = await blobToDataUrl(blob);
      chrome.runtime.sendMessage({ action: 'downloadDataUrl', dataUrl, filename });
    } catch {
      // fallback: download original
      const origExt = extFromUrl(url) || 'jpg';
      const filename = buildFilename(url, index, origExt);
      chrome.runtime.sendMessage({ action: 'downloadSingle', url, filename });
    }
  }
}

function convertImage(url, fmt, quality) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;
      const ctx = canvas.getContext('2d');
      if (fmt === 'jpg') {
        // fill white background for JPG (no transparency)
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }
      ctx.drawImage(img, 0, 0);
      const mimeType = fmt === 'jpg' ? 'image/jpeg' : 'image/png';
      canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('Canvas toBlob failed')),
        mimeType, quality);
    };
    img.onerror = reject;
    img.src = url;
  });
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = reject;
    r.readAsDataURL(blob);
  });
}

// ── Buttons ────────────────────────────────────────────────────────────────

document.querySelectorAll('.filter-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
    chip.classList.add('active');
    currentFilter = chip.dataset.filter;
    applyFilters();
  });
});

document.getElementById('min-size').addEventListener('change', applyFilters);

btnZip.addEventListener('click', () => {
  btnZip.disabled = true;
  btnZip.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="width:13px;height:13px;animation:spin 0.7s linear infinite"><path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4"/></svg> Создаю ZIP…`;
  chrome.runtime.sendMessage(
    { action: 'downloadZip', images: filteredImages, pageTitle, convertFormat, jpgQuality },
    res => {
      btnZip.disabled = false;
      btnZip.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" style="width:13px;height:13px"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Скачать ZIP`;
      if (res?.success) showToast(`ZIP готов — ${filteredImages.length} фото`);
      else showToast('Ошибка: ' + (res?.error || 'неизвестно'), true);
    }
  );
});

btnAll.addEventListener('click', () => {
  filteredImages.forEach((img, i) => {
    setTimeout(() => downloadOne(img.url, i + 1), i * 120);
  });
  showToast(`Загружаю ${filteredImages.length} файлов…`);
});

btnDlSelected.addEventListener('click', () => {
  const toDownload = filteredImages.filter(img => selectedUrls.has(img.url));
  toDownload.forEach((img, i) => {
    setTimeout(() => downloadOne(img.url, i + 1), i * 120);
  });
  showToast(`Загружаю ${toDownload.length} выбранных…`);
});

init();
