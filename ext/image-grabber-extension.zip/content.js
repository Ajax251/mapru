// content.js — runs in the context of the active tab

function getPageImages() {
  const seen = new Set();
  const images = [];

  // 1. <img> tags
  document.querySelectorAll('img').forEach(img => {
    const src = img.currentSrc || img.src;
    if (src && !seen.has(src)) {
      seen.add(src);
      images.push({
        url: src,
        alt: img.alt || '',
        width: img.naturalWidth || img.width || 0,
        height: img.naturalHeight || img.height || 0,
        type: 'img'
      });
    }
  });

  // 2. CSS background-image
  document.querySelectorAll('*').forEach(el => {
    const style = window.getComputedStyle(el);
    const bg = style.backgroundImage;
    if (bg && bg !== 'none') {
      const match = bg.match(/url\(["']?([^"')]+)["']?\)/g);
      if (match) {
        match.forEach(m => {
          const url = m.replace(/url\(["']?/, '').replace(/["']?\)$/, '').trim();
          if (url && !url.startsWith('data:') && !seen.has(url)) {
            seen.add(url);
            const abs = new URL(url, location.href).href;
            if (!seen.has(abs)) {
              seen.add(abs);
              images.push({ url: abs, alt: '', width: 0, height: 0, type: 'bg' });
            }
          }
        });
      }
    }
  });

  // 3. <source> inside <picture>
  document.querySelectorAll('picture source').forEach(s => {
    const srcset = s.srcset;
    if (srcset) {
      srcset.split(',').forEach(part => {
        const url = part.trim().split(/\s+/)[0];
        if (url && !seen.has(url)) {
          seen.add(url);
          images.push({ url: url, alt: '', width: 0, height: 0, type: 'source' });
        }
      });
    }
  });

  // Resolve relative URLs and filter empty
  return images
    .map(img => {
      try {
        img.url = new URL(img.url, location.href).href;
        return img;
      } catch {
        return null;
      }
    })
    .filter(Boolean);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'getImages') {
    sendResponse({ images: getPageImages(), pageTitle: document.title });
  }
});
