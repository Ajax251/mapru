// background.js

importScripts('jszip.min.js');

const MIME_TO_EXT = {
  'image/jpeg': 'jpg', 'image/jpg': 'jpg',
  'image/png': 'png', 'image/gif': 'gif',
  'image/webp': 'webp', 'image/svg+xml': 'svg',
  'image/avif': 'avif', 'image/bmp': 'bmp',
  'image/tiff': 'tiff',
};

const IMG_EXTS = new Set(['jpg','jpeg','png','gif','webp','svg','avif','bmp','tiff','ico']);

function extFromUrl(url) {
  try {
    const pathname = new URL(url).pathname;
    const last = pathname.split('/').pop().split('?')[0].split('#')[0];
    const dot = last.lastIndexOf('.');
    if (dot !== -1) {
      const e = last.slice(dot + 1).toLowerCase();
      if (IMG_EXTS.has(e)) return e;
    }
  } catch {}
  return null;
}

function extFromMime(mime) {
  if (!mime) return null;
  const base = mime.split(';')[0].trim().toLowerCase();
  return MIME_TO_EXT[base] || null;
}

/** Build clean filename with guaranteed extension */
function buildFilename(url, index, forcedExt) {
  try {
    const u = new URL(url);
    const parts = u.pathname.split('/');
    let base = parts[parts.length - 1] || '';
    base = base.split('?')[0].split('#')[0];
    const dot = base.lastIndexOf('.');
    if (dot !== -1) base = base.slice(0, dot);
    base = base.replace(/[^a-z0-9_\-]/gi, '_').slice(0, 60);
    if (!base) base = `image_${String(index).padStart(3, '0')}`;
    return `${base}.${forcedExt}`;
  } catch {
    return `image_${String(index).padStart(3, '0')}.${forcedExt}`;
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === 'downloadSingle') {
    // msg.filename already has extension set by popup
    chrome.downloads.download({ url: msg.url, filename: msg.filename, saveAs: false });
    sendResponse({ success: true });
    return true;
  }

  if (msg.action === 'downloadDataUrl') {
    // converted image as data URL
    chrome.downloads.download({ url: msg.dataUrl, filename: msg.filename, saveAs: false });
    sendResponse({ success: true });
    return true;
  }

  if (msg.action === 'downloadZip') {
    downloadAllAsZip(msg.images, msg.pageTitle, msg.convertFormat, msg.jpgQuality)
      .then(() => sendResponse({ success: true }))
      .catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }
});

async function downloadAllAsZip(images, pageTitle, convertFormat, jpgQuality) {
  const zip = new JSZip();
  const folder = zip.folder('images');
  let count = 0;

  const promises = images.map(async (img, i) => {
    try {
      const res = await fetch(img.url);
      if (!res.ok) return;
      const contentType = res.headers.get('content-type') || '';
      const mimeExt = extFromMime(contentType);
      const urlExt = extFromUrl(img.url);
      const origExt = urlExt || mimeExt || 'jpg';

      let blob = await res.blob();
      let finalExt = origExt;

      // Note: canvas-based conversion isn't available in service worker,
      // so for zip we keep the original blob but rename with correct ext.
      // (Conversion for zip happens only if popup pre-converted via downloadDataUrl)
      if (convertFormat !== 'original') {
        finalExt = convertFormat === 'jpg' ? 'jpg' : 'png';
      }

      const filename = `${String(i + 1).padStart(3, '0')}_${buildFilename(img.url, i + 1, finalExt)}`;
      folder.file(filename, blob);
      count++;
    } catch {
      // skip inaccessible
    }
  });

  await Promise.all(promises);
  if (count === 0) throw new Error('Не удалось загрузить ни одной картинки');

  const content = await zip.generateAsync({ type: 'blob' });
  const dataUrl = await blobToDataUrl(content);
  const safeName = (pageTitle || 'images').replace(/[^a-z0-9]/gi, '_').slice(0, 40);

  await chrome.downloads.download({
    url: dataUrl,
    filename: `${safeName}_images.zip`,
    saveAs: false
  });
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}
