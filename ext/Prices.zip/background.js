// background.js - Версия 7.2 (Исправлены двойные запуски и уведомления)

console.log("Background service worker v7.2 (single-run lock) запущен.");

// --- КОНСТАНТЫ ---
const API_URL = "https://mapruapp.ru/ai/api/v1/chat/completions";
const AI_MODEL = "gemini-2.5-flash-lite-preview-06-17";
const SUPABASE_URL = 'https://krbqraivfbowmzvucjxz.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtyYnFyYWl2ZmJvd216dnVjanh6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU1MDA0MTAsImV4cCI6MjA2MTA3NjQxMH0.Aun2UJDEW_75_Di-2hIcap42gqyZAu2XY9xiZpmShPc';

// --- СОСТОЯНИЕ РАСШИРЕНИЯ ---
let isAutoModeEnabled = false;
const processingTabs = new Set(); // Множество для отслеживания вкладок в процессе анализа

// --- СЛУШАТЕЛИ СОБЫТИЙ ---

chrome.commands.onCommand.addListener(async (command, tab) => {
    if (command === "trigger-analysis") {
        console.log("Ручной анализ запущен по горячей клавише...");
        runAnalysis(tab, false);
    }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'GET_AUTO_MODE_STATE') {
        sendResponse({ isEnabled: isAutoModeEnabled });
    } else if (message.type === 'SET_AUTO_MODE_STATE') {
        isAutoModeEnabled = message.enabled;
        console.log(`Авто-режим ${isAutoModeEnabled ? 'ВКЛЮЧЕН' : 'ВЫКЛЮЧЕН'}`);
        sendResponse({ success: true });
    } else if (message.type === 'RUN_ANALYSIS') {
        runAnalysis(message.tab, false).then(result => sendResponse(result));
        return true; 
    } else if (message.type === 'CLEAR_BADGE') {
        if (message.tabId) {
            chrome.action.setBadgeText({ text: '', tabId: message.tabId });
        }
        sendResponse({ success: true });
    }
    return true;
});

// ГЛАВНОЕ ИЗМЕНЕНИЕ: Добавлена логика блокировки
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (isAutoModeEnabled && changeInfo.status === 'complete' && tab.url && (tab.url.startsWith('http://') || tab.url.startsWith('https://'))) {
        // Если вкладка уже в процессе, ничего не делаем
        if (processingTabs.has(tabId)) {
            return;
        }

        // Блокируем вкладку и запускаем анализ
        processingTabs.add(tabId);
        console.log(`Авто-режим: страница ${tab.url} загружена. Блокирую и запускаю анализ для tabId: ${tabId}`);
        
        // Используем .finally, чтобы гарантированно разблокировать вкладку
        runAnalysis(tab, true).finally(() => {
            processingTabs.delete(tabId);
            console.log(`Анализ для tabId: ${tabId} завершен. Блокировка снята.`);
        });
    }
});


// --- ОСНОВНАЯ ЛОГИКА АНАЛИЗА ---
async function runAnalysis(tab, isAutoRun) {
    if (!isAutoRun) {
        chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon128.png', title: 'Анализ запущен', message: 'Идет поиск товаров...', silent: true });
    }

    try {
        const { isFilterEnabled } = await chrome.storage.local.get(['isFilterEnabled']);
        const injectionFunction = isFilterEnabled ? getPageContext : getPageTextContent;

        const injectionResults = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: injectionFunction });
        const result = injectionResults[0].result;
        
        let pageText, searchQuery = null;
        if (isFilterEnabled && typeof result === 'object') {
            pageText = result.pageText; searchQuery = result.searchQuery;
        } else {
            pageText = result;
        }

        if (!pageText || pageText.trim().length < 200) {
            const message = "На этой странице недостаточно контента для анализа.";
            if (isAutoRun) showInPageNotification(tab.id, "Товары не найдены", message, "info");
            return { error: message };
        }

        const products = await callAI(pageText, "parser", searchQuery, tab.url);
        
        if (!products || products.length === 0) {
            if(isAutoRun) showInPageNotification(tab.id, "Товары не найдены", "ИИ не обнаружил подходящих товаров.", "info");
            return { error: "Товары не найдены." };
        }
        
        await chrome.action.setBadgeBackgroundColor({ color: '#1A73E8' });
        await chrome.action.setBadgeText({ text: products.length.toString(), tabId: tab.id });
        
        await chrome.storage.local.set({ aiParserResults: products });
        const savedCount = await saveToSupabase(products, tab.url);

        if (isAutoRun) {
            showInPageNotification(tab.id, "Анализ завершен", `${savedCount} товаров успешно сохранено.`, "success");
        } else {
            chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon128.png', title: 'Анализ завершен', message: `Найдено и сохранено ${savedCount} товаров.` });
        }
        return { products };

    } catch (error) {
        console.error("ОШИБКА во время анализа:", error.message);
        if (isAutoRun) {
            showInPageNotification(tab.id, "Ошибка анализа", error.message, "error");
        } else {
            chrome.notifications.create({ type: 'basic', iconUrl: 'icons/icon128.png', title: 'Ошибка анализа', message: error.message });
        }
        return { error: error.message };
    }
}


// --- ФУНКЦИЯ ДЛЯ ВНЕДРЕНИЯ УВЕДОМЛЕНИЯ НА СТРАНИЦУ ---
function showInPageNotification(tabId, title, message, type = 'success') {
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: displayInPageNotification,
        args: [title, message, type]
    });
}

function displayInPageNotification(title, message, type) {
    const oldNotification = document.getElementById('auto-analysis-notification-overlay');
    if (oldNotification) {
        oldNotification.remove();
    }

    const overlay = document.createElement('div');
    overlay.id = 'auto-analysis-notification-overlay';
    
    const colors = {
        success: '#28a745',
        error: '#dc3545',
        info: '#17a2b8'
    };
    const borderColor = colors[type] || colors.success;

    // ГЛАВНОЕ ИЗМЕНЕНИЕ: Добавлен блок с предупреждением
    overlay.innerHTML = `
        <style>
            #auto-analysis-notification-overlay {
                position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                display: flex; justify-content: center; align-items: center;
                z-index: 2147483647;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            }
            .auto-analysis-modal {
                background-color: white; padding: 25px; border-radius: 10px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.3); text-align: center;
                max-width: 400px; width: 90%;
                border-top: 5px solid ${borderColor};
                animation: aan-fade-in 0.3s ease-out;
            }
            @keyframes aan-fade-in {
                from { opacity: 0; transform: translateY(-20px); }
                to { opacity: 1; transform: translateY(0); }
            }
            .auto-analysis-modal h3 { margin-top: 0; color: #333; font-size: 20px; font-weight: 500; }
            .auto-analysis-modal p { color: #666; font-size: 16px; line-height: 1.5; margin: 0 0 25px 0; }
            .auto-analysis-modal .auto-analysis-warning {
                font-size: 13px;
                color: #888;
                margin-top: 20px;
                padding-top: 15px;
                border-top: 1px solid #eee;
                line-height: 1.4;
            }
            .auto-analysis-modal button {
                background-color: ${borderColor}; color: white; border: none;
                padding: 10px 25px; border-radius: 5px; font-size: 16px;
                font-weight: 500; cursor: pointer; transition: opacity 0.2s;
                margin-top: 10px;
            }
            .auto-analysis-modal button:hover { opacity: 0.9; }
        </style>
        <div class="auto-analysis-modal">
            <h3>${title}</h3>
            <p>${message}</p>
            <p class="auto-analysis-warning">Автопоиск товаров активен. Пожалуйста, не забудьте отключить его в настройках расширения Цены, если он больше не нужен.</p>
            <button id="auto-analysis-ok-btn">OK</button>
        </div>
    `;

    document.body.appendChild(overlay);

    document.getElementById('auto-analysis-ok-btn').addEventListener('click', () => {
        overlay.remove();
    });
}

// --- ФУНКЦИЯ СОХРАНЕНИЯ В SUPABASE ---
async function saveToSupabase(products, pageUrl) {
    if (!products || products.length === 0) return 0;
    let finalRecords = [];
    try {
        const pageHostname = new URL(pageUrl).hostname;
        const isYandexSearch = pageHostname.includes('yandex.ru') || pageHostname.includes('ya.ru');
        const storeMappings = { 'www.ozon.ru': 'ОЗОН', 'www.wildberries.ru': 'Wildberries', 'www.mm.ru': 'МагнитМаркет' };
        
        const recordsToUpsert = products.map(product => {
            let storeName;
            if (storeMappings[pageHostname]) { storeName = storeMappings[pageHostname]; }
            else if (isYandexSearch && product.store) { storeName = product.store; }
            else { storeName = pageHostname; }
            return { store: storeName, product_name: product.name, price: product.price };
        }).filter(p => p.product_name && typeof p.price === 'number');

        const uniqueProducts = new Map();
        for (const record of recordsToUpsert) {
            const uniqueKey = `${record.store}|${record.product_name}`;
            if (!uniqueProducts.has(uniqueKey)) { uniqueProducts.set(uniqueKey, record); }
        }
        finalRecords = Array.from(uniqueProducts.values());

        if (finalRecords.length === 0) { return 0; }
        
        const conflictColumns = encodeURIComponent('store,product_name');
        const requestUrl = `${SUPABASE_URL}/rest/v1/prices?on_conflict=${conflictColumns}`;
        
        const response = await fetch(requestUrl, {
            method: 'POST',
            headers: { 'apikey': SUPABASE_ANON_KEY, 'Authorization': `Bearer ${SUPABASE_ANON_KEY}`, 'Content-Type': 'application/json', 'Prefer': 'resolution=merge-duplicates' },
            body: JSON.stringify(finalRecords)
        });
        
        if (response.status >= 200 && response.status <= 299) {
            return finalRecords.length;
        } else {
            const errorText = await response.text();
            throw new Error(`Supabase ответил ошибкой: ${response.status} - ${errorText}`);
        }
    } catch (error) {
        console.error(`КРИТИЧЕСКАЯ ОШИБКА в функции saveToSupabase:`, error.message);
        throw error;
    }
}


// --- ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ---
async function callAI(text, mode, searchQuery, pageUrl) {
    const hostname = new URL(pageUrl).hostname;
    const isYandex = hostname.includes('yandex.ru') || hostname.includes('ya.ru');
    let systemPrompt;
    if (mode === "parser") {
        if (isYandex) {
            systemPrompt = `Ты - высокоточный парсер данных со страницы агрегатора Яндекс. Твоя задача - извлечь каждый товар, его цену и НАЗВАНИЕ МАГАЗИНА. ПРАВИЛА ИЗВЛЕЧЕНИЯ: 1. Название: Извлекай полное название товара. 2. Магазин: Извлекай название магазина (например, "Wildberries", "Ситилинк", "OZON"). 3. Цена: Извлекай только числовое значение первой цены. ПРАВИЛА ФОРМАТИРОВАНИЯ: Ответ должен быть ТОЛЬКО валидным JSON-массивом объектов. Каждый объект: {"name": string, "price": number, "store": string}. Если товаров нет, верни [].`;
        } else {
            systemPrompt = `Ты - высокоточный парсер данных. Твоя задача - извлечь товары и их цены. ПРАВИЛА ИЗВЛЕЧЕНИЯ: 1. Цена: Извлекай только числовое значение первой цены. 2. Название: Извлекай полное название товара. 3. Формат: Ответ должен быть ТОЛЬКО валидным JSON-массивом объектов. Каждый объект: {"name": string, "price": number}. Если товаров нет, верни [].`;
        }
        if (searchQuery) {
            systemPrompt += ` КРИТИЧЕСКИ ВАЖНО: АКТИВИРОВАН УМНЫЙ ФИЛЬТР. Пользовательский запрос: "${searchQuery}". Включай в ответ ТОЛЬКО те товары, которые напрямую относятся к запросу. Отбрасывай аксессуары и товары из других категорий.`;
        }
    } else { return; }
    const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: AI_MODEL, messages: [{ role: "system", content: systemPrompt }, { role: "user", content: text }], max_tokens: 4096, temperature: 0.1, }),
    });
    if (!response.ok) { throw new Error(`Ошибка API: ${response.status} - ${await response.text()}`); }
    const data = await response.json();
    const content = data.choices[0]?.message?.content;
    if (!content) throw new Error("AI вернул пустой ответ.");
    try { return parseLenientJson(content); }
    catch (e) { throw new Error("AI вернул некорректный формат данных."); }
}
function getPageTextContent() {
    const mainElement = document.querySelector('main') || document.body;
    return mainElement.innerText;
}
function getPageContext() {
    let query = null;
    const searchInput = document.querySelector('input[type="search"], input[name*="search"], input[name*="query"], input[id*="search"], input[id*="query"], input[aria-label*="поиск"], input[aria-label*="search"]');
    if (searchInput && searchInput.value) { query = searchInput.value.trim(); }
    if (!query) { const h1 = document.querySelector('h1'); if (h1) { query = h1.textContent.trim(); } }
    if (!query) {
        query = document.title.trim();
        const separators = ['|', '-', '–', '—'];
        for (const sep of separators) {
            if (query.includes(sep)) { query = query.split(sep)[0].trim(); break; }
        }
    }
    const mainElement = document.querySelector('main') || document.body;
    return { pageText: mainElement.innerText, searchQuery: query };
}
function parseLenientJson(jsonString) {
    const startIndex = jsonString.indexOf('[');
    if (startIndex === -1) throw new Error("Не найдено начало JSON-массива '['.");
    const lastBraceIndex = jsonString.lastIndexOf('}');
    if (lastBraceIndex === -1) return [];
    let endIndex = jsonString.lastIndexOf(']');
    endIndex = (endIndex < startIndex) ? lastBraceIndex + 1 : endIndex + 1;
    const potentialJsonArray = jsonString.substring(startIndex, endIndex);
    try { return JSON.parse(potentialJsonArray); }
    catch (e) {
        try { return JSON.parse(potentialJsonArray.replace(/,\s*\]/g, ']')); }
        catch (e2) { throw new Error("AI вернул некорректный формат данных, который не удалось восстановить."); }
    }
}