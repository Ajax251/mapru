// popup.js - Версия 7.1 (Полная, с рабочими кнопками)

// --- КОНСТАНТЫ API и Supabase ---
const API_URL = "https://mapruapp.ru/ai/api/v1/chat/completions";
const AI_MODEL = "gemini-2.5-flash-lite-preview-06-17";

// --- Элементы DOM ---
const mainContent = document.getElementById('mainContent');
const analyzeBtn = document.getElementById('analyzeBtn');
const loader = document.getElementById('loader');
const resultsDiv = document.getElementById('results');
const statusText = document.getElementById('statusText');
const minPriceEl = document.getElementById('minPrice');
const avgPriceEl = document.getElementById('avgPrice');
const maxPriceEl = document.getElementById('maxPrice');
const productCountEl = document.getElementById('productCount');
const productListUl = document.getElementById('productList');
const copyBtn = document.getElementById('copyBtn');
const csvBtn = document.getElementById('csvBtn');
const xlsxBtn = document.getElementById('xlsxBtn');
const resetBtn = document.getElementById('resetBtn');
const priceQualityBtn = document.getElementById('priceQualityBtn');
const adviceModal = document.getElementById('adviceModal');
const modalCloseBtn = document.getElementById('modalCloseBtn');
const adviceContent = document.getElementById('adviceContent');
const filterToggle = document.getElementById('filterToggle');
const autoModeToggle = document.getElementById('autoModeToggle');
const dbStatusEl = document.getElementById('dbStatus');

let currentProducts = [];

// --- ИНИЦИАЛИЗАЦИЯ ---
document.addEventListener('DOMContentLoaded', () => {
    chrome.storage.local.get(['isFilterEnabled'], (settings) => {
        filterToggle.checked = !!settings.isFilterEnabled;
    });

    chrome.runtime.sendMessage({ type: 'GET_AUTO_MODE_STATE' }, (response) => {
        if (chrome.runtime.lastError) {
            console.warn("Не удалось получить состояние авто-режима:", chrome.runtime.lastError.message);
            return;
        }
        if (response) {
            autoModeToggle.checked = response.isEnabled;
        }
    });

    chrome.storage.local.get(['aiParserResults'], (data) => {
        if (data.aiParserResults && data.aiParserResults.length > 0) {
            displayResults(data.aiParserResults);
        } else {
            showView('mainContent');
        }
    });
});

// --- СЛУШАТЕЛИ СОБЫТИЙ ---

filterToggle.addEventListener('change', () => {
    chrome.storage.local.set({ isFilterEnabled: filterToggle.checked });
});

autoModeToggle.addEventListener('change', () => {
    chrome.runtime.sendMessage({ type: 'SET_AUTO_MODE_STATE', enabled: autoModeToggle.checked });
});

analyzeBtn.addEventListener('click', async () => {
    showView('loader');
    try {
        const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
        chrome.runtime.sendMessage({ type: 'RUN_ANALYSIS', tab: activeTab, isAutoRun: false }, (response) => {
            if (chrome.runtime.lastError) {
                displayError(`Ошибка связи: ${chrome.runtime.lastError.message}`);
                return;
            }
            if (response && response.products) {
                 chrome.storage.local.set({ aiParserResults: response.products });
                 displayResults(response.products);
            } else if (response && response.error) {
                 displayError(response.error);
            } else {
                 displayError("Неожиданный ответ от фонового скрипта.");
            }
        });
    } catch (error) {
        displayError(error.message);
    }
});

// --- ИСПРАВЛЕННЫЕ И РАБОТАЮЩИЕ СЛУШАТЕЛИ ---

copyBtn.addEventListener('click', () => {
    const icon = copyBtn.querySelector('.material-symbols-outlined');
    const originalIconName = icon.textContent;
    const textToCopy = currentProducts.map(p => `${p.name}\t${p.store || ''}\t${p.price}`).join('\n');
    navigator.clipboard.writeText(textToCopy).then(() => {
        icon.textContent = 'check';
        copyBtn.classList.add('copied');
        setTimeout(() => {
            icon.textContent = originalIconName;
            copyBtn.classList.remove('copied');
        }, 2000);
    });
});

csvBtn.addEventListener('click', () => {
    let csvContent = '"Название";"Магазин";"Цена"\n';
    currentProducts.forEach(p => { 
        const store = p.store ? p.store.replace(/"/g, '""') : '';
        const name = p.name.replace(/"/g, '""');
        csvContent += `"${name}";"${store}";${p.price}\n`; 
    });
    downloadFile(csvContent, 'prices.csv', 'text/csv;charset=utf-8;');
});

xlsxBtn.addEventListener('click', () => {
    if (typeof XLSX === 'undefined') {
        alert("Ошибка: Библиотека для экспорта в XLSX не загружена.");
        return;
    }
    const dataForSheet = currentProducts.map(p => ({ 'Название': p.name, 'Магазин': p.store, 'Цена': p.price }));
    const worksheet = XLSX.utils.json_to_sheet(dataForSheet);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Цены");
    worksheet['!cols'] = [{ wch: 60 }, { wch: 20 }, { wch: 15 }];
    XLSX.writeFile(workbook, "prices_export.xlsx");
});

resetBtn.addEventListener('click', async () => {
    // 1. Очищаем хранилище
    await chrome.storage.local.remove(['aiParserResults']);
    
    // 2. Отправляем сообщение в фон для очистки счетчика
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
        chrome.runtime.sendMessage({ type: 'CLEAR_BADGE', tabId: tab.id });
    }
    
    // 3. Скрываем ненужные элементы и показываем главный экран
    priceQualityBtn.classList.add('hidden');
    showView('mainContent');
    statusText.textContent = 'Анализ цен на текущей странице.';
    statusText.style.color = 'var(--on-surface-text-secondary)';
});

priceQualityBtn.addEventListener('click', async () => {
    priceQualityBtn.disabled = true;
    priceQualityBtn.innerHTML = `<div class="spinner-inline"></div> Анализирую...`;
    try {
        const productListString = currentProducts.map(p => `- ${p.name} (${p.store || 'н/д'}) - ${p.price} ₽`).join('\n');
        
        // --- Используем fetch напрямую, так как callAI в background.js ---
        const response = await fetch(API_URL, { 
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                model: AI_MODEL,
                messages: [
                    { role: "system", content: `Ты — профессиональный маркетолог. Тебе дан список товаров и их цен. Твоя задача — дать краткую, но ёмкую рекомендацию по покупке, основываясь на соотношении "цена/качество". ПРАВИЛА: 1. Структура ответа: * Общий вывод (1-2 предл.). * Лучшее предложение: выдели 1-2 товара. * Стоит избегать: укажи, если есть, переоцененные товары. * Итог: краткий совет. 2. Стиль: Дружелюбный, экспертный. 3. Формат: Markdown (**жирный**, списки).` }, 
                    { role: "user", content: productListString }
                ],
                max_tokens: 4096,
                temperature: 0.5,
            }),
        });

        if (!response.ok) throw new Error(`Ошибка API: ${response.status}`);
        const data = await response.json();
        const advice = data.choices[0]?.message?.content;
        
        if (!advice) throw new Error("AI вернул пустой ответ.");

        const formattedAdvice = advice
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n/g, '<br>');
        adviceContent.innerHTML = formattedAdvice;
        adviceModal.classList.remove('hidden');

    } catch (error) {
        alert(`Ошибка при получении рекомендации: ${error.message}`);
    } finally {
        priceQualityBtn.disabled = false;
        priceQualityBtn.innerHTML = `<span class="material-symbols-outlined">insights</span> Цена/Качество`;
    }
});

modalCloseBtn.addEventListener('click', () => adviceModal.classList.add('hidden'));
adviceModal.addEventListener('click', (e) => {
    if (e.target === adviceModal) adviceModal.classList.add('hidden');
});

// --- ФУНКЦИИ ---
function displayResults(products) {
    if (!products || products.length === 0) {
        displayError("ИИ не смог найти товары на этой странице.");
        return;
    }
    
    currentProducts = products.filter(p => p.name && typeof p.price === 'number' && p.price > 0);
    if (currentProducts.length === 0) {
        displayError("Не удалось найти корректные данные о товарах.");
        return;
    }
    
    currentProducts.sort((a, b) => a.price - b.price);
    const prices = currentProducts.map(p => p.price);
    minPriceEl.textContent = `${Math.min(...prices).toLocaleString('ru-RU')} ₽`;
    avgPriceEl.textContent = `${Math.round(prices.reduce((s, p) => s + p, 0) / prices.length).toLocaleString('ru-RU')} ₽`;
    maxPriceEl.textContent = `${Math.max(...prices).toLocaleString('ru-RU')} ₽`;
    productCountEl.textContent = currentProducts.length;

    productListUl.innerHTML = '';
    currentProducts.forEach(product => {
        const li = document.createElement('li');
        li.className = 'product-item';
        const storeHtml = product.store ? `<span class="product-store">${product.store}</span>` : '';
        li.innerHTML = `
            <div class="product-info">
                <span class="product-name" title="${product.name}">${product.name}</span>
                ${storeHtml}
            </div>
            <span class="product-price">${product.price.toLocaleString('ru-RU')} ₽</span>`;
        productListUl.appendChild(li);
    });

    priceQualityBtn.classList.remove('hidden'); 
    showView('results');
}

function showView(viewId) {
    document.querySelectorAll('.view').forEach(view => view.classList.add('hidden'));
    document.getElementById(viewId).classList.remove('hidden');
}

function displayError(message) {
    showView('mainContent');
    statusText.textContent = `Ошибка: ${message}`;
    statusText.style.color = '#d93025';
}

function downloadFile(content, fileName, contentType) {
    const a = document.createElement("a");
    const file = new Blob(['\uFEFF' + content], { type: contentType });
    a.href = URL.createObjectURL(file);
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(a.href);
}