document.addEventListener('DOMContentLoaded', function () {
    const toggle = document.getElementById('proxyToggle');
    const serverInput = document.getElementById('server');
    const portInput = document.getElementById('port');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const schemeSelect = document.getElementById('scheme');
    const targetSitesInput = document.getElementById('targetSites');
    const statusDiv = document.getElementById('status');
    const trafficInfoDiv = document.getElementById('trafficInfo');
    const resetButton = document.getElementById('resetButton');

    const proxySelect = document.getElementById('proxySelect');
    const addProxyBtn = document.getElementById('addProxyBtn');
    const deleteProxyBtn = document.getElementById('deleteProxyBtn');
    const importBtn = document.getElementById('importBtn');
    const exportBtn = document.getElementById('exportBtn');
    const fileInput = document.getElementById('fileInput');

    let proxyList = [];

    // ── Утилиты ────────────────────────────────────────────────────────────
    function showStatus(message, type = 'error') {
        statusDiv.textContent = message;
        statusDiv.className = type === 'success' ? 'status-success' : 'status-error';
        setTimeout(() => { statusDiv.textContent = ''; statusDiv.className = ''; }, 4000);
    }

    function formatBytes(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    function updateTrafficInfo() {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (!tabs[0] || !tabs[0].url) { trafficInfoDiv.textContent = 'N/A'; return; }
            try {
                const hostname = new URL(tabs[0].url).hostname;
                chrome.storage.local.get('trafficData', (data) => {
                    trafficInfoDiv.textContent = formatBytes((data.trafficData || {})[hostname] || 0);
                });
            } catch (e) { trafficInfoDiv.textContent = 'N/A'; }
        });
    }

    // ── Парсинг строки прокси ──────────────────────────────────────────────
    // Поддерживает форматы:
    //   host:port
    //   host:port:user:pass
    //   scheme://host:port
    //   scheme://user:pass@host:port
    function parseProxyString(str) {
        str = str.trim();
        if (!str) return null;

        let scheme = 'http', host, port, username = '', password = '';

        const schemeMatch = str.match(/^(https?|socks[45]):\/\/(.*)/i);
        if (schemeMatch) {
            scheme = schemeMatch[1].toLowerCase();
            str = schemeMatch[2];
        }

        if (str.includes('@')) {
            const [auth, hostpart] = str.split('@');
            const authParts = auth.split(':');
            username = authParts[0] || '';
            password = authParts.slice(1).join(':');
            str = hostpart;
        }

        const parts = str.split(':');
        if (parts.length >= 2) {
            host = parts[0];
            port = parseInt(parts[1], 10);
            // формат host:port:user:pass (без схемы и без @)
            if (!username && parts.length >= 4) {
                username = parts[2];
                password = parts.slice(3).join(':');
            }
        } else {
            return null;
        }

        if (!host || isNaN(port) || port < 1 || port > 65535) return null;
        return { address: `${host}:${port}`, host, port, username, password, scheme };
    }

    // ── Список прокси ──────────────────────────────────────────────────────
    function renderProxySelect(selectedIndex) {
        proxySelect.innerHTML = '';
        if (proxyList.length === 0) {
            const opt = document.createElement('option');
            opt.value = ''; opt.textContent = 'Нет сохранённых прокси'; opt.disabled = true;
            proxySelect.appendChild(opt);
            proxySelect.value = '';
        } else {
            proxyList.forEach((p, i) => {
                const opt = document.createElement('option');
                opt.value = i;
                opt.textContent = `${p.address} (${p.scheme.toUpperCase()})${p.username ? ' 🔒' : ''}`;
                proxySelect.appendChild(opt);
            });
            const idx = (selectedIndex >= 0 && selectedIndex < proxyList.length) ? selectedIndex : 0;
            proxySelect.value = idx;
            fillFormFromProxy(proxyList[idx]);
        }
    }

    function fillFormFromProxy(p) {
        if (!p) return;
        serverInput.value = p.host || '';
        portInput.value = p.port || '';
        schemeSelect.value = p.scheme || 'http';
        usernameInput.value = p.username || '';
        passwordInput.value = p.password || '';
    }

    function collectSettings() {
        return {
            scheme: schemeSelect.value,
            server: serverInput.value.trim(),
            port: portInput.value.trim(),
            username: usernameInput.value.trim(),
            password: passwordInput.value.trim(),
            targetSites: targetSitesInput.value.trim()
        };
    }

    // ── Инициализация из хранилища ─────────────────────────────────────────
    chrome.storage.sync.get(['proxyList', 'proxySettings', 'isConnected'], function (data) {
        proxyList = data.proxyList || [];

        let selectedIndex = 0;
        if (data.proxySettings && data.proxySettings.server) {
            const activeAddr = `${data.proxySettings.server}:${data.proxySettings.port}`;
            const found = proxyList.findIndex(p => p.address === activeAddr);
            if (found >= 0) selectedIndex = found;
        }

        renderProxySelect(selectedIndex);

        // Восстанавливаем targetSites из сохранённых настроек
        if (data.proxySettings) {
            targetSitesInput.value = data.proxySettings.targetSites || '';
        }

        toggle.checked = !!data.isConnected;
        if (toggle.checked) showStatus('Прокси активен', 'success');
        updateTrafficInfo();
    });

    // ── Переключатель вкл/выкл ─────────────────────────────────────────────
    toggle.addEventListener('change', function () {
        const settings = collectSettings();

        if (toggle.checked) {
            if (!settings.server || !settings.port) {
                toggle.checked = false;
                showStatus('Заполните поля сервера и порта', 'error');
                return;
            }
            chrome.runtime.sendMessage({ action: 'apply', settings });
            chrome.storage.sync.set({ isConnected: true, proxySettings: settings });
            showStatus('Прокси подключён', 'success');
        } else {
            chrome.runtime.sendMessage({ action: 'disable' });
            chrome.storage.sync.set({ isConnected: false });
            showStatus('Прокси отключён', 'error');
        }
    });

    // Обновляем прокси при изменении полей (если включён)
    function onFieldChange() {
        // Синхронизируем текущие данные формы с выбранным прокси в списке
        const idx = parseInt(proxySelect.value, 10);
        if (!isNaN(idx) && proxyList[idx]) {
            const [h, p] = (serverInput.value.trim() + ':' + portInput.value.trim()).split(':');
            proxyList[idx].host = serverInput.value.trim();
            proxyList[idx].port = parseInt(portInput.value.trim(), 10) || proxyList[idx].port;
            proxyList[idx].address = `${serverInput.value.trim()}:${portInput.value.trim()}`;
            proxyList[idx].scheme = schemeSelect.value;
            proxyList[idx].username = usernameInput.value.trim();
            proxyList[idx].password = passwordInput.value.trim();
        }

        const settings = collectSettings();
        chrome.storage.sync.set({ proxySettings: settings, proxyList });

        if (toggle.checked && settings.server && settings.port) {
            chrome.runtime.sendMessage({ action: 'apply', settings });
        }
    }

    serverInput.addEventListener('input', onFieldChange);
    portInput.addEventListener('input', onFieldChange);
    schemeSelect.addEventListener('change', onFieldChange);
    usernameInput.addEventListener('input', onFieldChange);
    passwordInput.addEventListener('input', onFieldChange);
    targetSitesInput.addEventListener('input', () => {
        const settings = collectSettings();
        chrome.storage.sync.set({ proxySettings: settings });
        if (toggle.checked && settings.server && settings.port) {
            chrome.runtime.sendMessage({ action: 'apply', settings });
        }
    });

    serverInput.addEventListener('keypress', e => e.key === 'Enter' && portInput.focus());
    portInput.addEventListener('keypress', e => e.key === 'Enter' && usernameInput.focus());

    // ── Добавление прокси ──────────────────────────────────────────────────
    addProxyBtn.addEventListener('click', () => {
        const settings = collectSettings();
        if (!settings.server || !settings.port) {
            showStatus('Заполните сервер и порт', 'error'); return;
        }
        const address = `${settings.server}:${settings.port}`;
        const existsIdx = proxyList.findIndex(p => p.address === address && p.username === settings.username);
        if (existsIdx !== -1) {
            renderProxySelect(existsIdx);
            showStatus('Уже в списке', 'success'); return;
        }
        proxyList.push({
            address,
            host: settings.server,
            port: parseInt(settings.port, 10),
            scheme: settings.scheme,
            username: settings.username,
            password: settings.password
        });
        renderProxySelect(proxyList.length - 1);
        chrome.storage.sync.set({ proxyList });
        showStatus('Добавлено в список', 'success');
    });

    // ── Удаление прокси ────────────────────────────────────────────────────
    deleteProxyBtn.addEventListener('click', () => {
        const idx = parseInt(proxySelect.value, 10);
        if (isNaN(idx) || !proxyList[idx]) return;
        proxyList.splice(idx, 1);
        renderProxySelect(Math.max(0, idx - 1));
        chrome.storage.sync.set({ proxyList });
        showStatus('Удалено', 'error');
    });

    // ── Выбор прокси из списка ─────────────────────────────────────────────
    proxySelect.addEventListener('change', () => {
        const idx = parseInt(proxySelect.value, 10);
        if (!isNaN(idx) && proxyList[idx]) {
            fillFormFromProxy(proxyList[idx]);
            // Если прокси включён — сразу переключаемся
            if (toggle.checked) {
                const settings = collectSettings();
                chrome.runtime.sendMessage({ action: 'apply', settings });
                chrome.storage.sync.set({ proxySettings: settings });
            }
        }
    });

    // ── Импорт из TXT ──────────────────────────────────────────────────────
    importBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', e => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = ev => {
            let added = 0;
            ev.target.result.split('\n').forEach(line => {
                const p = parseProxyString(line);
                if (p && !proxyList.find(x => x.address === p.address && x.username === p.username)) {
                    proxyList.push({ address: p.address, host: p.host, port: p.port, scheme: p.scheme, username: p.username, password: p.password });
                    added++;
                }
            });
            if (added > 0) {
                renderProxySelect(proxyList.length - 1);
                chrome.storage.sync.set({ proxyList });
                showStatus(`Импортировано: ${added}`, 'success');
            } else {
                showStatus('Новых прокси не найдено', 'error');
            }
            fileInput.value = '';
        };
        reader.readAsText(file);
    });

    // ── Экспорт в TXT ──────────────────────────────────────────────────────
    exportBtn.addEventListener('click', () => {
        if (!proxyList.length) { showStatus('Список пуст', 'error'); return; }
        const lines = proxyList.map(p => {
            let s = `${p.scheme}://${p.address}`;
            if (p.username) s += `:${p.username}:${p.password}`;
            return s;
        });
        const url = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/plain' }));
        const a = document.createElement('a');
        a.href = url; a.download = 'proxy_list.txt';
        document.body.appendChild(a); a.click();
        document.body.removeChild(a); URL.revokeObjectURL(url);
    });

    // ── Сброс статистики ───────────────────────────────────────────────────
    resetButton.addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'resetStats' });
        trafficInfoDiv.textContent = '0 B';
    });
});
