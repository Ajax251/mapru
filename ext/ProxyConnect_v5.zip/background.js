// --- ПОЛНЫЕ ШАБЛОНЫ СВЯЗАННЫХ ДОМЕНОВ ---
const SERVICE_PRESETS = {
    youtube: [
        'youtube.com', '*.youtube.com', 'youtu.be', 'googlevideo.com', '*.googlevideo.com',
        'ytimg.com', '*.ytimg.com', 'ggpht.com', '*.ggpht.com', 'youtubei.googleapis.com',
        'youtube-nocookie.com', 'yt3.ggpht.com', 'widevine.com'
    ],
    gemini: [
        'gemini.google.com', 'bard.google.com', 'aistudio.google.com', 'makersuite.google.com',
        'generativelanguage.googleapis.com', 'alkalimakersuite-pa.clients6.google.com',
        'proactivebackend-pa.googleapis.com', 'ai.google.dev', 'deepmind.google',
        'notebooklm.google.com', 'notebooklm.google', 'labs.google', 'opal.google.com',
        'accounts.google.com', 'ogs.google.com', 'gstatic.com', '*.gstatic.com',
        'googleapis.com', '*.googleapis.com', 'googleusercontent.com', '*.googleusercontent.com'
    ],
    claude: [
        'claude.ai', '*.claude.ai', 'anthropic.com', '*.anthropic.com',
        'console.anthropic.com', 'cdn.usefathom.com', 'intercom.io', '*.intercom.io',
        'intercomcdn.com', '*.intercomcdn.com', 'stripe.com', '*.stripe.com',
        'sentry.io', '*.sentry.io', 'statsigapi.net', 'featuregates.org'
    ],
    chatgpt: [
        'chatgpt.com', '*.chatgpt.com', 'openai.com', '*.openai.com',
        'oaistatic.com', '*.oaistatic.com', 'oaiusercontent.com', '*.oaiusercontent.com',
        'auth0.com', '*.auth0.com', 'arkoselabs.com', '*.arkoselabs.com'
    ]
};

// Автоматическое расширение доменов, если пользователь просто вписал главный сайт
const COMPANION_DOMAINS_MAP = {
    'youtube.com': SERVICE_PRESETS.youtube,
    'gemini.google.com': SERVICE_PRESETS.gemini,
    'aistudio.google.com': SERVICE_PRESETS.gemini,
    'claude.ai': SERVICE_PRESETS.claude,
    'anthropic.com': SERVICE_PRESETS.claude,
    'chatgpt.com': SERVICE_PRESETS.chatgpt,
    'openai.com': SERVICE_PRESETS.chatgpt,
    'instagram.com': ['cdninstagram.com', '*.cdninstagram.com', 'fbcdn.net', '*.fbcdn.net'],
    'twitter.com': ['twimg.com', '*.twimg.com', 't.co', 'x.com', '*.x.com'],
    'x.com': ['twimg.com', '*.twimg.com', 't.co', 'twitter.com', '*.twitter.com']
};

let cachedState = {
    isConnected: false,
    proxySettings: {},
    expandedTargetSites: [],
    connectionStatus: 'disconnected', // 'disconnected' | 'checking' | 'connected' | 'error'
    lastIpInfo: null,
    webrtcProtect: false
};

let trafficData = {};
let saveTrafficTimeout = null;
let baseIconBitmap = null;
const authRetryMap = new Map();

async function initialize() {
    const data = await chrome.storage.local.get([
        'proxySettings',
        'isConnected',
        'trafficData',
        'lastIpInfo',
        'webrtcProtect',
        'connectionStatus'
    ]);

    if (!data.proxySettings) {
        const syncData = await chrome.storage.sync.get(['proxySettings', 'isConnected', 'proxyList']);
        if (syncData.proxySettings) {
            await chrome.storage.local.set(syncData);
            data.proxySettings = syncData.proxySettings;
            data.isConnected = syncData.isConnected;
        }
    }

    trafficData = data.trafficData || {};
    cachedState.isConnected = !!data.isConnected;
    cachedState.lastIpInfo = data.lastIpInfo || null;
    cachedState.webrtcProtect = !!data.webrtcProtect;
    cachedState.connectionStatus = data.isConnected ? (data.connectionStatus || 'connected') : 'disconnected';

    if (data.proxySettings) {
        updateCachedState(data.proxySettings);
    }

    applyWebRTCProtection(cachedState.webrtcProtect && cachedState.isConnected);

    if (cachedState.isConnected && cachedState.proxySettings.server) {
        applyProxy(cachedState.proxySettings, false);
    } else {
        await updateVisualIndicators();
    }
}

initialize();

// Разворачиваем список сайтов + автоматически подтягиваем все связанные домены для YouTube, Gemini, Claude
function getExpandedTargetSites(userSiteList) {
    if (!userSiteList) return [];
    const initialSites = userSiteList
        .split(/[\s,;\n]+/)
        .map(s => s.trim().toLowerCase())
        .filter(Boolean);

    const siteSet = new Set(initialSites);
    initialSites.forEach(site => {
        const cleanSite = site.replace(/^\*\./, '');
        for (const mainDomain in COMPANION_DOMAINS_MAP) {
            if (cleanSite === mainDomain || site.includes(mainDomain)) {
                COMPANION_DOMAINS_MAP[mainDomain].forEach(companion => siteSet.add(companion));
            }
        }
    });
    return Array.from(siteSet);
}

function updateCachedState(proxySettings) {
    cachedState.proxySettings = proxySettings || {};
    if (!cachedState.proxySettings.routingMode) {
        cachedState.proxySettings.routingMode = cachedState.proxySettings.targetSites ? 'whitelist' : 'all';
    }
    cachedState.expandedTargetSites = getExpandedTargetSites(cachedState.proxySettings.targetSites);
}

function matchHostPattern(hostname, pattern) {
    hostname = hostname.toLowerCase();
    pattern = pattern.toLowerCase();

    if (pattern.includes('*')) {
        const regexStr = '^' + pattern.split('*').map(part => part.replace(/[.+?^${}()|[\]\\]/g, '\\$&')).join('.*') + '$';
        if (new RegExp(regexStr, 'i').test(hostname)) return true;
        if (pattern.startsWith('*.')) {
            const rootDomain = pattern.slice(2);
            if (hostname === rootDomain) return true;
        }
        return false;
    }
    return hostname === pattern || hostname.endsWith(`.${pattern}`);
}

function shouldUseProxyForHost(hostname) {
    if (!cachedState.isConnected || !hostname) return false;

    const mode = cachedState.proxySettings.routingMode || 'all';
    const patterns = cachedState.expandedTargetSites;

    if (mode === 'all' || patterns.length === 0) return true;

    const isMatched = patterns.some(pattern => matchHostPattern(hostname, pattern));
    return mode === 'whitelist' ? isMatched : !isMatched;
}

function buildPacConditions(patterns) {
    return patterns.map(pattern => {
        const cleanPattern = pattern.replace(/["\\]/g, '');
        if (cleanPattern.includes('*')) {
            if (cleanPattern.startsWith('*.')) {
                const root = cleanPattern.slice(2);
                return `(shExpMatch(host, "${cleanPattern}") || host === "${root}")`;
            }
            return `shExpMatch(host, "${cleanPattern}")`;
        }
        return `(host === "${cleanPattern}" || shExpMatch(host, "*.${cleanPattern}"))`;
    }).join(" || ");
}

function applyWebRTCProtection(enable) {
    if (!chrome.privacy || !chrome.privacy.network) return;
    chrome.privacy.network.webRTCIPHandlingPolicy.set({
        value: enable ? 'disable_non_proxied_udp' : 'default'
    });
}

function applyProxy(settings, runCheck = true) {
    if (!settings || !settings.server || !settings.port || !settings.scheme) return;

    updateCachedState(settings);
    cachedState.isConnected = true;
    cachedState.connectionStatus = 'checking';
    authRetryMap.clear();

    applyWebRTCProtection(cachedState.webrtcProtect);

    const mode = cachedState.proxySettings.routingMode || 'all';
    const targetSites = cachedState.expandedTargetSites;
    let config;

    if (mode !== 'all' && targetSites.length > 0) {
        const schemeUpper = settings.scheme.toUpperCase();
        let proxyType = 'PROXY';
        if (schemeUpper === 'HTTPS') proxyType = 'HTTPS';
        else if (schemeUpper === 'SOCKS5') proxyType = 'SOCKS5';
        else if (schemeUpper === 'SOCKS4') proxyType = 'SOCKS4';

        const proxyServerString = `${proxyType} ${settings.server}:${settings.port}`;
        const conditions = buildPacConditions(targetSites);
        const ipCheckDomains = `(shExpMatch(host, "*ipwho.is") || shExpMatch(host, "*ipify.org"))`;

        let pacScript;
        if (mode === 'whitelist') {
            pacScript = `
                function FindProxyForURL(url, host) {
                    host = host.toLowerCase();
                    if (${ipCheckDomains} || ${conditions}) {
                        return "${proxyServerString}";
                    }
                    return "DIRECT";
                }
            `;
        } else {
            pacScript = `
                function FindProxyForURL(url, host) {
                    host = host.toLowerCase();
                    if (isPlainHostName(host) || host === "localhost" || host === "127.0.0.1") {
                        return "DIRECT";
                    }
                    if (${ipCheckDomains}) {
                        return "${proxyServerString}";
                    }
                    if (${conditions}) {
                        return "DIRECT";
                    }
                    return "${proxyServerString}";
                }
            `;
        }
        config = { mode: "pac_script", pacScript: { data: pacScript } };
    } else {
        config = {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: settings.scheme,
                    host: settings.server,
                    port: parseInt(settings.port, 10)
                },
                bypassList: ["<local>", "127.0.0.1", "localhost"]
            }
        };
    }

    chrome.proxy.settings.set({ value: config, scope: "regular" }, async () => {
        await updateVisualIndicators();
        if (runCheck) {
            await checkProxyConnection();
        }
    });
}

function disableProxy() {
    cachedState.isConnected = false;
    cachedState.connectionStatus = 'disconnected';
    cachedState.lastIpInfo = null;
    authRetryMap.clear();

    applyWebRTCProtection(false);

    chrome.storage.local.set({
        isConnected: false,
        connectionStatus: 'disconnected',
        lastIpInfo: null
    });

    chrome.proxy.settings.clear({ scope: "regular" }, () => {
        updateVisualIndicators();
    });
}

async function checkProxyConnection() {
    if (!cachedState.isConnected) return null;

    cachedState.connectionStatus = 'checking';
    await updateVisualIndicators();

    const startTime = Date.now();
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 8000);

        const response = await fetch('https://ipwho.is/', {
            signal: controller.signal,
            cache: 'no-store'
        });
        clearTimeout(timeoutId);

        if (!response.ok) throw new Error('HTTP Error');
        const data = await response.json();
        const ping = Date.now() - startTime;

        const ipInfo = {
            ip: data.ip || cachedState.proxySettings.server,
            country: data.country_code || '',
            ping: ping
        };

        cachedState.connectionStatus = 'connected';
        cachedState.lastIpInfo = ipInfo;

        await chrome.storage.local.set({
            connectionStatus: 'connected',
            lastIpInfo: ipInfo
        });

        await updateVisualIndicators();
        return { success: true, ...ipInfo };
    } catch (err) {
        try {
            const controller2 = new AbortController();
            const timeoutId2 = setTimeout(() => controller2.abort(), 5000);
            const res2 = await fetch('https://api.ipify.org?format=json', {
                signal: controller2.signal,
                cache: 'no-store'
            });
            clearTimeout(timeoutId2);
            const data2 = await res2.json();
            const ping = Date.now() - startTime;

            const ipInfo = {
                ip: data2.ip || cachedState.proxySettings.server,
                country: '',
                ping: ping
            };

            cachedState.connectionStatus = 'connected';
            cachedState.lastIpInfo = ipInfo;
            await chrome.storage.local.set({ connectionStatus: 'connected', lastIpInfo: ipInfo });
            await updateVisualIndicators();
            return { success: true, ...ipInfo };
        } catch (e2) {
            cachedState.connectionStatus = 'error';
            await chrome.storage.local.set({ connectionStatus: 'error' });
            await updateVisualIndicators();
            return { success: false, error: 'Не удалось соединиться через прокси' };
        }
    }
}

function getLastIpOctet(ipStr) {
    if (!ipStr) return '';
    if (ipStr.includes('.')) {
        const parts = ipStr.trim().split('.');
        const last = parts[parts.length - 1];
        return last.length <= 3 ? `.${last}` : last.slice(0, 4);
    }
    return ipStr.slice(-4);
}

// Загрузка базовой картинки icon.png
async function getBaseIconBitmap() {
    if (baseIconBitmap) return baseIconBitmap;
    try {
        const url = chrome.runtime.getURL('icon.png');
        const response = await fetch(url);
        if (!response.ok) return null;
        const blob = await response.blob();
        baseIconBitmap = await createImageBitmap(blob);
        return baseIconBitmap;
    } catch (e) {
        return null;
    }
}

// Безопасное создание ImageData для конкретного размера (16x16 и 32x32)
function renderSizeImageData(bitmap, size, statusColor) {
    const canvas = new OffscreenCanvas(size, size);
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    ctx.clearRect(0, 0, size, size);

    if (bitmap) {
        ctx.drawImage(bitmap, 0, 0, size, size);
    } else {
        ctx.fillStyle = '#4f46e5';
        ctx.beginPath();
        ctx.roundRect(1, 1, size - 2, size - 2, Math.round(size * 0.2));
        ctx.fill();
    }

    if (statusColor) {
        const radius = size === 16 ? 3.2 : 5.5;
        const border = size === 16 ? 4.2 : 7.0;
        const cx = size - border;
        const cy = border;

        ctx.beginPath();
        ctx.arc(cx, cy, border, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();

        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.fillStyle = statusColor;
        ctx.fill();
    }

    const raw = ctx.getImageData(0, 0, size, size);
    // Создаём чистый экземпляр ImageData, чтобы Chrome не выдавал Icon invalid
    return new ImageData(new Uint8ClampedArray(raw.data), size, size);
}

// Безопасная установка иконки без ошибок runtime.lastError
async function safeSetIconWithDot(statusColor) {
    try {
        const bitmap = await getBaseIconBitmap();
        if (!bitmap) {
            chrome.action.setIcon({ path: { "16": "icon.png", "32": "icon.png" } }, () => {
                void chrome.runtime.lastError;
            });
            return;
        }

        const imageDataDict = {
            16: renderSizeImageData(bitmap, 16, statusColor),
            32: renderSizeImageData(bitmap, 32, statusColor)
        };

        chrome.action.setIcon({ imageData: imageDataDict }, () => {
            if (chrome.runtime.lastError) {
                // Если браузер отклонил буфер — тихо ставим штатную icon.png
                chrome.action.setIcon({ path: "icon.png" }, () => {
                    void chrome.runtime.lastError;
                });
            }
        });
    } catch (e) {
        chrome.action.setIcon({ path: "icon.png" }, () => {
            void chrome.runtime.lastError;
        });
    }
}

async function updateVisualIndicators() {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await updateIndicatorsForTab(tab);
    } catch (e) {}
}

async function updateIndicatorsForTab(tab) {
    if (!cachedState.isConnected) {
        await safeSetIconWithDot(null);
        chrome.action.setBadgeText({ text: '' });
        chrome.action.setTitle({ title: 'Прокси отключён' });
        return;
    }

    let useProxyOnCurrentTab = true;
    if (tab && tab.url && tab.url.startsWith('http')) {
        try {
            const hostname = new URL(tab.url).hostname.toLowerCase();
            useProxyOnCurrentTab = shouldUseProxyForHost(hostname);
        } catch (e) {
            useProxyOnCurrentTab = false;
        }
    }

    let indicatorColor = '#10b981'; // Зелёный — успешное соединение
    if (cachedState.connectionStatus === 'error') {
        indicatorColor = '#ef4444'; // Красный — ошибка
    } else if (cachedState.connectionStatus === 'checking') {
        indicatorColor = '#f59e0b'; // Жёлтый — проверка
    } else if (!useProxyOnCurrentTab) {
        indicatorColor = '#3b82f6'; // Синий — сайт в обход прокси
    }

    await safeSetIconWithDot(indicatorColor);

    const ipToDisplay = cachedState.lastIpInfo?.ip || cachedState.proxySettings?.server || '';
    const lastOctet = getLastIpOctet(ipToDisplay);

    if (cachedState.connectionStatus === 'error') {
        chrome.action.setBadgeText({ text: 'ERR' });
        chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
    } else if (lastOctet) {
        chrome.action.setBadgeText({ text: lastOctet });
        chrome.action.setBadgeBackgroundColor({
            color: useProxyOnCurrentTab ? '#10b981' : '#64748b'
        });
    } else {
        chrome.action.setBadgeText({ text: 'ON' });
        chrome.action.setBadgeBackgroundColor({ color: '#10b981' });
    }

    const statusText = cachedState.connectionStatus === 'connected' ? '🟢 Прокси активен' :
                       cachedState.connectionStatus === 'error' ? '🔴 Ошибка прокси' : '🟡 Проверка...';
    const ipLine = cachedState.lastIpInfo?.ip
        ? `IP: ${cachedState.lastIpInfo.ip} ${cachedState.lastIpInfo.country ? `(${cachedState.lastIpInfo.country})` : ''} • ${cachedState.lastIpInfo.ping} мс`
        : `Сервер: ${cachedState.proxySettings.server}:${cachedState.proxySettings.port}`;

    chrome.action.setTitle({
        title: `${statusText}\n${ipLine}\nТекущий сайт: ${useProxyOnCurrentTab ? 'Через прокси' : 'Напрямую (в обход)'}`
    });
}

// ── Автоматическая подстановка пароля прокси ───────────────────────────────
chrome.webRequest.onAuthRequired.addListener(
    (details, callback) => {
        if (!details.isProxy) {
            callback({});
            return;
        }

        const retries = authRetryMap.get(details.requestId) || 0;
        if (retries >= 3) {
            authRetryMap.delete(details.requestId);
            callback({ cancel: true });
            return;
        }
        authRetryMap.set(details.requestId, retries + 1);

        if (cachedState.isConnected && cachedState.proxySettings?.username) {
            callback({
                authCredentials: {
                    username: cachedState.proxySettings.username.trim(),
                    password: (cachedState.proxySettings.password || '').trim()
                }
            });
            return;
        }

        chrome.storage.local.get(['proxySettings', 'isConnected'], (data) => {
            const s = data.proxySettings;
            if (data.isConnected && s && s.username && s.username.trim()) {
                updateCachedState(s);
                cachedState.isConnected = true;
                callback({
                    authCredentials: {
                        username: s.username.trim(),
                        password: (s.password || '').trim()
                    }
                });
            } else {
                callback({});
            }
        });
    },
    { urls: ["<all_urls>"] },
    ["asyncBlocking"]
);

chrome.webRequest.onCompleted.addListener(
    (details) => {
        authRetryMap.delete(details.requestId);

        if (!cachedState.isConnected || details.tabId < 0 || details.fromCache) return;
        let useProxy = false;
        try {
            const hostname = new URL(details.url).hostname.toLowerCase();
            useProxy = shouldUseProxyForHost(hostname);
        } catch (e) { return; }

        if (useProxy) {
            const bytesHeader = details.responseHeaders?.find(h => h.name.toLowerCase() === 'content-length');
            const bytes = bytesHeader ? parseInt(bytesHeader.value, 10) : 0;
            if (bytes > 0) {
                chrome.tabs.get(details.tabId, (tab) => {
                    if (chrome.runtime.lastError || !tab || !tab.url) return;
                    try {
                        const mainHostname = new URL(tab.url).hostname;
                        trafficData[mainHostname] = (trafficData[mainHostname] || 0) + bytes;
                        scheduleSaveTraffic();
                    } catch (e) {}
                });
            }
        }
    },
    { urls: ["<all_urls>"] },
    ["responseHeaders"]
);

chrome.webRequest.onErrorOccurred.addListener(
    (details) => {
        authRetryMap.delete(details.requestId);
    },
    { urls: ["<all_urls>"] }
);

function scheduleSaveTraffic() {
    if (saveTrafficTimeout) clearTimeout(saveTrafficTimeout);
    saveTrafficTimeout = setTimeout(() => {
        chrome.storage.local.set({ trafficData });
    }, 2000);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'apply') {
        applyProxy(request.settings, true);
        sendResponse({ status: 'applying' });
    } else if (request.action === 'disable') {
        disableProxy();
        sendResponse({ status: 'disabled' });
    } else if (request.action === 'checkIp') {
        checkProxyConnection().then(res => sendResponse(res));
        return true;
    } else if (request.action === 'setWebRTC') {
        cachedState.webrtcProtect = !!request.enabled;
        chrome.storage.local.set({ webrtcProtect: cachedState.webrtcProtect });
        applyWebRTCProtection(cachedState.webrtcProtect && cachedState.isConnected);
        sendResponse({ ok: true });
    } else if (request.action === 'resetStats') {
        trafficData = {};
        chrome.storage.local.set({ trafficData: {} });
        sendResponse({ ok: true });
    }
});

chrome.tabs.onActivated.addListener(() => updateVisualIndicators());
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tab.active && changeInfo.url) updateIndicatorsForTab(tab);
});