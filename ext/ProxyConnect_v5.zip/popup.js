document.addEventListener('DOMContentLoaded', function () {
    // Полные шаблоны доменов для быстрой вставки
    const PRESET_DOMAINS = {
        youtube: [
            'youtube.com', 'youtu.be', 'googlevideo.com', 'ytimg.com',
            'ggpht.com', 'youtubei.googleapis.com', 'youtube-nocookie.com'
        ],
        gemini: [
            'gemini.google.com', 'aistudio.google.com', 'makersuite.google.com',
            'generativelanguage.googleapis.com', 'alkalimakersuite-pa.clients6.google.com',
            'proactivebackend-pa.googleapis.com', 'ai.google.dev', 'deepmind.google',
            'notebooklm.google.com', 'notebooklm.google', 'labs.google', 'opal.google.com',
            'accounts.google.com', 'ogs.google.com', 'gstatic.com', 'googleapis.com', 'googleusercontent.com'
        ],
        claude: [
            'claude.ai', 'anthropic.com', 'console.anthropic.com',
            'intercom.io', 'intercomcdn.com', 'usefathom.com',
            'stripe.com', 'sentry.io', 'statsigapi.net', 'featuregates.org'
        ],
        chatgpt: [
            'chatgpt.com', 'openai.com', 'oaistatic.com',
            'oaiusercontent.com', 'auth0.com', 'arkoselabs.com'
        ],
        ru: [
            '*.ru', '*.su', '*.рф', '*.xn--p1ai'
        ]
    };

    const toggle = document.getElementById('proxyToggle');
    const serverInput = document.getElementById('server');
    const portInput = document.getElementById('port');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const togglePassBtn = document.getElementById('togglePassBtn');
    const schemeSelect = document.getElementById('scheme');
    const socksWarning = document.getElementById('socksWarning');

    const routingModeTabs = document.querySelectorAll('.mode-tab');
    const sitesListContainer = document.getElementById('sitesListContainer');
    const modeHintText = document.getElementById('modeHintText');
    const targetSitesInput = document.getElementById('targetSites');
    const addCurrentSiteBtn = document.getElementById('addCurrentSiteBtn');
    const presetButtons = document.querySelectorAll('.preset-chip[data-preset]');
    const clearSitesBtn = document.getElementById('clearSitesBtn');

    const statusDiv = document.getElementById('status');
    const trafficInfoDiv = document.getElementById('trafficInfo');
    const resetButton = document.getElementById('resetButton');
    const webrtcToggle = document.getElementById('webrtcToggle');

    const headerDot = document.getElementById('headerDot');
    const connectionSub = document.getElementById('connectionSub');
    const currentIpValue = document.getElementById('currentIpValue');
    const pingBadge = document.getElementById('pingBadge');
    const checkIpBtn = document.getElementById('checkIpBtn');

    const proxySelect = document.getElementById('proxySelect');
    const addProxyBtn = document.getElementById('addProxyBtn');
    const deleteProxyBtn = document.getElementById('deleteProxyBtn');
    const importBtn = document.getElementById('importBtn');
    const exportBtn = document.getElementById('exportBtn');
    const fileInput = document.getElementById('fileInput');

    let proxyList = [];
    let currentRoutingMode = 'all';
    let statusTimeout = null;

    function showStatus(message, type = 'error') {
        if (statusTimeout) clearTimeout(statusTimeout);
        statusDiv.textContent = message;
        statusDiv.className = type === 'success' ? 'status-success' : 'status-error';
        statusTimeout = setTimeout(() => {
            statusDiv.textContent = '';
            statusDiv.className = '';
        }, 3500);
    }

    function formatBytes(bytes) {
        if (!bytes || bytes === 0) return '0 B';
        const k = 1024, sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    function checkSocksAuthWarning() {
        const isSocks = schemeSelect.value.startsWith('socks');
        const hasAuth = usernameInput.value.trim().length > 0 || passwordInput.value.trim().length > 0;
        socksWarning.style.display = (isSocks && hasAuth) ? 'block' : 'none';
    }

    function setRoutingModeUI(mode) {
        currentRoutingMode = mode || 'all';
        routingModeTabs.forEach(btn => {
            btn.classList.toggle('active', btn.dataset.mode === currentRoutingMode);
        });

        if (currentRoutingMode === 'all') {
            sitesListContainer.style.display = 'none';
        } else {
            sitesListContainer.style.display = 'block';
            modeHintText.textContent = currentRoutingMode === 'whitelist'
                ? 'Через прокси только эти сайты/шаблоны:'
                : 'Напрямую (в обход прокси) эти сайты/маски:';
        }
    }

    function updateHeaderAndIpUI(isConnected, connectionStatus, lastIpInfo) {
        headerDot.className = 'status-dot';
        pingBadge.className = 'ping-badge';

        if (!isConnected) {
            connectionSub.textContent = 'Отключено';
            currentIpValue.textContent = 'Прямое соединение';
            pingBadge.textContent = '— мс';
            return;
        }

        if (connectionStatus === 'checking') {
            headerDot.classList.add('checking');
            connectionSub.textContent = 'Проверка соединения...';
            currentIpValue.textContent = 'Загрузка...';
        } else if (connectionStatus === 'error') {
            headerDot.classList.add('error');
            connectionSub.textContent = 'Ошибка соединения';
            currentIpValue.textContent = 'Недоступен';
            pingBadge.textContent = 'ERR';
        } else {
            headerDot.classList.add('connected');
            connectionSub.textContent = 'Активен';
            if (lastIpInfo && lastIpInfo.ip) {
                const countryTag = lastIpInfo.country ? ` (${lastIpInfo.country})` : '';
                currentIpValue.textContent = `${lastIpInfo.ip}${countryTag}`;
                pingBadge.textContent = `${lastIpInfo.ping} мс`;
                pingBadge.classList.add(lastIpInfo.ping < 300 ? 'good' : 'warn');
            } else {
                currentIpValue.textContent = `${serverInput.value}:${portInput.value}`;
                pingBadge.textContent = 'OK';
            }
        }
    }

    function updateTrafficInfo() {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (!tabs[0] || !tabs[0].url) { trafficInfoDiv.textContent = '0 B'; return; }
            try {
                const hostname = new URL(tabs[0].url).hostname;
                chrome.storage.local.get('trafficData', (data) => {
                    trafficInfoDiv.textContent = formatBytes((data.trafficData || {})[hostname] || 0);
                });
            } catch (e) { trafficInfoDiv.textContent = '0 B'; }
        });
    }

    function parseProxyString(str) {
        str = str.trim();
        if (!str) return null;

        let scheme = schemeSelect.value || 'http';
        let host = '', port = '', username = '', password = '';

        const schemeMatch = str.match(/^(https?|socks[45]):\/\/(.*)/i);
        if (schemeMatch) {
            scheme = schemeMatch[1].toLowerCase();
            str = schemeMatch[2];
        }

        if (str.includes('@')) {
            const [auth, hostpart] = str.split('@');
            const authParts = auth.split(':');
            username = authParts[0] || '';
            password = authParts.slice(1).join(':');
            str = hostpart;
        }

        const parts = str.split(':');
        if (parts.length >= 2) {
            host = parts[0];
            port = parseInt(parts[1], 10);
            if (!username && parts.length >= 4) {
                username = parts[2];
                password = parts.slice(3).join(':');
            }
        } else {
            return null;
        }

        if (!host || isNaN(port) || port < 1 || port > 65535) return null;
        return { address: `${host}:${port}`, host, port, username, password, scheme };
    }

    serverInput.addEventListener('paste', (e) => {
        const pasted = (e.clipboardData || window.clipboardData).getData('text');
        if (pasted && pasted.includes(':')) {
            const parsed = parseProxyString(pasted);
            if (parsed) {
                e.preventDefault();
                serverInput.value = parsed.host;
                portInput.value = parsed.port;
                schemeSelect.value = parsed.scheme;
                if (parsed.username) usernameInput.value = parsed.username;
                if (parsed.password) passwordInput.value = parsed.password;
                onFieldChange();
                showStatus('Прокси распознан автоматически ✨', 'success');
            }
        }
    });

    togglePassBtn.addEventListener('click', () => {
        const isPass = passwordInput.type === 'password';
        passwordInput.type = isPass ? 'text' : 'password';
        togglePassBtn.textContent = isPass ? '🙈' : '👁';
    });

    function renderProxySelect(selectedIndex) {
        proxySelect.innerHTML = '';
        if (proxyList.length === 0) {
            const opt = document.createElement('option');
            opt.value = ''; opt.textContent = 'Нет сохранённых прокси'; opt.disabled = true;
            proxySelect.appendChild(opt);
            proxySelect.value = '';
        } else {
            proxyList.forEach((p, i) => {
                const opt = document.createElement('option');
                opt.value = i;
                opt.textContent = `${p.address} (${p.scheme.toUpperCase()})${p.username ? ' 🔒' : ''}`;
                proxySelect.appendChild(opt);
            });
            const idx = (selectedIndex >= 0 && selectedIndex < proxyList.length) ? selectedIndex : 0;
            proxySelect.value = idx;
            fillFormFromProxy(proxyList[idx]);
        }
    }

    function fillFormFromProxy(p) {
        if (!p) return;
        serverInput.value = p.host || '';
        portInput.value = p.port || '';
        schemeSelect.value = p.scheme || 'http';
        usernameInput.value = p.username || '';
        passwordInput.value = p.password || '';
        checkSocksAuthWarning();
    }

    function collectSettings() {
        return {
            scheme: schemeSelect.value,
            server: serverInput.value.trim(),
            port: portInput.value.trim(),
            username: usernameInput.value.trim(),
            password: passwordInput.value.trim(),
            routingMode: currentRoutingMode,
            targetSites: targetSitesInput.value.trim()
        };
    }

    chrome.storage.local.get([
        'proxyList',
        'proxySettings',
        'isConnected',
        'connectionStatus',
        'lastIpInfo',
        'webrtcProtect'
    ], function (data) {
        proxyList = data.proxyList || [];

        let selectedIndex = 0;
        if (data.proxySettings && data.proxySettings.server) {
            const activeAddr = `${data.proxySettings.server}:${data.proxySettings.port}`;
            const found = proxyList.findIndex(p => p.address === activeAddr);
            if (found >= 0) selectedIndex = found;
        }

        renderProxySelect(selectedIndex);

        if (data.proxySettings) {
            serverInput.value = data.proxySettings.server || serverInput.value;
            portInput.value = data.proxySettings.port || portInput.value;
            schemeSelect.value = data.proxySettings.scheme || schemeSelect.value;
            usernameInput.value = data.proxySettings.username || usernameInput.value;
            passwordInput.value = data.proxySettings.password || passwordInput.value;
            targetSitesInput.value = data.proxySettings.targetSites || '';

            const savedMode = data.proxySettings.routingMode || (data.proxySettings.targetSites ? 'whitelist' : 'all');
            setRoutingModeUI(savedMode);
        } else {
            setRoutingModeUI('all');
        }

        toggle.checked = !!data.isConnected;
        webrtcToggle.checked = !!data.webrtcProtect;

        checkSocksAuthWarning();
        updateHeaderAndIpUI(!!data.isConnected, data.connectionStatus, data.lastIpInfo);
        updateTrafficInfo();
    });

    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local') {
            chrome.storage.local.get(['isConnected', 'connectionStatus', 'lastIpInfo'], (data) => {
                updateHeaderAndIpUI(!!data.isConnected, data.connectionStatus, data.lastIpInfo);
            });
        }
    });

    routingModeTabs.forEach(btn => {
        btn.addEventListener('click', () => {
            setRoutingModeUI(btn.dataset.mode);
            onFieldChange();
        });
    });

    // Обработчик кнопок-шаблонов (YouTube, Gemini, Claude, ChatGPT, *.ru)
    presetButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const presetKey = btn.dataset.preset;
            const domainsToAdd = PRESET_DOMAINS[presetKey] || [];
            const currentList = targetSitesInput.value.split(/[\s,;\n]+/).filter(Boolean);
            let addedCount = 0;

            domainsToAdd.forEach(domain => {
                if (!currentList.includes(domain)) {
                    currentList.push(domain);
                    addedCount++;
                }
            });

            if (addedCount > 0) {
                targetSitesInput.value = currentList.join('\n');
                onFieldChange();
                showStatus(`Добавлен шаблон ${btn.textContent.trim()} (+${addedCount} доменов)`, 'success');
            } else {
                showStatus(`Все домены ${btn.textContent.trim()} уже в списке`, 'success');
            }
        });
    });

    // Очистка списка сайтов
    clearSitesBtn.addEventListener('click', () => {
        targetSitesInput.value = '';
        onFieldChange();
        showStatus('Список сайтов очищен', 'success');
    });

    addCurrentSiteBtn.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (!tabs[0] || !tabs[0].url) return;
            try {
                const url = new URL(tabs[0].url);
                if (!url.hostname || url.protocol.startsWith('chrome')) return;
                const cleanHost = url.hostname.replace(/^www\./, '');
                const currentList = targetSitesInput.value.split(/[\s,;\n]+/).filter(Boolean);
                if (!currentList.includes(cleanHost)) {
                    currentList.push(cleanHost);
                    targetSitesInput.value = currentList.join('\n');
                    onFieldChange();
                    showStatus(`Добавлен: ${cleanHost}`, 'success');
                } else {
                    showStatus('Сайт уже в списке', 'success');
                }
            } catch (e) {}
        });
    });

    toggle.addEventListener('change', function () {
        const settings = collectSettings();

        if (toggle.checked) {
            if (!settings.server || !settings.port) {
                toggle.checked = false;
                showStatus('Заполните поля сервера и порта', 'error');
                return;
            }
            chrome.storage.local.set({ isConnected: true, proxySettings: settings });
            chrome.runtime.sendMessage({ action: 'apply', settings });
            updateHeaderAndIpUI(true, 'checking', null);
        } else {
            chrome.runtime.sendMessage({ action: 'disable' });
            updateHeaderAndIpUI(false, 'disconnected', null);
        }
    });

    checkIpBtn.addEventListener('click', () => {
        if (!toggle.checked) {
            showStatus('Сначала включите прокси', 'error');
            return;
        }
        updateHeaderAndIpUI(true, 'checking', null);
        chrome.runtime.sendMessage({ action: 'checkIp' }, (res) => {
            if (res && res.success) {
                showStatus(`Ответ получен (${res.ping} мс)`, 'success');
            } else {
                showStatus('Ошибка ответа от прокси', 'error');
            }
        });
    });

    webrtcToggle.addEventListener('change', () => {
        chrome.runtime.sendMessage({ action: 'setWebRTC', enabled: webrtcToggle.checked });
    });

    function onFieldChange() {
        checkSocksAuthWarning();
        const idx = parseInt(proxySelect.value, 10);
        if (!isNaN(idx) && proxyList[idx]) {
            proxyList[idx].host = serverInput.value.trim();
            proxyList[idx].port = parseInt(portInput.value.trim(), 10) || proxyList[idx].port;
            proxyList[idx].address = `${serverInput.value.trim()}:${portInput.value.trim()}`;
            proxyList[idx].scheme = schemeSelect.value;
            proxyList[idx].username = usernameInput.value.trim();
            proxyList[idx].password = passwordInput.value.trim();
        }

        const settings = collectSettings();
        chrome.storage.local.set({ proxySettings: settings, proxyList });

        if (toggle.checked && settings.server && settings.port) {
            chrome.runtime.sendMessage({ action: 'apply', settings });
        }
    }

    serverInput.addEventListener('input', onFieldChange);
    portInput.addEventListener('input', onFieldChange);
    schemeSelect.addEventListener('change', onFieldChange);
    usernameInput.addEventListener('input', onFieldChange);
    passwordInput.addEventListener('input', onFieldChange);
    targetSitesInput.addEventListener('input', onFieldChange);

    addProxyBtn.addEventListener('click', () => {
        const settings = collectSettings();
        if (!settings.server || !settings.port) {
            showStatus('Заполните сервер и порт', 'error'); return;
        }
        const address = `${settings.server}:${settings.port}`;
        const existsIdx = proxyList.findIndex(p => p.address === address && p.username === settings.username);
        if (existsIdx !== -1) {
            proxyList[existsIdx].password = settings.password;
            proxyList[existsIdx].scheme = settings.scheme;
            renderProxySelect(existsIdx);
            chrome.storage.local.set({ proxyList });
            showStatus('Данные прокси обновлены', 'success');
            return;
        }
        proxyList.push({
            address,
            host: settings.server,
            port: parseInt(settings.port, 10),
            scheme: settings.scheme,
            username: settings.username,
            password: settings.password
        });
        renderProxySelect(proxyList.length - 1);
        chrome.storage.local.set({ proxyList });
        showStatus('Сохранено в список', 'success');
    });

    deleteProxyBtn.addEventListener('click', () => {
        const idx = parseInt(proxySelect.value, 10);
        if (isNaN(idx) || !proxyList[idx]) return;
        proxyList.splice(idx, 1);
        renderProxySelect(Math.max(0, idx - 1));
        chrome.storage.local.set({ proxyList });
        showStatus('Прокси удалён', 'error');
    });

    proxySelect.addEventListener('change', () => {
        const idx = parseInt(proxySelect.value, 10);
        if (!isNaN(idx) && proxyList[idx]) {
            fillFormFromProxy(proxyList[idx]);
            const settings = collectSettings();
            chrome.storage.local.set({ proxySettings: settings });
            if (toggle.checked) {
                chrome.runtime.sendMessage({ action: 'apply', settings });
            }
        }
    });

    importBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', e => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = ev => {
            let added = 0;
            ev.target.result.split('\n').forEach(line => {
                const p = parseProxyString(line);
                if (p && !proxyList.find(x => x.address === p.address && x.username === p.username)) {
                    proxyList.push(p);
                    added++;
                }
            });
            if (added > 0) {
                renderProxySelect(proxyList.length - 1);
                chrome.storage.local.set({ proxyList });
                showStatus(`Импортировано: ${added}`, 'success');
            } else {
                showStatus('Новых прокси не найдено', 'error');
            }
            fileInput.value = '';
        };
        reader.readAsText(file);
    });

    exportBtn.addEventListener('click', () => {
        if (!proxyList.length) { showStatus('Список пуст', 'error'); return; }
        const lines = proxyList.map(p => {
            let s = `${p.scheme}://${p.address}`;
            if (p.username) s += `:${p.username}:${p.password}`;
            return s;
        });
        const url = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/plain' }));
        const a = document.createElement('a');
        a.href = url; a.download = 'proxy_list.txt';
        document.body.appendChild(a); a.click();
        document.body.removeChild(a); URL.revokeObjectURL(url);
    });

    resetButton.addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'resetStats' });
        trafficInfoDiv.textContent = '0 B';
    });
});