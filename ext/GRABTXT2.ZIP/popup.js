// Список нежелательных слов-маркеров интерфейса для очистки шума
const NOISE_WORDS = [
  "политика конфиденциальности", "оферта", "контакты", "все права защищены",
  "войти", "зарегистрироваться", "карта сайта", "cookie", "соглашение",
  "телефон:", "поддержка", "подписаться", "читать далее", "поделиться"
];

// Улучшенная функция очистки и форматирования текста
function cleanRawText(text) {
  if (!text) return "";
  const lines = text.split('\n');
  
  const filteredLines = lines.map(line => line.trim()).filter(line => {
    if (!line) return false;
    
    // Исключаем слишком короткие цифровые строки (например, номера страниц, счетчики)
    if (/^\d+$/.test(line) && line.length < 3) return false;

    const lower = line.toLowerCase();
    
    // Проверка на точное совпадение с шумовыми словами
    for (let word of NOISE_WORDS) {
      if (lower === word || lower.includes("copyright ©") || lower.includes("© 20")) {
        return false;
      }
    }
    return true;
  });

  // Собираем текст и оптимизируем количество переносов строк
  let cleaned = filteredLines.join('\n');
  cleaned = cleaned.replace(/\n{3,}/g, '\n\n');
  return cleaned.trim();
}

// Конвертер текста в форматированную HTML-страницу
function convertTextToHtml(title, bodyText) {
  const paragraphs = bodyText.split('\n\n');
  let bodyHtml = "";

  paragraphs.forEach(p => {
    const trimmed = p.trim();
    if (!trimmed) return;

    // Определение потенциальных заголовков
    if (trimmed.length < 90 && !trimmed.endsWith('.') && !trimmed.endsWith(':') && !trimmed.includes('\n')) {
      bodyHtml += `  <h2>${trimmed}</h2>\n`;
    } else {
      // Определение списков
      const lines = trimmed.split('\n');
      if (lines.length > 1 && lines.every(l => l.trim().startsWith('-') || l.trim().startsWith('•') || /^\d+\./.test(l.trim()))) {
        bodyHtml += '  <ul>\n';
        lines.forEach(line => {
          const cleanLine = line.replace(/^[-•\d\.\s]+/, '').trim();
          bodyHtml += `    <li>${cleanLine}</li>\n`;
        });
        bodyHtml += '  </ul>\n';
      } else {
        const formattedParagraph = trimmed.replace(/\n/g, '<br>\n');
        bodyHtml += `  <p>${formattedParagraph}</p>\n`;
      }
    }
  });

  return `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <title>${title || 'Документ'}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; line-height: 1.6; max-width: 800px; margin: 40px auto; padding: 0 20px; color: #1e293b; background-color: #f8fafc; }
    h1 { border-bottom: 2px solid #2563eb; padding-bottom: 10px; color: #0f172a; }
    h2 { color: #1e40af; margin-top: 30px; }
    p { margin-bottom: 1.2em; text-align: justify; }
    ul { margin-bottom: 1.2em; padding-left: 20px; }
    li { margin-bottom: 0.5em; }
  </style>
</head>
<body>
  <h1>${title || 'Документ'}</h1>
  ${bodyHtml}
</body>
</html>`;
}

// Загрузка файла пользователю
function downloadFile(content, fileName, contentType) {
  const a = document.createElement("a");
  const file = new Blob([content], {type: contentType});
  a.href = URL.createObjectURL(file);
  a.download = fileName;
  a.click();
  URL.revokeObjectURL(a.href);
}

// Обновление счетчика элементов базы данных
function updateStatus() {
  chrome.storage.local.get({ documents: [] }, (data) => {
    const count = data.documents.length;
    document.getElementById("statusText").innerText = count > 0 
      ? `В базе накоплено документов: ${count}` 
      : "База данных пуста";
  });
}

// Автоматический поиск заголовка документа (первая строка)
function extractTitle(text) {
  if (!text) return "document";
  const firstLine = text.split('\n')[0].trim();
  return firstLine.substring(0, 50).replace(/[^a-zA-Zа-яА-Я0-9\s-_]/g, "");
}

// Универсальное извлечение текста с активной страницы
document.getElementById("btnExtract").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      // Исключаем скрипты, стили, фреймы и элементы навигации
      const selectorsToIgnore = 'script, style, noscript, iframe, header, footer, nav, aside, .ads, .sidebar';
      const clone = document.body.cloneNode(true);
      
      const ignoredElements = clone.querySelectorAll(selectorsToIgnore);
      ignoredElements.forEach(el => el.remove());

      // Получаем чистый внутренний текст без лишних интерактивных блоков
      return clone.innerText || clone.textContent;
    }
  }, (results) => {
    if (results && results[0]) {
      const raw = results[0].result;
      const cleaned = cleanRawText(raw);
      document.getElementById("txtPreview").value = cleaned;
    }
  });
});

// Разблокировка контекстного меню и выделения текста на веб-странице
document.getElementById("btnUnblock").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      // 1. Снимаем блокировки через CSS
      const css = `
        * {
          -webkit-user-select: text !important;
          -moz-user-select: text !important;
          -ms-user-select: text !important;
          user-select: text !important;
        }
      `;
      const style = document.createElement('style');
      style.type = 'text/css';
      style.appendChild(document.createTextNode(css));
      document.head.appendChild(style);

      // 2. Снимаем обработчики JS, блокирующие копирование и контекстное меню
      const autoAllow = (e) => e.stopPropagation();
      document.addEventListener('copy', autoAllow, true);
      document.addEventListener('contextmenu', autoAllow, true);
      document.addEventListener('selectstart', autoAllow, true);
      document.addEventListener('mousedown', autoAllow, true);
      
      // Сбрасываем встроенные в теги события
      document.body.oncopy = null;
      document.body.oncontextmenu = null;
      document.body.onselectstart = null;
      
      alert("Защита от копирования деактивирована на этой странице.");
    }
  });
});

// Сохранение текущего текста как TXT
document.getElementById("btnSaveCurTxt").addEventListener("click", () => {
  const text = document.getElementById("txtPreview").value;
  if (!text) return alert("Сначала извлеките текст.");
  const filename = extractTitle(text) + ".txt";
  downloadFile(text, filename, "text/plain");
});

// Сохранение текущего текста как HTML
document.getElementById("btnSaveCurHtml").addEventListener("click", () => {
  const text = document.getElementById("txtPreview").value;
  if (!text) return alert("Сначала извлеките текст.");
  const title = extractTitle(text);
  const htmlContent = convertTextToHtml(title, text);
  downloadFile(htmlContent, title + ".html", "text/html");
});

// Добавление в общую базу данных
document.getElementById("btnAddToDb").addEventListener("click", () => {
  const text = document.getElementById("txtPreview").value;
  if (!text) return alert("Нечего добавлять. Сначала извлеките текст.");

  chrome.storage.local.get({ documents: [] }, (data) => {
    const list = data.documents;
    const title = extractTitle(text);
    list.push({ title, body: text });
    chrome.storage.local.set({ documents: list }, () => {
      updateStatus();
      alert("Текст добавлен в базу данных.");
    });
  });
});

// Очистка накопленной базы данных
document.getElementById("btnResetDb").addEventListener("click", () => {
  if (confirm("Вы уверены, что хотите полностью очистить накопленную базу?")) {
    chrome.storage.local.set({ documents: [] }, () => {
      updateStatus();
    });
  }
});

// Экспорт всей базы в один файл TXT
document.getElementById("btnSaveDbTxt").addEventListener("click", () => {
  chrome.storage.local.get({ documents: [] }, (data) => {
    if (data.documents.length === 0) return alert("База данных пуста.");
    let fullText = "";
    data.documents.forEach((doc, idx) => {
      fullText += `=== ДОКУМЕНТ №${idx + 1}: ${doc.title} ===\n\n${doc.body}\n\n\n`;
    });
    downloadFile(fullText, "All_Documents.txt", "text/plain");
  });
});

// Экспорт всей базы в один файл HTML
document.getElementById("btnSaveDbHtml").addEventListener("click", () => {
  chrome.storage.local.get({ documents: [] }, (data) => {
    if (data.documents.length === 0) return alert("База данных пуста.");
    
    let combinedHtml = `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <title>Сборник материалов</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; line-height: 1.6; max-width: 800px; margin: 40px auto; padding: 0 20px; color: #1e293b; background-color: #f8fafc; }
    h1.main-title { text-align: center; border-bottom: 3px double #cbd5e1; padding-bottom: 20px; margin-bottom: 50px; color: #0f172a; }
    h2.doc-title { border-bottom: 2px solid #2563eb; padding-bottom: 10px; color: #1e40af; margin-top: 60px; page-break-before: always; }
    h3 { color: #1e3a8a; margin-top: 25px; }
    p { margin-bottom: 1.2em; text-align: justify; }
    ul { margin-bottom: 1.2em; padding-left: 20px; }
    li { margin-bottom: 0.5em; }
  </style>
</head>
<body>
  <h1 class="main-title">Сборник материалов (База знаний)</h1>`;

    data.documents.forEach((doc, idx) => {
      combinedHtml += `<h2 class="doc-title">Раздел №${idx + 1}. ${doc.title}</h2>`;
      
      const paragraphs = doc.body.split('\n\n');
      paragraphs.forEach(p => {
        const trimmed = p.trim();
        if (!trimmed) return;
        
        if (trimmed === doc.title) return; // Исключаем дублирование заголовка

        if (trimmed.length < 90 && !trimmed.endsWith('.') && !trimmed.endsWith(':') && !trimmed.includes('\n')) {
          combinedHtml += `  <h3>${trimmed}</h3>\n`;
        } else {
          const lines = trimmed.split('\n');
          if (lines.length > 1 && lines.every(l => l.trim().startsWith('-') || l.trim().startsWith('•') || /^\d+\./.test(l.trim()))) {
            combinedHtml += '  <ul>\n';
            lines.forEach(line => {
              const cleanLine = line.replace(/^[-•\d\.\s]+/, '').trim();
              combinedHtml += `    <li>${cleanLine}</li>\n`;
            });
            combinedHtml += '  </ul>\n';
          } else {
            const formattedParagraph = trimmed.replace(/\n/g, '<br>\n');
            combinedHtml += `  <p>${formattedParagraph}</p>\n`;
          }
        }
      });
    });

    combinedHtml += `</body>\n</html>`;
    downloadFile(combinedHtml, "All_Documents.html", "text/html");
  });
});

// Первичная инициализация статуса базы
updateStatus();