// popup.js

document.addEventListener('DOMContentLoaded', async () => {
  const cadInput = document.getElementById('cad-number-input');
  const findButton = document.getElementById('find-btn');
  const pasteJsonButton = document.getElementById('paste-json-btn');
  const resultDisplay = document.getElementById('result-display');
  const spinner = document.getElementById('spinner');
  const copyButton = document.getElementById('copy-btn');
  const placeholder = resultDisplay.querySelector('.placeholder');

  try {
    const lastState = await chrome.storage.session.get(['lastResult', 'lastCadNumber']);
    if (lastState.lastResult) {
      displayResult(lastState.lastResult);
    }
    if (lastState.lastCadNumber) {
      cadInput.value = lastState.lastCadNumber;
    }
  } catch (e) {
    console.error("Не удалось загрузить состояние сессии:", e);
  }

  const sevenDigitsRegions = [
    '06', '07', '09', '10', '11', '12', '13', '14', '17', '23',
    '24', '27', '31', '32', '35', '36', '41', '42', '47', '48',
    '50', '52', '53', '56', '57', '58', '59', '60', '61', '62',
    '63', '64', '65', '66', '67', '69', '70', '71', '72', '74',
    '77', '78', '79'];

  function formatCadastralNumber() {
    let value = cadInput.value;
    let cleanedValue = value.replace(/\D/g, ''); 
    const firstTwoDigits = cleanedValue.slice(0, 2);
    const isSevenDigitRegion = sevenDigitsRegions.includes(firstTwoDigits);
    const thirdBlockLength = isSevenDigitRegion ? 7 : 6;
    let formatted = '';
    if (cleanedValue.length > 0) formatted += cleanedValue.slice(0, 2);
    if (cleanedValue.length > 2) formatted += ':' + cleanedValue.slice(2, 4);
    if (cleanedValue.length > 4) {
        const remaining = cleanedValue.slice(4);
        remaining.length <= thirdBlockLength ? 
            formatted += ':' + remaining : 
            formatted += ':' + remaining.slice(0, thirdBlockLength) + ':' + remaining.slice(thirdBlockLength);
    }
    cadInput.value = formatted;
  }

  const handleFind = async () => {
    const cadNumber = cadInput.value.trim();
    if (!cadNumber) {
      displayError('Введите кадастровый номер');
      await chrome.storage.session.remove(['lastResult', 'lastCadNumber']);
      return;
    }
    await chrome.storage.session.set({ lastCadNumber: cadNumber });
    showLoadingState(`Запрос данных для ${cadNumber}...`);
    try {
      const activeTab = await getActiveNspdTab();
      const response = await sendMessageToTab(activeTab.id, { type: 'FETCH_NSPD_DATA', cadNumber: cadNumber });
      if (response && response.success) {
        processResponse(response.data);
      } else {
        throw new Error(response.error || 'Неизвестная ошибка от страницы');
      }
    } catch (error) {
      displayError(error.message);
      await chrome.storage.session.remove(['lastResult']);
    } finally {
      hideLoadingState();
    }
  };
  
  const handlePasteJson = async () => {
    showLoadingState('Обработка JSON из буфера...');
    await chrome.storage.session.remove(['lastCadNumber']);
    try {
        const clipboardText = await navigator.clipboard.readText();
        if (!clipboardText) throw new Error('Буфер обмена пуст.');
        const data = JSON.parse(clipboardText);
        processResponse(data);
    } catch (error) {
        displayError(`Ошибка вставки: ${error.message}`);
        await chrome.storage.session.remove(['lastResult']);
    } finally {
        hideLoadingState();
    }
  };

  const handleCopy = () => {
    const textToCopy = resultDisplay.cloneNode(true);
    textToCopy.querySelectorAll('.placeholder, #spinner, #copy-btn').forEach(el => el.remove());
    navigator.clipboard.writeText(textToCopy.textContent.trim()).then(() => {
        copyButton.innerHTML = '<i class="fa-solid fa-check"></i>';
        copyButton.classList.add('copied');
        setTimeout(() => {
            copyButton.innerHTML = '<i class="fa-regular fa-copy"></i>';
            copyButton.classList.remove('copied');
        }, 1500);
    }).catch(err => console.error('Ошибка копирования:', err));
  };
  
  function displayError(message) {
    resultDisplay.innerHTML = '';
    placeholder.textContent = message;
    placeholder.style.color = '#ff5555';
    resultDisplay.appendChild(placeholder);
    copyButton.style.display = 'none';
  }

  function displayResult(text) {
    resultDisplay.textContent = text;
    resultDisplay.appendChild(copyButton);
    copyButton.style.display = 'flex';
  }

  function showLoadingState(message) {
    spinner.style.display = 'block';
    copyButton.style.display = 'none';
    placeholder.textContent = message;
    placeholder.style.color = '#aaa';
    resultDisplay.innerHTML = '';
    resultDisplay.appendChild(placeholder);
    resultDisplay.appendChild(spinner);
    findButton.disabled = true;
    pasteJsonButton.disabled = true;
  }

  function hideLoadingState() {
    spinner.style.display = 'none';
    findButton.disabled = false;
    pasteJsonButton.disabled = false;
  }

  async function getActiveNspdTab() {
    return new Promise((resolve, reject) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const activeTab = tabs && tabs[0];
            if (!activeTab) {
                reject(new Error("Нет активной вкладки."));
            } else if (!activeTab.url || !activeTab.url.startsWith('https://nspd.gov.ru/map')) {
                reject(new Error('Активная вкладка должна быть nspd.gov.ru/map'));
            } else {
                resolve(activeTab);
            }
        });
    });
  }

  async function sendMessageToTab(tabId, message) {
    return new Promise((resolve, reject) => {
        chrome.tabs.sendMessage(tabId, message, (response) => {
            if (chrome.runtime.lastError) {
                reject(new Error(`Ошибка связи. Перезагрузите страницу nspd.gov.ru.`));
            } else {
                resolve(response);
            }
        });
    });
  }

  cadInput.addEventListener('input', formatCadastralNumber);
  findButton.addEventListener('click', handleFind);
  pasteJsonButton.addEventListener('click', handlePasteJson);
  copyButton.addEventListener('click', handleCopy);
  cadInput.addEventListener('keydown', (event) => event.key === 'Enter' && handleFind());

  async function processResponse(responseData) {
    try {
      const features = responseData?.data?.features || responseData?.features;
      if (!features || features.length === 0) throw new Error('Объекты не найдены в ответе API.');

      const targetMskSystem = 'EPSG:6331602';
      const mskSystemObject = (typeof COORDINATE_SYSTEMS !== 'undefined') 
        ? COORDINATE_SYSTEMS.find(s => s.value === targetMskSystem) : null;
      if (!mskSystemObject || !mskSystemObject.def) throw new Error(`Определение для ${targetMskSystem} не найдено.`);
      
      const offsetX = mskSystemObject.offsetX || 0;
      const offsetY = mskSystemObject.offsetY || 0;
      proj4.defs(targetMskSystem, mskSystemObject.def);
      
      const allMskBlocks = [];

      for (const feature of features) {
        const geometry = feature.geometry;
        if (!geometry || !geometry.coordinates) continue;
        
        // --- ИЗМЕНЕНИЕ ЗДЕСЬ: Добавляем .reverse() ---
        const convertRing = ring => ring.map(coordPair => {
            const wgs84Coords = proj4('EPSG:3857', 'EPSG:4326', coordPair);
            const mskCoords = proj4('EPSG:4326', targetMskSystem, wgs84Coords);
            const finalX = mskCoords[1] + offsetX;
            const finalY = mskCoords[0] + offsetY;
            return `${finalX.toFixed(2)}\t${finalY.toFixed(2)}`;
        }).reverse().join('\n'); // <-- ИЗМЕНЕНИЕ ЗДЕСЬ
        
        if (geometry.type === 'Polygon') {
          allMskBlocks.push(geometry.coordinates.map(convertRing).join('\n\n'));
        } else if (geometry.type === 'MultiPolygon') {
          allMskBlocks.push(geometry.coordinates.map(p => p.map(convertRing).join('\n\n')).join('\n\n---\n\n'));
        }
      }

      if (allMskBlocks.length === 0) throw new Error('Не найдено корректных геометрий для конвертации.');
      
      const resultText = allMskBlocks.join('\n\n');
      
      await chrome.storage.session.set({ lastResult: resultText });

      displayResult(resultText);

    } catch (error) {
      displayError(`Ошибка обработки: ${error.message}`);
      await chrome.storage.session.remove(['lastResult']);
    }
  }
});