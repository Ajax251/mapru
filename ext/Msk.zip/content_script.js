chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'FETCH_NSPD_DATA') {
    const cadNumber = message.cadNumber;
    const url = `https://nspd.gov.ru/api/geoportal/v2/search/geoportal?query=${encodeURIComponent(cadNumber)}&thematicSearchId=1`;

    fetch(url)
      .then(response => {
        if (!response.ok) {
          return response.text().then(text => {
            throw new Error(`Ошибка сети: ${response.status}. Ответ: ${text}`);
          });
        }
        return response.json();
      })
      .then(data => {
        sendResponse({ success: true, data: data });
      })
      .catch(error => {
        sendResponse({ success: false, error: error.message });
      });
    return true; 
  }
});