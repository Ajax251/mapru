chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'PROXY_FETCH') {
        const { url, method = 'GET', body, headers = {} } = message.payload;

        const options = {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                ...headers
            }
        };

        if (body && (method === 'POST' || method === 'PUT')) {
            options.body = JSON.stringify(body);
        }

        fetch(url, options)
            .then(async (response) => {
                const text = await response.text();
                if (!response.ok) {
                    return sendResponse({ success: false, error: `HTTP ${response.status}: ${text}` });
                }
                try {
                    // Пытаемся распарсить JSON, если это возможно
                    const data = JSON.parse(text);
                    sendResponse({ success: true, data: data });
                } catch (e) {
                    // Если вернулся не JSON (например, XML или ошибка текстом)
                    sendResponse({ success: true, data: text, isText: true });
                }
            })
            .catch(error => {
                sendResponse({ success: false, error: error.toString() });
            });

        return true; // Нужно для асинхронного ответа
    }
});