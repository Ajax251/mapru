document.addEventListener('DOMContentLoaded', async () => {
    // === ЭЛЕМЕНТЫ DOM ===
    const cadInput = document.getElementById('cad-number-input');
    const findButton = document.getElementById('find-btn');
    const pasteJsonButton = document.getElementById('paste-json-btn');
    const quarterOptions = document.getElementById('quarter-options');
    const resultDisplay = document.getElementById('result-display');
    const spinner = document.getElementById('spinner');
    const copyButton = document.getElementById('copy-btn');
    const mskDetectedLabel = document.getElementById('msk-detected');

    // === КОНСТАНТЫ И НАСТРОЙКИ ===
    const SUPABASE_URL = 'https://vznsatvyikahngdfvqho.supabase.co';
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZ6bnNhdHZ5aWthaG5nZGZ2cWhvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU0MjM3MDMsImV4cCI6MjA2MDk5OTcwM30.FJmk0lgIjqvcdV7p6C0riaxqS9QWKAuIHDZtkMYMJe4';
    
    // Инициализация Supabase клиента (если библиотека загружена)
    let supabaseClient = null;
    if (typeof supabase !== 'undefined' && supabase.createClient) {
        supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    } else {
        console.warn('Supabase JS не загружен. Функции ЕЗ будут недоступны.');
    }

    const CATEGORY_IDS = {
        ZU: 36368, BUILDINGS: 36369, CONSTRUCTIONS: 36383,
        ZOUIT: 36940, TERR_ZONES: 36315, SETTLEMENTS: 36281, MUNICIPAL: 36278
    };

    const sevenDigitsRegions = ['06', '07', '09', '10', '11', '12', '13', '14', '17', '23', '24', '27', '31', '32', '35', '36', '41', '42', '47', '48', '50', '52', '53', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '69', '70', '71', '72', '74', '77', '78', '79'];

    // === ОБРАБОТЧИКИ СОБЫТИЙ ===

    // Форматирование ввода и переключение режима
    cadInput.addEventListener('input', () => {
        let val = cadInput.value.replace(/[^\d]/g, '');
        let formatted = '';
        
        // Форматирование XX:XX:XXXXXXX
        if (val.length > 0) formatted += val.substring(0, 2);
        if (val.length > 2) formatted += ':' + val.substring(2, 4);
        
        const firstTwo = val.substring(0, 2);
        const quarterMaxLength = sevenDigitsRegions.includes(firstTwo) ? 7 : 6;
        
        if (val.length > 4) formatted += ':' + val.substring(4, 4 + quarterMaxLength);
        if (val.length > 4 + quarterMaxLength) formatted += ':' + val.substring(4 + quarterMaxLength);
        
        cadInput.value = formatted;

        // Определение режима: Квартал (2 двоеточия) или Объект (3 двоеточия)
        const parts = formatted.split(':');
        if (parts.length === 3 && parts[2].length >= 6) {
            // Режим КВАРТАЛ
            quarterOptions.style.display = 'block';
            findButton.innerHTML = '<i class="fa-solid fa-file-zipper"></i>';
            document.getElementById('chk-ez').disabled = !document.getElementById('chk-zu').checked;
            
            // Автодетект МСК
            if (typeof MskFinder !== 'undefined') {
                const msk = MskFinder.findMskCode(formatted);
                if (msk) {
                    mskDetectedLabel.textContent = `МСК ${msk}`;
                    mskDetectedLabel.style.display = 'inline-block';
                    mskDetectedLabel.style.background = '#e0f2f1';
                    mskDetectedLabel.style.color = '#00695c';
                } else {
                    mskDetectedLabel.style.display = 'none';
                }
            }
        } else {
            // Режим ОБЪЕКТ
            quarterOptions.style.display = 'none';
            findButton.innerHTML = '<i class="fa-solid fa-magnifying-glass"></i>';
        }
    });

    // Зависимость чекбокса ЕЗ от ЗУ
    document.getElementById('chk-zu').addEventListener('change', (e) => {
        const ez = document.getElementById('chk-ez');
        ez.disabled = !e.target.checked;
        if (!e.target.checked) ez.checked = false;
    });

    findButton.addEventListener('click', async () => {
        const val = cadInput.value.trim();
        if (!val) return;

        if (quarterOptions.style.display !== 'none') {
            await handleQuarterProcess(val);
        } else {
            await handleSingleObject(val);
        }
    });

    pasteJsonButton.addEventListener('click', async () => {
        showLoading('Чтение буфера...');
        try {
            const text = await navigator.clipboard.readText();
            const json = JSON.parse(text);
            processSingleObjectResponse(json); // Используем логику одиночного объекта для JSON
        } catch (e) {
            displayError("Ошибка JSON: " + e.message);
        }
    });
    
    copyButton.addEventListener('click', () => {
        const txt = resultDisplay.innerText;
        navigator.clipboard.writeText(txt).then(() => {
            const originalIcon = copyButton.innerHTML;
            copyButton.innerHTML = '<i class="fa-solid fa-check"></i>';
            setTimeout(() => copyButton.innerHTML = originalIcon, 1500);
        });
    });

    // === ЛОГИКА ДЛЯ ОДИНОЧНОГО ОБЪЕКТА ===
    async function handleSingleObject(cadNumber) {
        showLoading(`Поиск ${cadNumber}...`);
        try {
            const url = `https://nspd.gov.ru/api/geoportal/v2/search/geoportal?query=${encodeURIComponent(cadNumber)}&thematicSearchId=1`;
            const data = await fetchViaContentScript(url);
            processSingleObjectResponse(data);
        } catch (e) {
            displayError(e.message);
        }
    }

    function processSingleObjectResponse(data) {
        const features = data?.data?.features || data?.features;
        if (!features || features.length === 0) {
            displayError("Объекты не найдены");
            return;
        }

        // Берем дефолтную МСК или пытаемся определить (но для объекта сложнее)
        // Используем самую распространенную или первую попавшуюся из настроек веб-кода
        const targetCS = 'EPSG:6331602'; // Дефолтная МСК из вашего примера
        const sys = COORDINATE_SYSTEMS.find(s => s.value === targetCS);
        
        if (!sys) {
            displayError("Ошибка конфигурации СК");
            return;
        }

        proj4.defs(targetCS, sys.def);
        const offsetX = sys.offsetX || 0;
        const offsetY = sys.offsetY || 0;

        let output = "";
        
        features.forEach((f, idx) => {
            const num = f.properties?.options?.cad_num || f.properties?.cad_num || `Объект ${idx+1}`;
            output += `Кадастровый номер: ${num}\n`;
            
            if (!f.geometry) { output += "(нет геометрии)\n\n"; return; }
            
            // Рекурсивный обход координат
            const processRing = (ring) => {
                // В оригинальном коде было reverse() для одиночных объектов. Оставим это.
                const reversed = [...ring].reverse();
                return reversed.map(pt => {
                    // WGS84 -> MSK
                    const p = proj4('EPSG:3857', 'EPSG:4326', pt); // Сначала в градусы (если вход EPSG:3857)
                    // Но API NSPD обычно возвращает 3857. Proj4 умеет 3857 -> MSK напрямую, если прописано.
                    // В вашем примере: proj4('EPSG:3857', 'EPSG:4326', pt) -> потом proj4('EPSG:4326', target, ...)
                    // Сделаем как в MskFinder обычно: прямой трансформ 3857 -> Target
                    
                    const msk = proj4('EPSG:3857', targetCS, pt);
                    const x = (msk[1] + offsetX).toFixed(2);
                    const y = (msk[0] + offsetY).toFixed(2);
                    return `${x}\t${y}`;
                }).join('\n');
            };

            if (f.geometry.type === 'Polygon') {
                output += f.geometry.coordinates.map(processRing).join('\n\n');
            } else if (f.geometry.type === 'MultiPolygon') {
                output += f.geometry.coordinates.map(poly => poly.map(processRing).join('\n\n')).join('\n---\n');
            }
            output += "\n\n";
        });

        displayResult(output);
    }

    // === ЛОГИКА ДЛЯ КВАРТАЛА (ZIP XML) ===
    async function handleQuarterProcess(quarterNumber) {
        showLoading(`Анализ квартала ${quarterNumber}...`);
        
        try {
            // 1. Получаем геометрию квартала
            const qUrl = `https://nspd.gov.ru/api/geoportal/v2/search/geoportal?thematicSearchId=2&query=${quarterNumber}`;
            const qData = await fetchViaContentScript(qUrl);
            const quarterFeature = qData?.data?.features?.[0];
            
            if (!quarterFeature?.geometry) throw new Error('Геометрия квартала не найдена. Проверьте номер.');

            // 2. Определяем СК
            let targetCS = 'EPSG:6331602'; // Fallback
            let mskCode = null;
            let offsets = { x: 0, y: 0 };
            
            if (typeof MskFinder !== 'undefined') {
                mskCode = MskFinder.findMskCode(quarterNumber);
                if (mskCode) {
                    const found = COORDINATE_SYSTEMS.find(s => s.text.includes(`МСК ${mskCode}`));
                    if (found) {
                        targetCS = found.value;
                        offsets.x = found.offsetX || 0;
                        offsets.y = found.offsetY || 0;
                        proj4.defs(targetCS, found.def);
                    }
                }
            }
            
            if (!mskCode) {
               // Если не нашли автоматически - используем дефолт, но предупредим в консоли
               console.warn('МСК не определена автоматически, используется дефолтная.');
            }

            // 3. Собираем данные
            const allData = { quarter: qData.data };
            const tasks = [];

            // ЗУ
            if (document.getElementById('chk-zu').checked) {
                showLoading('Загрузка участков...');
                const zuData = await fetchIntersects(quarterFeature.geometry, CATEGORY_IDS.ZU);
                allData.zu = zuData;
            }

            // Единое землепользование (Supabase)
            let ezMap = new Map();
            if (document.getElementById('chk-zu').checked && document.getElementById('chk-ez').checked && allData.zu?.features?.length > 0) {
                showLoading('Поиск ЕЗ (Supabase)...');
                if (supabaseClient) {
                    const cadNumbers = allData.zu.features.map(f => f.properties.options?.cad_num).filter(Boolean);
                    ezMap = await fetchEzDataBatch(cadNumbers);
                }
            }

            // ОКС
            if (document.getElementById('chk-oks').checked) {
                showLoading('Загрузка зданий...');
                const bPromise = fetchIntersects(quarterFeature.geometry, CATEGORY_IDS.BUILDINGS).then(d => allData.buildings = d);
                const cPromise = fetchIntersects(quarterFeature.geometry, CATEGORY_IDS.CONSTRUCTIONS).then(d => allData.constructions = d);
                await Promise.all([bPromise, cPromise]);
            }

            // ЗОУИТ (Intersects)
            if (document.getElementById('chk-zones').checked) {
                showLoading('Загрузка ЗОУИТ...');
                allData.zouit = await fetchIntersects(quarterFeature.geometry, CATEGORY_IDS.ZOUIT);
                
                // Терр зоны (WMS) - если есть turf
                if (typeof turf !== 'undefined') {
                    showLoading('Загрузка терр. зон (WMS)...');
                    allData.terrZones = await fetchWms(quarterFeature.geometry, CATEGORY_IDS.TERR_ZONES);
                }
            }

            // Границы НП/МО (WMS)
            if (document.getElementById('chk-mun').checked && typeof turf !== 'undefined') {
                showLoading('Загрузка границ...');
                const sPromise = fetchWms(quarterFeature.geometry, CATEGORY_IDS.SETTLEMENTS).then(d => allData.settlements = d);
                const mPromise = fetchWms(quarterFeature.geometry, CATEGORY_IDS.MUNICIPAL).then(d => allData.municipal = d);
                await Promise.all([sPromise, mPromise]);
            }

            // 4. Генерация XML
            showLoading('Формирование XML...');
            // Включаем границы квартала в XML только если выбран чекбокс
            const includeQuarterBounds = document.getElementById('chk-bounds').checked;
            
            // ГЕНЕРАЦИЯ
            const { xmlContent, filenameBase } = convertJsonToXml(
                allData, 
                quarterNumber, 
                { 
                    targetCS, 
                    offsets, 
                    includeQuarterBounds 
                }, 
                ezMap
            );

            // 5. ZIP и Скачивание
            showLoading('Сжатие в ZIP...');
            const zip = new JSZip();
            zip.file(`${filenameBase}.xml`, xmlContent);
            
            const content = await zip.generateAsync({ type: "blob", compression: "DEFLATE" });
            const url = URL.createObjectURL(content);
            
            chrome.downloads.download({
                url: url,
                filename: `${filenameBase}.zip`,
                saveAs: true
            });

            // Итоги
            const count = (allData.zu?.features?.length || 0) + (allData.buildings?.features?.length || 0);
            displayResult(`Готово!\nФайл отправлен на скачивание.\n\nМСК: ${mskCode || 'Не определена (Default)'}\nОбъектов: ~${count}\nЕЗ найдено: ${ezMap.size}`);

        } catch (e) {
            displayError("Ошибка процесса: " + e.message);
            console.error(e);
        }
    }

    // === СЕТЕВЫЕ ФУНКЦИИ ===

    async function fetchViaContentScript(url, method = 'GET', body = null) {
        const tab = await getActiveNspdTab();
        const response = await chrome.tabs.sendMessage(tab.id, {
            type: 'PROXY_FETCH',
            payload: { url, method, body }
        });
        
        if (!response) throw new Error('Нет ответа от страницы');
        if (!response.success) throw new Error(response.error);
        
        return response.data;
    }

    async function fetchIntersects(geometry, catId) {
        return await fetchViaContentScript(
            'https://nspd.gov.ru/api/geoportal/v1/intersects?typeIntersect=fullObject',
            'POST',
            { 
                geom: { type: "FeatureCollection", features: [{ type: "Feature", geometry, properties: {} }] }, 
                categories: [{ "id": catId }] 
            }
        );
    }

    async function fetchWms(geometry, layerId) {
        const bbox = turf.bbox(geometry);
        const cx = (bbox[0] + bbox[2]) / 2;
        const cy = (bbox[1] + bbox[3]) / 2;
        // Запрос с запасом вокруг центра
        const bboxStr = `${cx-0.1},${cy-0.1},${cx+0.1},${cy+0.1}`;
        const url = `https://nspd.gov.ru/api/aeggis/v4/${layerId}/wms?REQUEST=GetFeatureInfo&QUERY_LAYERS=${layerId}&SERVICE=WMS&VERSION=1.3.0&FORMAT=image%2Fpng%2F&INFO_FORMAT=application%2Fjson&FEATURE_COUNT=50&I=256&J=256&WIDTH=512&HEIGHT=512&CRS=EPSG%3A3857&BBOX=${bboxStr}`;
        return await fetchViaContentScript(url);
    }

    async function getActiveNspdTab() {
        return new Promise((resolve, reject) => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                const t = tabs[0];
                if (t && t.url && t.url.includes('nspd.gov.ru')) {
                    resolve(t);
                } else {
                    reject(new Error("Откройте вкладку nspd.gov.ru/map"));
                }
            });
        });
    }

    // === SUPABASE (Batch Fetch) ===
    async function fetchEzDataBatch(cadNumbers) {
        if (!supabaseClient) return new Map();
        
        const targets = cadNumbers.filter(cn => {
            if (!cn) return false;
            const parts = cn.split(':');
            return parts.length > 2 && !/^0{6,7}$/.test(parts[2]);
        });
        
        if (targets.length === 0) return new Map();

        const resultMap = new Map();
        const chunkSize = 200; // Безопасный размер чанка
        
        for (let i = 0; i < targets.length; i += chunkSize) {
            const chunk = targets.slice(i, i + chunkSize);
            const { data, error } = await supabaseClient
                .from('EZ')
                .select('EZ, ZU')
                .in('ZU', chunk);

            if (!error && data) {
                data.forEach(row => resultMap.set(row.ZU, row.EZ));
            }
        }
        return resultMap;
    }

    // === XML ГЕНЕРАТОР (ПОЛНАЯ ФУНКЦИЯ) ===
    function convertJsonToXml(allData, quarterNumber, options, ezMap = new Map()) {
        const { targetCS, offsets, includeQuarterBounds } = options;
        const offsetX = offsets.x;
        const offsetY = offsets.y;
        
        // В XML X и Y меняются местами (X - Север, Y - Восток)
        const swapXmlCoords = true; 
        const reverseDirection = true; // Как в веб-примере

        const today = new Date();
        const dateString = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
        const filenameBase = `${quarterNumber.replace(/:/g, '_')} ${dateString} NSPD`;
        const escapeXml = (unsafe) => unsafe ? String(unsafe).replace(/[<>&'"]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;','\'':'&apos;','"':'&quot;'}[c])) : '';

        // --- Вспомогательные функции XML ---
        const generateOrdinates = (points) => {
            return points.map((point, i) => {
                // Перевод в МСК
                const convertedPoint = proj4('EPSG:3857', targetCS, point);
                const decimalPlaces = 2;
                
                const y_from_proj = convertedPoint[0] + offsetY;
                const x_from_proj = convertedPoint[1] + offsetX;
                
                // Swap logic
                const [xml_x, xml_y] = swapXmlCoords ? [x_from_proj, y_from_proj] : [y_from_proj, x_from_proj];
                
                return `<ordinate><x>${xml_x.toFixed(decimalPlaces)}</x><y>${xml_y.toFixed(decimalPlaces)}</y><ord_nmb>${i + 1}</ord_nmb></ordinate>`;
            }).join('');
        };

        const generateContoursXml = (geometry, parentTag) => {
            if (!geometry || !geometry.coordinates) return '';
            const skIdText = "MSK"; // Можно улучшить, беря имя из COORDINATE_SYSTEMS, но MSK сойдет
            
            let allRings = [];
            if (geometry.type === 'Polygon') allRings = geometry.coordinates;
            else if (geometry.type === 'MultiPolygon') allRings = geometry.coordinates.flat(1);
            else return '';

            return allRings.map((ring, contourIndex) => {
                if(!ring || ring.length < 1) return '';
                let points = ring;
                if (reverseDirection) points = [...points].reverse();
                
                const ordinatesXml = generateOrdinates(points);
                const spatialElement = `<spatial_element><ordinates>${ordinatesXml}</ordinates></spatial_element>`;
                
                if (parentTag === 'spatial_data') {
                     return `<spatials_elements>${spatialElement}</spatials_elements>`;
                }
                return `<contour><number_pp>${contourIndex + 1}</number_pp><entity_spatial><sk_id>${escapeXml(skIdText)}</sk_id><spatials_elements>${spatialElement}</spatials_elements></entity_spatial></contour>`;
            }).join('');
        };

        const generateLandRecordXml = (f) => {
            const p = f.properties.options || {};
            const areaVal = p.specified_area || p.land_record_area_verified || p.declared_area || p.land_record_area_declaration || p.land_record_area || '0';
            const areaBlock = (p.specified_area || p.land_record_area_verified) ? `<area><value>${escapeXml(areaVal)}</value><inaccuracy>0</inaccuracy></area>` : `<area><value>${escapeXml(areaVal)}</value></area>`;
            
            const parentEz = ezMap.get(p.cad_num);
            let subtypeBlock = '';
            let cadLinksBlock = '';
            let objectTypeValue = 'Земельный участок';

            if (parentEz) {
                objectTypeValue = 'Обособленный участок';
                subtypeBlock = `<subtype><code>03</code><value>Обособленный участок</value></subtype>`;
                cadLinksBlock = `<cad_links><common_land><common_land_cad_number><cad_number>${escapeXml(parentEz)}</cad_number></common_land_cad_number></common_land></cad_links>`;
            }

            return `<land_record><object><common_data><type><code>002001001000</code><value>${objectTypeValue}</value></type><cad_number>${escapeXml(p.cad_num)}</cad_number></common_data>${subtypeBlock}</object>${cadLinksBlock}<params>${areaBlock}<category><type><code>-</code><value>${escapeXml(p.land_record_category_type)}</value></type></category><permitted_use><permitted_use_established><by_document>${escapeXml(p.permitted_use_established_by_document)}</by_document></permitted_use_established></permitted_use></params><address_location><address><readable_address>${escapeXml(p.readable_address)}</readable_address></address></address_location><cost><value>${escapeXml(p.cost_value)}</value></cost><contours_location><contours>${generateContoursXml(f.geometry)}</contours></contours_location></land_record>`;
        };

        const generateBuildRecordXml = (f) => {
             const p = f.properties.options || {};
             return `<build_record><object><common_data><type><code>002001002000</code><value>Здание</value></type><cad_number>${escapeXml(p.cad_num)}</cad_number></common_data></object><params><area>${escapeXml(p.build_record_area)}</area><purpose><code>-</code><value>${escapeXml(p.purpose)}</value></purpose></params><address_location><address><readable_address>${escapeXml(p.readable_address)}</readable_address></address></address_location><cost><value>${escapeXml(p.cost_value)}</value></cost><contours>${generateContoursXml(f.geometry)}</contours></build_record>`;
        };

        const generateConstructionRecordXml = (f) => {
            const p = f.properties.options || {};
            const baseParam = p.params_extension ? `<extension>${escapeXml(p.params_extension)}</extension>` : (p.params_area ? `<area>${escapeXml(p.params_area)}</area>` : '');
            return `<construction_record><object><common_data><type><code>002001004000</code><value>Сооружение</value></type><cad_number>${escapeXml(p.cad_number)}</cad_number></common_data></object><params><base_parameters><base_parameter>${baseParam}</base_parameter></base_parameters><purpose>${escapeXml(p.params_purpose)}</purpose></params><address_location><address><readable_address>${escapeXml(p.address_readable_address)}</readable_address></address></address_location><cost><value>${escapeXml(p.cost_value)}</value></cost><contours>${generateContoursXml(f.geometry)}</contours></construction_record>`;
        };

        const generateBoundaryRecordXml = (f, tagName) => {
            const p = f.properties.options || {};
            const regNumb = p.reg_numb_border || p.brd_nmb || f.properties.descr;
            const typeCode = { 'Граница муниципального образования': '3', 'Граница населенного пункта': '4', 'Территориальная зона': '7' }[p.type_boundary_value] || '5';
            return `<${tagName}><record_info><registration_date>${escapeXml(p.registration_date)}</registration_date></record_info><b_object_${tagName.replace('_record','')}><b_object><reg_numb_border>${escapeXml(regNumb)}</reg_numb_border><type_boundary><code>${typeCode}</code><value>${escapeXml(p.type_boundary_value || f.properties.categoryName)}</value></type_boundary></b_object><name_by_doc>${escapeXml(p.name_by_doc || p.name || f.properties.label)}</name_by_doc></b_object_${tagName.replace('_record','')}><b_contours_location><contours>${generateContoursXml(f.geometry)}</contours></b_contours_location></${tagName}>`;
        };

        // --- Сборка ---
        let landRecordsXml = '', buildRecordsXml = '', constructionRecordsXml = '', zonesAndTerritoriesXml = '', municipalBoundariesXml = '', inhabitedLocalityBoundariesXml = '', spatialDataXml = '';

        if (allData.zu?.features) allData.zu.features.forEach(f => landRecordsXml += generateLandRecordXml(f));
        if (allData.buildings?.features) allData.buildings.features.forEach(f => buildRecordsXml += generateBuildRecordXml(f));
        if (allData.constructions?.features) allData.constructions.features.forEach(f => constructionRecordsXml += generateConstructionRecordXml(f));
        if (allData.zouit?.features) allData.zouit.features.forEach(f => zonesAndTerritoriesXml += generateBoundaryRecordXml(f, 'zones_and_territories_record'));
        if (allData.terrZones?.features) allData.terrZones.features.forEach(f => zonesAndTerritoriesXml += generateBoundaryRecordXml(f, 'zones_and_territories_record'));
        if (allData.settlements?.features) allData.settlements.features.forEach(f => inhabitedLocalityBoundariesXml += generateBoundaryRecordXml(f, 'inhabited_locality_boundary_record'));
        if (allData.municipal?.features) allData.municipal.features.forEach(f => municipalBoundariesXml += generateBoundaryRecordXml(f, 'municipal_boundary_record'));
        
        if (includeQuarterBounds && allData.quarter?.features) {
            allData.quarter.features.forEach(f => {
                spatialDataXml = `<spatial_data><entity_spatial><sk_id>MSK</sk_id>${generateContoursXml(f.geometry, 'spatial_data')}</entity_spatial></spatial_data>`;
            });
        }

        const fullXml = `<?xml version="1.0" encoding="UTF-8"?>
<extract_cadastral_plan_territory>
    <details_statement><group_top_requisites><organ_registr_rights>EPSG3857-EXTENSION</organ_registr_rights><date_formation>${dateString}</date_formation><registration_number></registration_number></group_top_requisites></details_statement>
    <cadastral_blocks><cadastral_block>
        <cadastral_number>${escapeXml(quarterNumber)}</cadastral_number>
        ${spatialDataXml}
        <record_data><base_data>
            ${landRecordsXml ? `<land_records>${landRecordsXml}</land_records>` : ''}
            ${buildRecordsXml ? `<build_records>${buildRecordsXml}</build_records>` : ''}
            ${constructionRecordsXml ? `<construction_records>${constructionRecordsXml}</construction_records>` : ''}
        </base_data></record_data>
        ${municipalBoundariesXml ? `<municipal_boundaries>${municipalBoundariesXml}</municipal_boundaries>` : ''}
        ${inhabitedLocalityBoundariesXml ? `<inhabited_locality_boundaries>${inhabitedLocalityBoundariesXml}</inhabited_locality_boundaries>` : ''}
        ${zonesAndTerritoriesXml ? `<zones_and_territories_boundaries>${zonesAndTerritoriesXml}</zones_and_territories_boundaries>` : ''}
    </cadastral_block></cadastral_blocks>
</extract_cadastral_plan_territory>`;

        return { xmlContent: fullXml, filenameBase };
    }

    // === UTILS ===
    function showLoading(msg) {
        spinner.style.display = 'block';
        copyButton.style.display = 'none';
        resultDisplay.querySelector('.placeholder').textContent = msg;
        findButton.disabled = true;
    }

    function displayResult(text) {
        spinner.style.display = 'none';
        resultDisplay.innerText = text; // innerText сохраняет переносы строк
        copyButton.style.display = 'flex';
        findButton.disabled = false;
    }

    function displayError(msg) {
        spinner.style.display = 'none';
        resultDisplay.innerText = msg;
        resultDisplay.style.color = '#d32f2f';
        findButton.disabled = false;
    }
});