import os
import tempfile
import cv2
import numpy as np
from PIL import Image
from pdf2image import convert_from_path
from flask import Flask, request, send_file, render_template

app = Flask(__name__)

# --- ВАШ ПУТЬ К POPPLER ---
POPPLER_DIR = r"c:\poppler\Library\bin"

def hex_to_rgb(hex_color):
    """Преобразует #RRGGBB в кортеж (R, G, B)"""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def detect_background_color(image_array):
    """Берет кусок 50x50 пикселей из левого верхнего угла и вычисляет средний цвет"""
    patch = image_array[10:60, 10:60]
    avg_color_per_row = np.average(patch, axis=0)
    avg_color = np.average(avg_color_per_row, axis=0)
    return (int(avg_color[0]), int(avg_color[1]), int(avg_color[2]))

def process_page(image_array, mode="clean", target_color=(255, 255, 255)):
    """
    Улучшенный алгоритм: создает маску из ч/б версии, но цвет применяет к оригинальной
    RGB-картинке. Это сохраняет синие печати и подписи!
    """
    # 1. Получаем серую версию для анализа (поиска текста)
    gray = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)

    # 2. Создаем маску текста. 
    # cv2.THRESH_BINARY_INV делает текст белым (255), а фон черным (0)
    mask = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 51, 15
    )

    # 3. Берем оригинальную цветную картинку
    result_img = image_array.copy()

    # 4. Там, где маска черная (это фон), закрашиваем нужным цветом.
    # Текст и синие ручки (где маска 255) остаются нетронутыми!
    background_condition = (mask == 0)
    result_img[background_condition] = target_color

    return result_img

@app.route('/')
def index():
    # Отдаем HTML интерфейс
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process_pdf():
    if 'file' not in request.files:
        return "Файл не найден", 400

    file = request.files['file']
    dpi = int(request.form.get('dpi', 300))
    mode = request.form.get('mode', 'clean')
    auto_color = request.form.get('auto_color') == 'true'
    bg_color_hex = request.form.get('bg_color', '#ffffff')

    # Временные пути для файлов
    temp_dir = tempfile.mkdtemp()
    input_pdf_path = os.path.join(temp_dir, "input.pdf")
    output_pdf_path = os.path.join(temp_dir, "output.pdf")
    
    file.save(input_pdf_path)

    try:
        # Конвертируем PDF в картинки
        pages = convert_from_path(input_pdf_path, dpi=dpi, poppler_path=POPPLER_DIR)
        
        cleaned_pages = []
        target_color = (255, 255, 255) # По умолчанию белый

        # Если выбрали заливку и автоопределение
        if mode == "fill":
            if auto_color:
                # Определяем цвет по первой странице
                first_page_array = np.array(pages[0])
                target_color = detect_background_color(first_page_array)
            else:
                target_color = hex_to_rgb(bg_color_hex)

        for page in pages:
            img_array = np.array(page)
            
            # Обрабатываем с сохранением цвета
            processed_array = process_page(img_array, mode=mode, target_color=target_color)
            
            cleaned_image = Image.fromarray(processed_array)
            cleaned_pages.append(cleaned_image)

        # Сохраняем результат
        cleaned_pages[0].save(
            output_pdf_path,
            save_all=True,
            append_images=cleaned_pages[1:],
            resolution=dpi
        )

        # Отправляем файл пользователю
        return send_file(output_pdf_path, as_attachment=True, download_name="Cleaned.pdf")

    except Exception as e:
        return str(e), 500

if __name__ == '__main__':
    # Запускаем локальный веб-сервер
    print("Сервер запущен! Откройте в браузере ссылку: http://127.0.0.1:5000")
    app.run(debug=True, port=5000)