# Get-SystemReport.ps1
# Скрипт генерации детального HTML-отчета о системе

$ErrorActionPreference = "SilentlyContinue"

# Проверка прав администратора
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

# Настройка пути для сохранения отчета (на Рабочий стол или во временную папку)
$outDir = if ($PSScriptRoot) { $PSScriptRoot } else { [Environment]::GetFolderPath("Desktop") }
$outputPath = Join-Path $outDir "SystemReport.html"

Write-Host "Сбор системных данных..." -ForegroundColor Cyan

# ==========================================
# 1. СВЕДЕНИЯ ОБ ОС И ОБЩАЯ ИНФОРМАЦИЯ
# ==========================================
$os = Get-CimInstance Win32_OperatingSystem
$cs = Get-CimInstance Win32_ComputerSystem
$bios = Get-CimInstance Win32_BIOS
$csp = Get-CimInstance Win32_ComputerSystemProduct

$computerName = $env:COMPUTERNAME
$osName = $os.Caption
$osBuild = $os.BuildNumber
$osInstallDate = if ($os.InstallDate) { $os.InstallDate.ToString("dd.MM.yyyy HH:mm") } else { "N/A" }
$manufacturer = $cs.Manufacturer
$model = $cs.Model
$domain = $cs.Domain

# Аптайм
$lastBoot = $os.LastBootUpTime
$uptimeSpan = (Get-Date) - $lastBoot
$uptimeString = "$($uptimeSpan.Days)д $($uptimeSpan.Hours)ч $($uptimeSpan.Minutes)м"

# ==========================================
# 2. АППАРАТНАЯ ЧАСТЬ (CPU, RAM, GPU)
# ==========================================
# CPU
$cpu = Get-CimInstance Win32_Processor
$cpuName = $cpu.Name
$cpuCores = $cpu.NumberOfCores
$cpuLogical = $cpu.NumberOfLogicalProcessors
$cpuMaxSpeed = [Math]::Round($cpu.MaxClockSpeed / 1000, 2)

# RAM
$ramSticks = Get-CimInstance Win32_PhysicalMemory
$ramSticksCount = if ($ramSticks) { $ramSticks.Count } else { 0 }
$ramSpeed = if ($ramSticks) { "$($ramSticks[0].Speed) МГц" } else { "N/A" }
$ramManufacturer = if ($ramSticks) { $ramSticks[0].Manufacturer.Trim() } else { "N/A" }
$totalRamGB = [Math]::Round(($os.TotalVisibleMemorySize / 1MB), 2)
$freeRamGB = [Math]::Round(($os.FreePhysicalMemory / 1MB), 2)
$usedRamGB = [Math]::Round(($totalRamGB - $freeRamGB), 2)
$ramPercent = [Math]::Round(($usedRamGB / $totalRamGB) * 100, 1)

# GPU
$gpus = Get-CimInstance Win32_VideoController
$gpuString = if ($gpus) { ($gpus | ForEach-Object { $_.Name }) -join ", " } else { "N/A" }

# ==========================================
# 3. ФИЗИЧЕСКИЕ НАКОПИТЕЛИ (S.M.A.R.T, модели, износ)
# ==========================================
$physicalDisks = @()
if (Get-Command Get-PhysicalDisk -ErrorAction SilentlyContinue) {
    $disks = Get-PhysicalDisk
    foreach ($d in $disks) {
        $diskDetail = Get-Disk -Number $d.DeviceId -ErrorAction SilentlyContinue
        $busType = if ($diskDetail) { $diskDetail.BusType } else { "Unknown" }
        $physicalDisks += [PSCustomObject]@{
            Number    = $d.DeviceId
            Model     = $d.Model
            Type      = $d.MediaType
            Size      = "$([Math]::Round($d.Size / 1GB, 2)) GB"
            BusType   = $busType
            Status    = $d.OperationalStatus -join ", "
            Health    = $d.HealthStatus
            Serial    = $d.SerialNumber.Trim()
        }
    }
} else {
    # Резервный сбор для старых систем (Win7 / Server 2008)
    $disks = Get-CimInstance Win32_DiskDrive
    foreach ($d in $disks) {
        $physicalDisks += [PSCustomObject]@{
            Number    = $d.Index
            Model     = $d.Model
            Type      = if ($d.Caption -like "*SSD*") { "SSD" } else { "HDD" }
            Size      = "$([Math]::Round($d.Size / 1GB, 2)) GB"
            BusType   = $d.InterfaceType
            Status    = $d.Status
            Health    = "N/A"
            Serial    = $d.SerialNumber
        }
    }
}

# ==========================================
# 4. ЛОГИЧЕСКИЕ ДИСКИ
# ==========================================
$logicalDisks = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
    $totalSize = $_.Size
    $freeSpace = $_.FreeSpace
    $usedSpace = $totalSize - $freeSpace
    $percentFree = if ($totalSize -gt 0) { [Math]::Round(($freeSpace / $totalSize) * 100, 1) } else { 0 }
    [PSCustomObject]@{
        Drive       = $_.DeviceID
        VolumeName  = $_.VolumeName
        FileSystem  = $_.FileSystem
        TotalSize   = "$([Math]::Round($totalSize / 1GB, 2)) GB"
        FreeSpace   = "$([Math]::Round($freeSpace / 1GB, 2)) GB"
        UsedSpace   = "$([Math]::Round($usedSpace / 1GB, 2)) GB"
        PercentFree = $percentFree
    }
}

# ==========================================
# 5. СЕТЕВЫЕ ИНТЕРФЕЙСЫ И СВЯЗЬ
# ==========================================
$netAdapters = @()
if (Get-Command Get-NetAdapter -ErrorAction SilentlyContinue) {
    $adapters = Get-NetAdapter | Where-Object { $_.PhysicalMediumType -ne "Unspecified" }
    foreach ($a in $adapters) {
        $ips = Get-NetIPAddress -InterfaceAlias $a.Name -AddressFamily IPv4 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty IPAddress
        $netAdapters += [PSCustomObject]@{
            Name   = $a.Name
            Status = $a.Status
            Speed  = $a.LinkSpeed
            MAC    = $a.MacAddress
            IPs    = $ips -join ", "
        }
    }
} else {
    $adapters = Get-CimInstance Win32_NetworkAdapterConfiguration -Filter "IPEnabled=True"
    foreach ($a in $adapters) {
        $netAdapters += [PSCustomObject]@{
            Name   = $a.Description
            Status = "Active"
            Speed  = "N/A"
            MAC    = $a.MACAddress
            IPs    = $a.IPAddress -join ", "
        }
    }
}

# Тест интернет-соединения и внешнего IP
$internetStatus = "Disconnected"
$externalIP = "N/A"
try {
    $testConnection = Test-Connection -ComputerName 8.8.8.8 -Count 1 -Quiet -ErrorAction SilentlyContinue
    if ($testConnection) {
        $internetStatus = "Connected"
        $externalIP = Invoke-RestMethod -Uri "https://api.ipify.org" -TimeoutSec 3 -ErrorAction SilentlyContinue
    }
} catch {}

# ==========================================
# 6. БЕЗОПАСНОСТЬ (BitLocker, Defender, Админы)
# ==========================================
# Windows Defender
$defenderStatus = "N/A"
$defenderRealtime = "N/A"
if (Get-Command Get-MpComputerStatus -ErrorAction SilentlyContinue) {
    try {
        $mp = Get-MpComputerStatus -ErrorAction SilentlyContinue
        $defenderStatus = if ($mp.AntivirusEnabled) { "Enabled" } else { "Disabled" }
        $defenderRealtime = if ($mp.RealTimeProtectionEnabled) { "Enabled" } else { "Disabled" }
    } catch {
        $defenderStatus = "Access Denied"
    }
}

# Брандмауэр
$firewallProfiles = @()
if (Get-Command Get-NetFirewallProfile -ErrorAction SilentlyContinue) {
    try {
        $fw = Get-NetFirewallProfile | Select-Object Name, Enabled
        foreach ($f in $fw) {
            $firewallProfiles += [PSCustomObject]@{
                Profile = $f.Name
                State   = if ($f.Enabled -eq "True" -or $f.Enabled -eq $true) { "Enabled" } else { "Disabled" }
            }
        }
    } catch {
        $firewallProfiles += [PSCustomObject]@{ Profile = "All"; State = "Access Denied" }
    }
}

# BitLocker
$bitlockerStatus = @()
if (Get-Command Get-BitLockerVolume -ErrorAction SilentlyContinue) {
    try {
        $bl = Get-BitLockerVolume -ErrorAction SilentlyContinue
        foreach ($b in $bl) {
            $bitlockerStatus += [PSCustomObject]@{
                MountPoint        = $b.MountPoint
                ProtectionStatus  = $b.ProtectionStatus
                EncryptionPercent = "$($b.EncryptionPercentage)%"
            }
        }
    } catch {
        $bitlockerStatus += [PSCustomObject]@{ MountPoint = "All"; ProtectionStatus = "Access Denied"; EncryptionPercent = "N/A" }
    }
}

# Локальные администраторы
$localAdmins = @()
if (Get-Command Get-LocalGroupMember -ErrorAction SilentlyContinue) {
    try {
        $localAdmins = Get-LocalGroupMember -Group "Administrators" | Select-Object Name, PrincipalSource
    } catch {
        try {
            $group = [ADSI]"WinNT://$env:COMPUTERNAME/Administrators,group"
            $localAdmins = $group.psbase.Invoke("Members") | ForEach-Object {
                $name = $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null)
                [PSCustomObject]@{ Name = $name; PrincipalSource = "Local" }
            }
        } catch {
            $localAdmins = @([PSCustomObject]@{ Name = "Access Denied"; PrincipalSource = "N/A" })
        }
    }
}

# ==========================================
# 7. ОБНОВЛЕНИЯ И АВТОЗАГРУЗКА
# ==========================================
# Установленные KB
$lastUpdates = @()
try {
    $updates = Get-CimInstance Win32_QuickFixEngineering | Sort-Object InstalledOn -Descending | Select-Object -First 5
    foreach ($u in $updates) {
        $lastUpdates += [PSCustomObject]@{
            HotFixID    = $u.HotFixID
            Description = $u.Description
            InstalledBy = $u.InstalledBy
            InstalledOn = if ($u.InstalledOn) { $u.InstalledOn.ToString("dd.MM.yyyy") } else { "N/A" }
        }
    }
} catch {}

# Автозагрузка
$startupApps = @()
try {
    $startups = Get-CimInstance Win32_StartupCommand | Select-Object Name, Command, User | Select-Object -First 8
    foreach ($s in $startups) {
        $startupApps += [PSCustomObject]@{
            Name    = $s.Name
            Command = $s.Command
            User    = $s.User
        }
    }
} catch {}

# ==========================================
# 8. ПРОИЗВОДИТЕЛЬНОСТЬ И КРИТИЧЕСКИЕ СОБЫТИЯ
# ==========================================
# Топ CPU процессов
$topCpu = Get-Process | Where-Object {$_.CPU -ne $null} | Sort-Object CPU -Descending | Select-Object -First 5 | ForEach-Object {
    [PSCustomObject]@{
        ID     = $_.Id
        Name   = $_.ProcessName
        CPU    = "$([Math]::Round($_.CPU, 1))%"
        Memory = "$([Math]::Round($_.WorkingSet / 1MB, 1)) MB"
    }
}

# Топ RAM процессов
$topRam = Get-Process | Sort-Object WorkingSet -Descending | Select-Object -First 5 | ForEach-Object {
    [PSCustomObject]@{
        ID     = $_.Id
        Name   = $_.ProcessName
        Memory = "$([Math]::Round($_.WorkingSet / 1MB, 1)) MB"
        CPU    = if ($_.CPU) { "$([Math]::Round($_.CPU, 1))%" } else { "0%" }
    }
}

# Логи критических ошибок за 24 часа
$eventLogs = @()
try {
    $logFilter = @{
        LogName   = @('System', 'Application')
        Level     = @(1, 2) # 1 - Critical, 2 - Error
        StartTime = (Get-Date).AddDays(-1)
    }
    $events = Get-WinEvent -FilterHashtable $logFilter -MaxEvents 10 -ErrorAction SilentlyContinue
    foreach ($e in $events) {
        $eventLogs += [PSCustomObject]@{
            Time    = $e.TimeCreated.ToString("dd.MM.yyyy HH:mm")
            LogName = $e.LogName
            Source  = $e.ProviderName
            Message = $e.Message.Split("`n")[0]
        }
    }
} catch {}

Write-Host "Формирование HTML-отчета..." -ForegroundColor Cyan

# ==========================================
# 9. ГЕНЕРАЦИЯ HTML-КОНТЕНТА
# ==========================================

# Сбор строк таблиц
$physTableRows = ""
if ($physicalDisks.Count -eq 0) {
    $physTableRows = "<tr><td colspan='8' style='text-align:center; color: var(--text-muted);'>Физические накопители не определены (возможно, запуск в VM).</td></tr>"
} else {
    foreach ($pd in $physicalDisks) {
        $hClass = if ($pd.Health -eq "Healthy" -or $pd.Health -eq "OK") { "badge-success" } elseif ($pd.Health -eq "Warning") { "badge-warning" } else { "badge-danger" }
        $physTableRows += "<tr><td>$($pd.Number)</td><td>$($pd.Model)</td><td>$($pd.Type)</td><td>$($pd.Size)</td><td>$($pd.BusType)</td><td><span class='badge $hClass'>$($pd.Health)</span></td><td>$($pd.Status)</td><td><code>$($pd.Serial)</code></td></tr>"
    }
}

$logTableRows = ""
foreach ($ld in $logicalDisks) {
    $percentUsed = 100 - $ld.PercentFree
    $barColor = if ($percentUsed -gt 85) { "#f87171" } elseif ($percentUsed -gt 70) { "#facc15" } else { "#38bdf8" }
    $progressBar = "<div class='progress-container' title='Занято: $percentUsed%'><div class='progress-bar' style='width: $percentUsed%; background-color: $barColor;'></div></div>"
    $logTableRows += "<tr><td><strong>$($ld.Drive)</strong></td><td>$($ld.VolumeName)</td><td>$($ld.FileSystem)</td><td>$($ld.TotalSize)</td><td>$($ld.UsedSpace)</td><td>$($ld.FreeSpace)</td><td>$progressBar<span style='font-size:11px; color:var(--text-muted);'>Свободно: $($ld.PercentFree)%</span></td></tr>"
}

$netTableRows = ""
foreach ($na in $netAdapters) {
    $sClass = if ($na.Status -eq "Up" -or $na.Status -eq "Active" -or $na.Status -eq 2) { "badge-success" } else { "badge-danger" }
    $netTableRows += "<tr><td>$($na.Name)</td><td><span class='badge $sClass'>$($na.Status)</span></td><td>$($na.Speed)</td><td><code>$($na.MAC)</code></td><td>$($na.IPs)</td></tr>"
}

$upTableRows = ""
foreach ($lu in $lastUpdates) {
    $upTableRows += "<tr><td><span class='badge badge-info'>$($lu.HotFixID)</span></td><td>$($lu.Description)</td><td>$($lu.InstalledBy)</td><td>$($lu.InstalledOn)</td></tr>"
}

$startTableRows = ""
foreach ($sa in $startupApps) {
    $startTableRows += "<tr><td>$($sa.Name)</td><td style='word-break: break-all;'><code>$($sa.Command)</code></td><td>$($sa.User)</td></tr>"
}

$topCpuRows = ""
foreach ($p in $topCpu) {
    $topCpuRows += "<tr><td>$($p.ID)</td><td>$($p.Name)</td><td><strong>$($p.CPU)</strong></td><td>$($p.Memory)</td></tr>"
}

$topRamRows = ""
foreach ($p in $topRam) {
    $topRamRows += "<tr><td>$($p.ID)</td><td>$($p.Name)</td><td><strong>$($p.Memory)</strong></td><td>$($p.CPU)</td></tr>"
}

$logErrRows = ""
if ($eventLogs.Count -eq 0) {
    $logErrRows = "<tr><td colspan='4' style='text-align:center; color: var(--text-muted);'>Ошибок в журнале событий не зафиксировано за последние 24 часа.</td></tr>"
} else {
    foreach ($el in $eventLogs) {
        $logErrRows += "<tr><td>$($el.Time)</td><td><span class='badge badge-danger'>$($el.LogName)</span></td><td>$($el.Source)</td><td style='word-break: break-all;'>$($el.Message)</td></tr>"
    }
}

$adminRows = ""
foreach ($adm in $localAdmins) {
    $adminRows += "<tr><td>$($adm.Name)</td><td>$($adm.PrincipalSource)</td></tr>"
}

$fwRows = ""
foreach ($fw in $firewallProfiles) {
    $fwBadge = if ($fw.State -eq "Enabled") { "<span class='badge badge-success'>Включен</span>" } else { "<span class='badge badge-danger'>Выключен</span>" }
    $fwRows += "<tr><td>$($fw.Profile)</td><td>$fwBadge</td></tr>"
}

$blTableRows = ""
foreach ($b in $bitlockerStatus) {
    $blBadge = if ($b.ProtectionStatus -eq "On" -or $b.ProtectionStatus -eq 1) { "<span class='badge badge-success'>Защищено</span>" } else { "<span class='badge badge-danger'>Открыто</span>" }
    $blTableRows += "<tr><td>$($b.MountPoint)</td><td>$blBadge</td><td>$($b.EncryptionPercent)</td></tr>"
}

# Генерация итогового файла
$html = @"
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<title>Отчет о системе — $computerName</title>
<style>
:root {
  --bg-color: #0b0f19;
  --card-bg: #151d30;
  --border-color: #242f4c;
  --text-color: #f1f5f9;
  --text-muted: #94a3b8;
  --accent-color: #38bdf8;
  --success-color: #4ade80;
  --warning-color: #facc15;
  --danger-color: #f87171;
}
body {
    font-family: 'Segoe UI', -apple-system, system-ui, sans-serif;
    background-color: var(--bg-color);
    color: var(--text-color);
    margin: 0;
    padding: 24px;
    line-height: 1.5;
}
.container {
    max-width: 1400px;
    margin: 0 auto;
}
header {
    margin-bottom: 30px;
    border-bottom: 2px solid var(--border-color);
    padding-bottom: 16px;
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    flex-wrap: wrap;
    gap: 16px;
}
h1 {
    margin: 0;
    font-size: 2rem;
    color: var(--accent-color);
    font-weight: 700;
}
.generation-time {
    color: var(--text-muted);
    font-size: 0.9rem;
}
.alert {
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 24px;
    font-size: 0.9rem;
}
.alert-warning {
    background-color: #422006;
    border: 1px solid #ca8a04;
    color: #fef08a;
}
.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 20px;
    margin-bottom: 24px;
}
.card {
    background-color: var(--card-bg);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    padding: 20px;
}
.card-title {
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--accent-color);
    margin-bottom: 16px;
    border-bottom: 1px dashed var(--border-color);
    padding-bottom: 10px;
    display: flex;
    align-items: center;
    gap: 8px;
}
.info-row {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    font-size: 0.9rem;
    gap: 10px;
}
.info-label {
    color: var(--text-muted);
}
.info-value {
    font-weight: 500;
    text-align: right;
}
.section-title {
    font-size: 1.3rem;
    color: var(--accent-color);
    margin-top: 40px;
    margin-bottom: 16px;
    display: flex;
    align-items: center;
    gap: 10px;
}
.table-container {
    background-color: var(--card-bg);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    overflow-x: auto;
    margin-bottom: 24px;
}
table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
    text-align: left;
}
th, td {
    padding: 12px 16px;
    border-bottom: 1px solid var(--border-color);
}
th {
    background-color: #0e1422;
    color: var(--accent-color);
    font-weight: 600;
    font-size: 0.8rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}
tr:last-child td {
    border-bottom: none;
}
tr:hover {
    background-color: #1a243c;
}
.badge {
    padding: 3px 8px;
    border-radius: 5px;
    font-weight: 600;
    font-size: 0.75rem;
    display: inline-block;
}
.badge-success { background-color: #064e3b; color: var(--success-color); border: 1px solid #059669; }
.badge-warning { background-color: #451a03; color: var(--warning-color); border: 1px solid #d97706; }
.badge-danger { background-color: #4c0519; color: var(--danger-color); border: 1px solid #e11d48; }
.badge-info { background-color: #1e3a8a; color: var(--accent-color); border: 1px solid #2563eb; }

.progress-container {
    background-color: var(--border-color);
    border-radius: 4px;
    height: 8px;
    width: 100%;
    margin-top: 6px;
    margin-bottom: 4px;
    overflow: hidden;
}
.progress-bar {
    height: 100%;
    border-radius: 4px;
}
code {
    font-family: Consolas, Monaco, monospace;
    background-color: #0f1524;
    padding: 2px 6px;
    border-radius: 4px;
    color: #e2e8f0;
    font-size: 0.8rem;
}
.performance-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(480px, 1fr));
    gap: 20px;
    margin-bottom: 24px;
}
@media (max-width: 768px) {
    .performance-grid {
        grid-template-columns: 1fr;
    }
}
</style>
</head>
<body>
<div class="container">
    <header>
        <div>
            <h1>Сводный отчёт о системе</h1>
            <div class="generation-time">Хост: <strong>$computerName</strong> | Сгенерировано: $(Get-Date -Format "dd.MM.yyyy HH:mm")</div>
        </div>
    </header>

    $(if (!$isAdmin) { $adminWarning })

    <!-- ВЕРХНЯЯ СЕТКА КАРТОЧЕК -->
    <div class="grid">
        <!-- Карточка 1: Сведения об ОС -->
        <div class="card">
            <div class="card-title">🖥️ Основные сведения</div>
            <div class="info-row"><span class="info-label">Имя хоста:</span><span class="info-value">$computerName</span></div>
            <div class="info-row"><span class="info-label">Операционная система:</span><span class="info-value">$osName (Сборка $osBuild)</span></div>
            <div class="info-row"><span class="info-label">Дата установки ОС:</span><span class="info-value">$osInstallDate</span></div>
            <div class="info-row"><span class="info-label">Платформа:</span><span class="info-value">$manufacturer $model</span></div>
            <div class="info-row"><span class="info-label">Время непрерывной работы:</span><span class="info-value">$uptimeString</span></div>
            <div class="info-row"><span class="info-label">Последняя перезагрузка:</span><span class="info-value">$lastBoot</span></div>
        </div>

        <!-- Карточка 2: Аппаратное обеспечение -->
        <div class="card">
            <div class="card-title">⚙️ Аппаратное обеспечение</div>
            <div class="info-row"><span class="info-label">Процессор (CPU):</span><span class="info-value">$cpuName</span></div>
            <div class="info-row"><span class="info-label">Ядра / Потоки:</span><span class="info-value">$cpuCores яд. / $cpuLogical пот.</span></div>
            <div class="info-row"><span class="info-label">Тактовая частота:</span><span class="info-value">$cpuMaxSpeed ГГц</span></div>
            <div class="info-row">
                <span class="info-label">Память (RAM):</span>
                <span class="info-value">$usedRamGB / $totalRamGB ГБ ($ramPercent%)</span>
            </div>
            <div class="progress-container">
                <div class="progress-bar" style="width: $ramPercent%; background-color: $(if($ramPercent -gt 85){"#f87171"}elseif($ramPercent -gt 60){"#facc15"}else{"#4ade80"});"></div>
            </div>
            <div class="info-row" style="margin-top: 10px;"><span class="info-label">Модули RAM:</span><span class="info-value">$ramSticksCount шт. | $ramSpeed | $ramManufacturer</span></div>
            <div class="info-row"><span class="info-label">Версия BIOS:</span><span class="info-value">$($bios.SMBIOSBIOSVersion) ($(($bios.ReleaseDate).ToString("dd.MM.yyyy")))</span></div>
            <div class="info-row"><span class="info-label">Графика (GPU):</span><span class="info-value">$gpuString</span></div>
        </div>

        <!-- Карточка 3: Безопасность -->
        <div class="card">
            <div class="card-title">🛡️ Безопасность</div>
            <div class="info-row">
                <span class="info-label">Windows Defender:</span>
                <span class="info-value">$(if ($defenderStatus -eq "Enabled") { "<span class='badge badge-success'>Активен</span>" } elseif ($defenderStatus -eq "Disabled") { "<span class='badge badge-danger'>Отключен</span>" } else { "<span class='badge badge-warning'>N/A</span>" })</span>
            </div>
            <div class="info-row">
                <span class="info-label">Режим реального времени:</span>
                <span class="info-value">$(if ($defenderRealtime -eq "Enabled") { "<span class='badge badge-success'>Вкл</span>" } else { "<span class='badge badge-danger'>Выкл</span>" })</span>
            </div>
            <div class="info-row" style="margin-top: 10px;"><span class="info-label">Брандмауэр по профилям:</span></div>
            <table style="margin-top: 5px;">
                $fwRows
            </table>
        </div>

        <!-- Карточка 4: Сетевое окружение и BitLocker -->
        <div class="card">
            <div class="card-title">🌐 Сеть и шифрование</div>
            <div class="info-row">
                <span class="info-label">Подключение к сети:</span>
                <span class="info-value">$(if ($internetStatus -eq "Connected") { "<span class='badge badge-success'>Интернетизирован</span>" } else { "<span class='badge badge-danger'>Локальный режим</span>" })</span>
            </div>
            <div class="info-row"><span class="info-label">Внешний IP-адрес:</span><span class="info-value">$externalIP</span></div>
            <div class="info-row"><span class="info-label">Домен / Рабочая группа:</span><span class="info-value">$domain</span></div>
            
            <div class="info-row" style="margin-top:10px;"><span class="info-label">Статус BitLocker:</span></div>
            <table style="margin-top: 5px;">
                $(if($blTableRows){$blTableRows}else{"<tr><td colspan='3' style='text-align:center;color:var(--text-muted);'>Диски не зашифрованы или нет доступа</td></tr>"})
            </table>
        </div>
    </div>

    <!-- РАЗДЕЛ: НАКОПИТЕЛИ -->
    <div class="section-title">💾 Подсистема хранения данных</div>
    
    <div class="card-title" style="margin-bottom:8px;">Физические накопители</div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th style="width: 5%">Индекс</th>
                    <th style="width: 25%">Модель устройства</th>
                    <th style="width: 10%">Тип носителя</th>
                    <th style="width: 10%">Объем</th>
                    <th style="width: 10%">Интерфейс</th>
                    <th style="width: 10%">Здоровье</th>
                    <th style="width: 10%">Состояние</th>
                    <th style="width: 20%">Серийный номер</th>
                </tr>
            </thead>
            <tbody>
                $physTableRows
            </tbody>
        </table>
    </div>

    <div class="card-title" style="margin-bottom:8px;">Логические диски (разделы)</div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th style="width: 5%">Буква</th>
                    <th style="width: 15%">Метка тома</th>
                    <th style="width: 10%">Файловая система</th>
                    <th style="width: 15%">Всего</th>
                    <th style="width: 15%">Занято</th>
                    <th style="width: 15%">Свободно</th>
                    <th style="width: 25%">Распределение памяти</th>
                </tr>
            </thead>
            <tbody>
                $logTableRows
            </tbody>
        </table>
    </div>

    <!-- РАЗДЕЛ: СЕТЬ И АДАПТЕРЫ -->
    <div class="section-title">🔌 Сетевые интерфейсы</div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Имя адаптера</th>
                    <th style="width: 10%">Статус</th>
                    <th style="width: 15%">Скорость соединения</th>
                    <th style="width: 20%">MAC-адрес</th>
                    <th>IPv4 Адрес(а)</th>
                </tr>
            </thead>
            <tbody>
                $netTableRows
            </tbody>
        </table>
    </div>

    <!-- ДИАГНОСТИКА И ПРОИЗВОДИТЕЛЬНОСТЬ -->
    <div class="section-title">📊 Текущая производительность и логи</div>
    <div class="performance-grid">
        <!-- Топ процессов CPU -->
        <div class="card">
            <div class="card-title">🔥 Топ-5 процессов по CPU</div>
            <table>
                <thead>
                    <tr>
                        <th style="width:15%">PID</th>
                        <th>Имя процесса</th>
                        <th style="width:20%">CPU %</th>
                        <th style="width:25%">Память (WS)</th>
                    </tr>
                </thead>
                <tbody>
                    $topCpuRows
                </tbody>
            </table>
        </div>

        <!-- Топ процессов RAM -->
        <div class="card">
            <div class="card-title">💧 Топ-5 процессов по ОЗУ</div>
            <table>
                <thead>
                    <tr>
                        <th style="width:15%">PID</th>
                        <th>Имя процесса</th>
                        <th style="width:25%">Память (WS)</th>
                        <th style="width:20%">CPU %</th>
                    </tr>
                </thead>
                <tbody>
                    $topRamRows
                </tbody>
            </table>
        </div>
    </div>

    <!-- Журнал ошибок -->
    <div class="card" style="margin-bottom: 24px;">
        <div class="card-title">⚠️ Последние ошибки журналов событий (за 24 часа)</div>
        <div class="table-container" style="margin-bottom:0; border:none;">
            <table>
                <thead>
                    <tr>
                        <th style="width: 15%">Время</th>
                        <th style="width: 10%">Лог</th>
                        <th style="width: 20%">Источник</th>
                        <th>Сообщение</th>
                    </tr>
                </thead>
                <tbody>
                    $logErrRows
                </tbody>
            </table>
        </div>
    </div>

    <!-- СИСТЕМНЫЕ НАСТРОЙКИ (Обновления, автозагрузка, пользователи) -->
    <div class="section-title">⚙️ Системное окружение</div>
    
    <div class="performance-grid">
        <!-- Недавние обновления -->
        <div class="card">
            <div class="card-title">📦 Последние обновления (HotFixes)</div>
            <table>
                <thead>
                    <tr>
                        <th style="width:25%">KB ID</th>
                        <th>Описание</th>
                        <th style="width:25%">Установил</th>
                        <th style="width:20%">Дата</th>
                    </tr>
                </thead>
                <tbody>
                    $upTableRows
                </tbody>
            </table>
        </div>

        <!-- Администраторы -->
        <div class="card">
            <div class="card-title">👥 Локальные администраторы</div>
            <table>
                <thead>
                    <tr>
                        <th>Имя пользователя</th>
                        <th style="width:40%">Источник учетной записи</th>
                    </tr>
                </thead>
                <tbody>
                    $adminRows
                </tbody>
            </table>
        </div>
    </div>

    <!-- Программы в автозагрузке -->
    <div class="card">
        <div class="card-title">🚀 Автозагрузка приложений (Startup)</div>
        <div class="table-container" style="margin-bottom:0; border:none;">
            <table>
                <thead>
                    <tr>
                        <th style="width:25%">Название</th>
                        <th>Команда / Путь запуска</th>
                        <th style="width:20%">Пользователь</th>
                    </tr>
                </thead>
                <tbody>
                    $startTableRows
                </tbody>
            </table>
        </div>
    </div>

</div>
</body>
</html>
"@

# Запись файла и автоматический запуск
[System.IO.File]::WriteAllText($outputPath, $html, [System.Text.Encoding]::UTF8)

Write-Host "Готово! Отчет успешно сохранен в: $outputPath" -ForegroundColor Green
Invoke-Item $outputPath