@echo off
chcp 65001 > nul
set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Content -Raw -Encoding UTF8 '%SCRIPT_DIR%SearchThumbnails.ps1' | Invoke-Expression"
pause