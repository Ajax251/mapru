# Скрипт для поиска эскизов картинок и PDF на русском языке с выбором типов файлов

# 1. Проверяем наличие ассоциации эскизов PDF в системе
$Path1 = "Registry::HKEY_CLASSES_ROOT\.pdf\ShellEx\{E357FCCD-A995-4576-B01F-234630154E96}"
$Path2 = "Registry::HKEY_CURRENT_USER\Software\Classes\.pdf\ShellEx\{E357FCCD-A995-4576-B01F-234630154E96}"
$Path3 = "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\.pdf\ShellEx\{E357FCCD-A995-4576-B01F-234630154E96}"

$HasPDFThumbnail = (Test-Path $Path1) -or (Test-Path $Path2) -or (Test-Path $Path3)

if (-not $HasPDFThumbnail) {
    Write-Host "Внимание: В системе не настроены эскизы для PDF." -ForegroundColor Yellow
    $Response = Read-Host "Хотите установить SumatraPDF через winget для автоматического включения PDF-эскизов? (Y/N)"
    if ($Response -eq 'Y' -or $Response -eq 'y') {
        Write-Host "Попытка установки SumatraPDF..." -ForegroundColor Cyan
        try {
            winget install SumatraPDF.SumatraPDF --silent
            Write-Host "Установка успешно завершена!" -ForegroundColor Green
            Write-Host "Перезапускаем Проводник Windows для применения изменений..." -ForegroundColor Yellow
            Stop-Process -Name explorer -Force
            Start-Sleep -Seconds 1
        } catch {
            Write-Host "Не удалось установить SumatraPDF автоматически. Запустите BAT-файл от имени Администратора." -ForegroundColor Red
        }
    }
} else {
    Write-Host "Эскизы PDF уже настроены в вашей системе." -ForegroundColor Green
}

# 2. Выбор каталога пользователем
Write-Host "`nОткрытие диалога выбора папки..." -ForegroundColor Cyan
$Shell = New-Object -ComObject Shell.Application
$Folder = $Shell.BrowseForFolder(0, "Выберите папку для просмотра эскизов:", 0, 17)

if (-not $Folder) {
    Write-Host "Выбор каталога отменен." -ForegroundColor Red
    Exit
}

$SelectedFolder = $Folder.Self.Path
Write-Host "Выбран каталог: $SelectedFolder" -ForegroundColor Green

# 3. Ввод минимального размера файла
$MinSizeKB = Read-Host "Введите минимальный размер файла в КБ (по умолчанию 100)"
if ([string]::IsNullOrWhiteSpace($MinSizeKB)) {
    $MinSizeKB = "100"
}

$MinSizeBytes = [int64]$MinSizeKB * 1024

# 4. Выбор типа файлов для поиска
Write-Host "`nВыберите типы файлов для поиска:" -ForegroundColor Cyan
Write-Host "1 - Только PDF (*.pdf)"
Write-Host "2 - Картинки + PDF (по умолчанию)"
Write-Host "3 - Только картинки (JPG, PNG, GIF, BMP)"
Write-Host "4 - Свой тип файлов (например: .docx, .xlsx)"
$Choice = Read-Host "Введите номер варианта (1-4)"

$FileFilter = ""
if ($Choice -eq "1") {
    $FileFilter = "(*.pdf)"
} elseif ($Choice -eq "3") {
    $FileFilter = "(*.jpg OR *.jpeg OR *.png OR *.gif OR *.bmp)"
} elseif ($Choice -eq "4") {
    $CustomInput = Read-Host "Введите расширения через пробел или запятую (например: .docx, .xlsx)"
    if ([string]::IsNullOrWhiteSpace($CustomInput)) {
        $FileFilter = "(*.pdf OR *.jpg OR *.jpeg OR *.png OR *.gif OR *.bmp)" # Откат на дефолт при пустом вводе
    } else {
        # Разделяем введенную строку по пробелам, запятым или точкам с запятой
        $Exts = $CustomInput -split '[\s,;]+' | ForEach-Object {
            $e = $_.Trim().ToLower()
            if ($e) {
                # Приводим к формату *.расширение для Windows Search
                if (-not $e.StartsWith('*.')) {
                    if ($e.StartsWith('.')) { $e = "*$e" } else { $e = "*.$e" }
                }
                $e
            }
        }
        $FileFilter = "(" + ($Exts -join " OR ") + ")"
    }
} else {
    # По умолчанию или вариант 2
    $FileFilter = "(*.pdf OR *.jpg OR *.jpeg OR *.png OR *.gif OR *.bmp)"
}

# 5. Формирование поискового запроса по каноническим свойствам Windows
$Query = "System.Size:>=$MinSizeBytes $FileFilter"

# Кодируем параметры, чтобы Windows Explorer правильно их обработал в URI
$EncodedQuery = [uri]::EscapeDataString($Query)
$EncodedLocation = [uri]::EscapeDataString($SelectedFolder)

$SearchURI = "search-ms:query=$EncodedQuery&crumb=location:$EncodedLocation"

Write-Host "Открытие Проводника с результатами..." -ForegroundColor Green
Start-Process $SearchURI