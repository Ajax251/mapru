# Скрипт для поиска эскизов картинок и PDF на русском языке с выбором подкаталогов и типов вывода

# 1. Проверяем наличие ассоциации эскизов PDF в системе
$Path1 = "Registry::HKEY_CLASSES_ROOT\.pdf\ShellEx\{E357FCCD-A995-4576-B01F-234630154E96}"
$Path2 = "Registry::HKEY_CURRENT_USER\Software\Classes\.pdf\ShellEx\{E357FCCD-A995-4576-B01F-234630154E96}"
$Path3 = "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Classes\.pdf\ShellEx\{E357FCCD-A995-4576-B01F-234630154E96}"

$HasPDFThumbnail = (Test-Path $Path1) -or (Test-Path $Path2) -or (Test-Path $Path3)

if (-not $HasPDFThumbnail) {
    Write-Host "Внимание: В системе не настроены эскизы для PDF." -ForegroundColor Yellow
    $Response = Read-Host "Хотите установить SumatraPDF через winget для автоматического включения PDF-эскизов? (Y/N)"
    if ($Response -eq 'Y' -or $Response -eq 'y') {
        Write-Host "Попытка установки SumatraPDF..." -ForegroundColor Cyan
        try {
            winget install SumatraPDF.SumatraPDF --silent
            Write-Host "Установка успешно завершена!" -ForegroundColor Green
            Write-Host "Перезапускаем Проводник Windows для применения изменений..." -ForegroundColor Yellow
            Stop-Process -Name explorer -Force
            Start-Sleep -Seconds 1
        } catch {
            Write-Host "Не удалось установить SumatraPDF автоматически. Запустите BAT-файл от имени Администратора." -ForegroundColor Red
        }
    }
} else {
    Write-Host "Эскизы PDF уже настроены в вашей системе." -ForegroundColor Green
}

# 2. Выбор каталога пользователем
Write-Host "`nОткрытие диалога выбора папки..." -ForegroundColor Cyan
$Shell = New-Object -ComObject Shell.Application
$Folder = $Shell.BrowseForFolder(0, "Выберите папку для просмотра эскизов:", 0, 17)

if (-not $Folder) {
    Write-Host "Выбор каталога отменен." -ForegroundColor Red
    Exit
}

$SelectedFolder = $Folder.Self.Path
Write-Host "Выбран каталог: $SelectedFolder" -ForegroundColor Green

# 3. Запрос на сканирование подкаталогов (вложенных папок)
$RecurseInput = Read-Host "Искать также во вложенных папках (подкаталогах)? (Y/N, по умолчанию Y)"
$Recurse = $true
if ($RecurseInput -eq 'N' -or $RecurseInput -eq 'n') {
    $Recurse = $false
    Write-Host "Поиск ограничен только выбранной папкой (без подпапок)." -ForegroundColor Yellow
} else {
    Write-Host "Поиск будет выполнен включая все подкаталоги." -ForegroundColor Green
}

# 4. Ввод минимального размера файла
$MinSizeKB = Read-Host "Введите минимальный размер файла в КБ (по умолчанию 100)"
if ([string]::IsNullOrWhiteSpace($MinSizeKB)) {
    $MinSizeKB = "100"
}

$MinSizeBytes = [int64]$MinSizeKB * 1024

# 5. Выбор типа файлов для поиска
Write-Host "`nВыберите типы файлов для поиска:" -ForegroundColor Cyan
Write-Host "1 - Только PDF (*.pdf)"
Write-Host "2 - Картинки + PDF (по умолчанию)"
Write-Host "3 - Только картинки (JPG, PNG, GIF, BMP)"
Write-Host "4 - Свой тип файлов (например: .docx, .xlsx)"
$Choice = Read-Host "Введите номер варианта (1-4)"

$ExtensionsToFind = @()
$FileFilter = ""

if ($Choice -eq "1") {
    $FileFilter = "(*.pdf)"
    $ExtensionsToFind = @("*.pdf")
} elseif ($Choice -eq "3") {
    $FileFilter = "(*.jpg OR *.jpeg OR *.png OR *.gif OR *.bmp)"
    $ExtensionsToFind = @("*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp")
} elseif ($Choice -eq "4") {
    $CustomInput = Read-Host "Введите расширения через пробел или запятую (например: .docx, .xlsx)"
    if ([string]::IsNullOrWhiteSpace($CustomInput)) {
        $FileFilter = "(*.pdf OR *.jpg OR *.jpeg OR *.png OR *.gif OR *.bmp)"
        $ExtensionsToFind = @("*.pdf", "*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp")
    } else {
        $Exts = $CustomInput -split '[\s,;]+' | ForEach-Object {
            $e = $_.Trim().ToLower()
            if ($e) {
                if (-not $e.StartsWith('*.')) {
                    if ($e.StartsWith('.')) { $e = "*$e" } else { $e = "*.$e" }
                }
                $e
            }
        }
        $FileFilter = "(" + ($Exts -join " OR ") + ")"
        $ExtensionsToFind = $Exts
    }
} else {
    $FileFilter = "(*.pdf OR *.jpg OR *.jpeg OR *.png OR *.gif OR *.bmp)"
    $ExtensionsToFind = @("*.pdf", "*.jpg", "*.jpeg", "*.png", "*.gif", "*.bmp")
}

# 6. Выбор способа вывода
Write-Host "`nВыберите способ вывода результатов:" -ForegroundColor Cyan
Write-Host "1 - Открыть в Проводнике Windows (по умолчанию)"
Write-Host "2 - Открыть как HTML-галерею в браузере"
$OutputChoice = Read-Host "Введите номер варианта (1-2)"

if ($OutputChoice -eq "2") {
    # ВАРИАНТ HTML-ГАЛЕРЕИ
    Write-Host "Сканирование папки на наличие файлов..." -ForegroundColor Cyan
    
    # Сканируем с учетом выбранной настройки рекурсии ($Recurse)
    $Files = Get-ChildItem -Path $SelectedFolder -File -Recurse:$Recurse | Where-Object {
        $file = $_
        $sizeMatch = $file.Length -ge $MinSizeBytes
        $extMatch = $false
        foreach ($ext in $ExtensionsToFind) {
            if ($file.Name -like $ext) { $extMatch = $true; break }
        }
        $sizeMatch -and $extMatch
    }

    if ($Files.Count -eq 0) {
        Write-Host "Файлы, соответствующие критериям поиска, не найдены." -ForegroundColor Red
        Exit
    }

    Write-Host "Генерация HTML-страницы..." -ForegroundColor Cyan
    
    $CardsHtml = ""
    foreach ($file in $Files) {
        $Uri = New-Object System.Uri($file.FullName)
        $EscapedPath = $Uri.AbsoluteUri
        
        $ThumbHtml = ""
        if ($file.Extension.ToLower() -eq ".pdf") {
            $ThumbHtml = "<iframe src=""$EscapedPath#toolbar=0&navpanes=0&scrollbar=0"" class=""thumb-pdf"" loading=""lazy""></iframe>"
        } else {
            $ThumbHtml = "<img src=""$EscapedPath"" class=""thumb-img"" loading=""lazy"">"
        }

        $SizeKb = [Math]::Round($file.Length / 1KB, 1)

        $CardsHtml += @"
        <div class="card" onclick="window.open('$EscapedPath')">
            <div class="thumb-container">
                $ThumbHtml
            </div>
            <div class="info">
                <div class="title" title="$($file.Name)">$($file.Name)</div>
                <div class="size">$SizeKb КБ</div>
            </div>
        </div>
"@
    }

    $HtmlContent = @"
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Галерея файлов - $SelectedFolder</title>
    <style>
        body {
            background-color: #121212;
            color: #e0e0e0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
        }
        h1 {
            font-size: 22px;
            margin: 0 0 5px 0;
            color: #ffffff;
        }
        .subtitle {
            color: #888;
            margin-bottom: 25px;
            font-size: 14px;
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 20px;
        }
        .card {
            background-color: #1e1e1e;
            border: 1px solid #2d2d2d;
            border-radius: 8px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            cursor: pointer;
            transition: transform 0.2s, border-color 0.2s;
        }
        .card:hover {
            transform: translateY(-4px);
            border-color: #00bcd4;
        }
        .thumb-container {
            width: 100%;
            height: 150px;
            background-color: #0d0d0d;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }
        .thumb-img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .thumb-pdf {
            width: 100%;
            height: 100%;
            border: none;
            pointer-events: none;
        }
        .info {
            padding: 10px;
        }
        .title {
            font-size: 13px;
            font-weight: 600;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            margin-bottom: 4px;
            color: #ffffff;
        }
        .size {
            font-size: 11px;
            color: #888;
        }
    </style>
</head>
<body>
    <h1>Галерея эскизов</h1>
    <div class="subtitle">Папка: $SelectedFolder | Найдено элементов: $($Files.Count)</div>
    <div class="grid">
        $CardsHtml
    </div>
</body>
</html>
"@

    $TempFile = Join-Path $env:TEMP "gallery_$((Get-Date).Ticks).html"
    [System.IO.File]::WriteAllText($TempFile, $HtmlContent, [System.Text.Encoding]::UTF8)
    
    Write-Host "Запуск браузера с галереей..." -ForegroundColor Green
    Start-Process $TempFile

} else {
    # ВАРИАНТ С ПРОПИСНЫМ ПРОВОДНИКОМ (search-ms)
    $Query = "System.Size:>=$MinSizeBytes $FileFilter"

    $EncodedQuery = [uri]::EscapeDataString($Query)
    $EncodedLocation = [uri]::EscapeDataString($SelectedFolder)

    # ОПРЕДЕЛЯЕМ ГЛУБИНУ ПОИСКА ДЛЯ ПРОВОДНИКА:
    $Scope = "location"
    if (-not $Recurse) {
        $Scope = "folder"
    }

    # ИСПРАВЛЕНО: Явное сложение строк исключает ошибки парсинга двоеточия у переменной $Scope
    $SearchURI = "search-ms:query=" + $EncodedQuery + "&crumb=" + $Scope + ":" + $EncodedLocation

    Write-Host "Открытие Проводника с результатами..." -ForegroundColor Green
    Start-Process $SearchURI
}